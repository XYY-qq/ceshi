﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CIM通讯
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            System.Threading.Mutex mutex = new System.Threading.Mutex(false, "CIM通讯");
            bool Running = !mutex.WaitOne(0, false);
            if (Running)
            {
                MessageBox.Show("程序已启动！");
                return;
            }

            try
            {
                Application.Run(new CIMMainForm());

            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }
    }
}
