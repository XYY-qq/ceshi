﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIM通讯
{
    public class CIMData
    {
           //时间
            private string datatime;
            public string Datatime
            {
                get { return datatime; }
                set { datatime = value; }
            }
           //panelID
            private string panelID;
            public string PanelID
            {
                get { return panelID; }
                set { panelID = value; }
            }
            //TrayID
            private string trayID;
            public string TrayID
            {
                get { return trayID; }
                set { trayID = value; }
            }
            //panelID 验证信息
            private string rTCode;
            public string RTCode
            {
                get
                { return rTCode; }
                set { rTCode = value; }
            }
    }
}
