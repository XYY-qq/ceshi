﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Xml;
using System.Xml.Linq;

namespace CIM通讯
{
    //CtL/CtR/Ct1L/Ct1R
    public partial class ParamsSetForm : Form
    {
        public CIMParams CIMparams = null;
        public ParamsSetForm(CIMParams CIMparams)
        {
            this.CIMparams = CIMparams;
            CIMparams.ReadPrm();         
            InitializeComponent();
            tb_UnitID.Text = CIMparams.UnitID;
            cmb_Prefix.Text = CIMparams.Prefix;
            //参数设置里面的保存天数
            tb_dataSaveDays.Text = CIMparams.dataSaveDays.ToString();

            check_OutLineDefine.Checked = CIMparams.OutLineDefine;
            check_FourStationEnable.Checked = CIMparams.FourStationEnable;
            check_OfflineMode.Checked = CIMparams.OfflineMode;

            numericUpDown1.Value = CIMparams.m_iDataStartHour;
            numericUpDown2.Value = CIMparams.m_iDataStartMin;
            Out_Int.Text =  CIMparams.m_iOffLine.ToString();
        }
        //保存参数
        private void btn_Save_Click(object sender, EventArgs e)
        {
            int result = 0;
            if ((tb_UnitID.Text == "") || (cmb_Prefix.SelectedIndex == -1) || (!int.TryParse(this.tb_dataSaveDays.Text, out result)))
            {
                MessageBox.Show("参数输入有误，请重新输入！");
            }
            else
            {
                CIMparams.UnitID = tb_UnitID.Text;
                CIMparams.dataSaveDays = int.Parse(tb_dataSaveDays.Text);
                CIMparams.Prefix = (string)cmb_Prefix.SelectedItem;
                CIMparams.OutLineDefine = check_OutLineDefine.Checked;
                CIMparams.FourStationEnable = check_FourStationEnable.Checked;
                CIMparams.OfflineMode = check_OfflineMode.Checked;

                CIMparams.m_iDataStartHour = decimal.ToInt32(numericUpDown1.Value);
                CIMparams.m_iDataStartMin = decimal.ToInt32(numericUpDown2.Value);
                CIMparams.m_iOffLine  = int.Parse(Out_Int.Text);

                if (CIMparams.SavePrm())
                {
                    DialogResult = DialogResult.OK;
                }
                else
                {
                    MessageBox.Show("参数应用成功，但保存到本地文件失败!");
                }
            }
            string file_B = Path.Combine(".\\params", "CIMConfig_beifen");
            XElement ele = CIMparams.ToXml();
            ele.Save(file_B);
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void ParamsSetForm_Load(object sender, EventArgs e)
        {

        }

        private void check_OutLineDefine_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void check_FourStationEnable_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void check_OfflineMode_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void NumericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            CIMparams.m_iDataStartHour = decimal.ToInt32(numericUpDown1.Value);
        }

        private void NumericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            CIMparams.m_iDataStartMin = decimal.ToInt32(numericUpDown2.Value);
        }
    }           
}
