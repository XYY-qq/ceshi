﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using TimeOperate;
using System.Threading;
using System.Threading.Tasks;
using System.Data;
using Cognex.DataMan.SDK;
using System.IO;
using System.Diagnostics;
using System.Timers;
using System.Xml;
using System.Xml.Linq;

namespace CIM通讯
{
    public partial class CIMMainForm : Form
    {
        public EqpRepairForm.EqpRepairFlow eqpRepairFlow = EqpRepairForm.EqpRepairFlow.EqpRepairEnd;

        public delegate void SD_BCToCtL_Command_MessageEventHandler(string value);
        public event Action<bool[]> CanRemveDownPanel;
        public event Action EqpStatusChange;

        public static string EqpRepairEndTime = "";
        public static string CallEqpRepairTime = "";
        public static string RepairStartTime = "";
        public static string EndOperatorID = "";
        public static string CallOperatorID = "";
        public static string StartRepairOperatorID = "";


        /// <summary>
        /// 康耐视的库
        /// 调用采图的dll
        /// </summary>
       // public Cognex.DataMan.SDK.MainForm CognexForm = new Cognex.DataMan.SDK.MainForm();
        CIMMainClass cIMMainClass = new CIMMainClass();

        List<CIMData> list = new List<CIMData>();
        System.Timers.Timer aTimer = new System.Timers.Timer(); //定时器

        //只要对配置文件做了写入动作，则在此时将配置全部写入到备份配置文件
        //备份的文件
        string file_B = Path.Combine(".\\params", "CIMConfig_beifen");
        XElement ele1 ;
        System.Timers.Timer m_timerWaterTank;
        public CIMMainForm()
        {
            //到时间的时候执行事件
            //aTimer.Elapsed += new ElapsedEventHandler(TimerDayReadCode);
            //aTimer.Interval = 3600000;//一个小时存一次
            //aTimer.AutoReset = true;//执行一次 false，一直执行true  
            ////是否执行System.Timers.Timer.Elapsed事件  
            //aTimer.Enabled = true;

            InitializeComponent();
            UIShow(cIMMainClass.CIMparams.OfflineMode);
            ele1 = cIMMainClass.CIMparams.ToXml();


            

            LockSwitchForm.KeyRightEvent_2 += this.EnabledForm;//使能界面
            LockSwitchForm.KeyErrorEvent += this.DisabledForm;//屏蔽界面
            DisabledForm();
            cIMMainClass.controlVCR.CIMOffLineEvent += this.CIMOffLine;//CIM离线事件
            cIMMainClass.controlVCR.VCRDisplayEvent += VCRDispaly;//读码成功显示六工位
            cIMMainClass.DispalyBCREvent += this.M_BCRDispaly;
            cIMMainClass.controlBCR.ReceivedAllDataEvent += new ControlBCR.ReceivedAllDataEventHandler(BCRDispaly);
            cIMMainClass.WarningLog += this.MsgBoxOutput;
            cIMMainClass.WarningLog += this.TextBoxOutput;
            cIMMainClass.BCWarningLog += this.BCAlarmMessageOutput;
            cIMMainClass.BCWarningLog += this.MsgBoxOutput;
            cIMMainClass.BCNormalLog += this.BCAlarmMessageOutput; 
            cIMMainClass.NormalLog += this.TextBoxOutput;
            LockSwitchForm.KeyRightEvent += this.CloseForm;//退出功能
            CanRemveDownPanel += this.RemoveDownPanel;//拔片功能    
            cIMMainClass.CIMparams.ReadPrm();
            cIMMainClass.controlVCR.CognexFlag = cIMMainClass.CIMparams.bCognexFlag;
            //是否使用康耐视的取图的功能false为不开启
            if (cIMMainClass.controlVCR.CognexFlag == false)
            {
                this.Width = 567;
                this.Height= 630;
            }
            cIMMainClass.variableMap.BC_Aliving += this.BCStateDispaly;//检查BC是否在线
            cIMMainClass.variableMap.BCTrayValidationDisplayEvent += BCRDispaly;//调取BC里面的核对trayID读取验证
            cIMMainClass.variableMap.BCPNLValidationDisplayEvent += VCRDispaly;
            cIMMainClass.DisplayNowPlateNum += DisplayNowPlateNum;
            cIMMainClass.DispalyReadOKRateEvent += DispalyReadOKRate;

            cIMMainClass.controlVCR.PanelDisplayEvent += VCRDispaly;
            try
            {
                if (cIMMainClass.CIMparams.m_iOffLine == 0)
                {
                    string file_B = Path.Combine(".\\params", "CIMConfig_beifen");
                    File.Delete(file_B);
                    cIMMainClass.CIMparams.m_iOffLine = 1;
                }
                m_timerWaterTank = new System.Timers.Timer(cIMMainClass.CIMparams.m_iOffLine * 60000);
                m_timerWaterTank.Elapsed += new System.Timers.ElapsedEventHandler(m_timerWaterTank_Tick);//到达时间的时候执行事件；
                m_timerWaterTank.AutoReset = true;//设置是执行一次（false）还是一直执行(true)；
            }
            catch (NullReferenceException e)
            {

            }
           
            EqpRepairForm.EqpRepairFlowEvent += new EqpRepairForm.EqpRepairFlowEventHandler(getEqpRepairFlow);

            if(!cIMMainClass.CIMparams.OfflineMode)
            {
                cIMMainClass.variableMap.WindowHandle(this.Handle);//最关键的一步
                EqpStatusChange += CIMMainForm_EqpStatusChange;
                //ControlVCR.CognexReadCodeEvent += CognexForm.GetImage;//康耐视保存图片
                // CognexForm.TopLevel = false;
                // CognexForm.Parent = this.panel_CognexSDK;
                //CognexForm.Show();

                ConnectBCR("COM7");
            }
            if (cIMMainClass.controlVCR.CognexFlag == false)
            {
                ConnectVCR("COM1");
            }
            else
            {
                this.cmb_VCRPort.Visible = false;
                this.btn_ConnectVCR.Visible = false;
                this.VCR.Visible = false;
            }
            //软件开启默认打开VCR开关
            check_PLC_CIMSwitch.Checked = true;
            check_PLC_CIMSwitch_CheckedChanged(null,null);
            cIMMainClass.controlVCR.LotUnlimited = check_LotUnlimited.Checked = true;
            cIMMainClass.CIMparams.ReadPrm();
            if (cIMMainClass.CIMparams.NowTrayID != "")//不为空显示
            {
                SetNowTrayTestState("OK");
                tb_NowTrayID.Text = cIMMainClass.CIMparams.NowTrayID;
                tb_WorkOrderID.Text = cIMMainClass.CIMparams.NowWorkOrderID;
                tb_SetPlateNum.Text = cIMMainClass.CIMparams.NowSetPlateNum.ToString();
                tb_NewPlateNum.Text = cIMMainClass.CIMparams.NowPlateNum.ToString();//当前盘数
                tb_RecipeID.Text = cIMMainClass.CIMparams.NowRecipeID.ToString();//产品型号
                cIMMainClass.controlBCR.queueInTrayID.Enqueue(cIMMainClass.CIMparams.NowTrayID);
                if (cIMMainClass.CIMparams.NextTrayID != "")
                {
                    SetNextTrayTestState("OK");
                    tb_NextTrayID.Text = cIMMainClass.CIMparams.NextTrayID;
                    cIMMainClass.controlBCR.queueInTrayID.Enqueue(cIMMainClass.CIMparams.NextTrayID);
                }
                else
                {
                    SetNextTrayTestState("NT");
                }
            }
            else 
            {
                if (!cIMMainClass.CIMparams.OfflineMode)
                {
                    SetNowTrayTestState("NT");
                    SetNextTrayTestState("NT");
                    MsgBoxOutput("当前无LotID! 请上传新的LotID!");
                    TextBoxOutput("当前无LotID! 请上传新的LotID!");

                    this.cIMMainClass.controlVCR.W_StopFeedAndFinish(true);
                }
            }
        }

        private void UIShow(bool bOffline = false)
        {
            bool bsts = !bOffline;
            label1.Visible = bsts;
            cmb_BCRPort.Visible = bsts;
            btn_ConnectBCR.Visible = bsts;
            btn_CIMAlive.Visible = bsts;
            check_LotUnlimited.Visible = bsts;
            groupBox2.Enabled = bsts;
            groupBox1.Visible = bsts;
        }

        public void DisplayNowPlateNum(int NowPlateNum)
        {
            this.BeginInvoke(new Action(() =>
            {
                this.tb_NewPlateNum.Text = NowPlateNum.ToString();
            }));
        }
        public void CIMMainForm_EqpStatusChange()
        {
            //上传设备状态信息
            cIMMainClass.variableMap.CtLToBC_EqpStatusTask(cIMMainClass.controlVCR.R_EqpStatus(),  VariableMap.waitTime);
        }

        /// <summary>
        /// 显示BC在线与否
        /// </summary>
        /// <param name="state"></param>
        public void BCStateDispaly(bool state)
        {
            this.BeginInvoke(new Action(() =>
            {
                if((!state)&&( (btn_CIMAlive.Text == "CIM在线")))
                {
                    MsgBoxOutput("BC离线！");
                    TextBoxOutput("BC离线！");
                }
                
            }));
        }
        public void CloseForm()
        {
            Application.Exit();
        }
        #region Log
        private void MsgBoxOutput(string msg)
        {
            this.BeginInvoke(new Action(() =>
            {
                MessageBoxTimeOut mb = new MessageBoxTimeOut();
                mb.Show(1500,msg,"报警");
            }));
        }
        private void TextBoxOutput(string msg)
        {
            this.BeginInvoke(new Action(() =>
            {
                lb_LogMessageOutput.Items.Add(cIMMainClass.GetLogSystemTime() + msg);
                //lb_LogMessageOutput.BackColor = Color.GhostWhite;
                lb_LogMessageOutput.TopIndex = this.lb_LogMessageOutput.Items.Count - (int)(this.lb_LogMessageOutput.Height / this.lb_LogMessageOutput.ItemHeight);
            }));
        }
        public void BCAlarmMessageOutput(string msg)
        {
            this.BeginInvoke(new Action(() =>
            {
                lb_BCAlarmMessageOutput.Items.Add(cIMMainClass.GetLogSystemTime() + msg);
                //lb_BCAlarmMessageOutput.BackColor = Color.DarkRed;
                lb_BCAlarmMessageOutput.TopIndex = this.lb_BCAlarmMessageOutput.Items.Count - (int)(this.lb_BCAlarmMessageOutput.Height / this.lb_BCAlarmMessageOutput.ItemHeight);
            }));
        }
        #endregion
        //记录报修流程
        public void getEqpRepairFlow(EqpRepairForm.EqpRepairFlow eqpRepairFlow)
        {
            this.eqpRepairFlow = eqpRepairFlow;
        }
        public void M_BCRDispaly()
        {
            if (cIMMainClass.CIMparams.OfflineMode)
                return;
            this.BeginInvoke(new Action(delegate
            {
                if (cIMMainClass.controlBCR.queueInTrayID.Count == 0)
                {
                    SetNowTrayTestState("NT");
                    tb_NowTrayID.Text = "";
                    tb_WorkOrderID.Text = "";
                    tb_RecipeID.Text = "";
                    tb_SetPlateNum.Text = "";
                    tb_NewPlateNum.Text = "";
                }
                else if (cIMMainClass.controlBCR.queueInTrayID.Count == 1)
                {
                    SetNowTrayTestState("OK");
                    SetNextTrayTestState("NT");
                    tb_NextTrayID.Text = "";
                    cIMMainClass.CIMparams.NowTrayID = cIMMainClass.CIMparams.NextTrayID;
                    cIMMainClass.CIMparams.NowWorkOrderID = cIMMainClass.CIMparams.NextWorkOrderID;
                    cIMMainClass.CIMparams.NowRecipeID = cIMMainClass.CIMparams.NextRecipeID;
                    cIMMainClass.CIMparams.NowSetPlateNum = cIMMainClass.CIMparams.NextSetPlateNum;
                    cIMMainClass.CIMparams.NowPlateNum = cIMMainClass.CIMparams.NowSetPlateNum;

                    cIMMainClass.CIMparams.NextTrayID = "";
                    cIMMainClass.CIMparams.NextWorkOrderID = "";
                    cIMMainClass.CIMparams.NextRecipeID = "";
                    cIMMainClass.CIMparams.NextSetPlateNum = 0;

                    tb_NowTrayID.Text = cIMMainClass.CIMparams.NowTrayID;
                    tb_WorkOrderID.Text = cIMMainClass.CIMparams.NowWorkOrderID;
                    tb_RecipeID.Text = cIMMainClass.CIMparams.NowRecipeID;//产品型号
                    tb_SetPlateNum.Text = cIMMainClass.CIMparams.NowSetPlateNum.ToString();
                    tb_NewPlateNum.Text = cIMMainClass.CIMparams.NowPlateNum.ToString();//当前盘数
                }
                cIMMainClass.CIMparams.SavePrm();
                ele1.Save(file_B);
            }
            ));
        }
        public void BCRDispaly(string RstrTrayID, int TrayRTCode, string WorkOrderID, int Quantity,string RecipeID)
        {
            this.BeginInvoke(new Action(delegate
            {
                if (TrayRTCode == 0)
                {
                    if (cIMMainClass.controlBCR.queueInTrayID.Count == 2)
                    { 
                        TextBoxOutput("2-TrayID验证OK");
                        SetNextTrayTestState("OK");
                        tb_NextTrayID.Text = RstrTrayID;
                        tb_WorkOrderID.Text = cIMMainClass.CIMparams.NowWorkOrderID;
                        cIMMainClass.CIMparams.NextSetPlateNum = (Quantity / 6);
                        cIMMainClass.CIMparams.NextWorkOrderID = WorkOrderID;
                        cIMMainClass.CIMparams.NextRecipeID = RecipeID;
                        cIMMainClass.CIMparams.NextTrayID = RstrTrayID;
                    }
                    else if (cIMMainClass.controlBCR.queueInTrayID.Count == 1)
                    {
                        TextBoxOutput("1-TrayID验证OK");
                        SetNowTrayTestState("OK");
                        tb_NowTrayID.Text = RstrTrayID;
                        tb_WorkOrderID.Text = WorkOrderID;
                        tb_SetPlateNum.Text = (Quantity / 6).ToString();
                        tb_NewPlateNum.Text = (Quantity / 6).ToString();//当前盘数
                        tb_RecipeID.Text = cIMMainClass.CIMparams.NowRecipeID;//产品型号
                        cIMMainClass.CIMparams.NowSetPlateNum = (Quantity / 6);
                        cIMMainClass.CIMparams.NowWorkOrderID = WorkOrderID;
                        cIMMainClass.CIMparams.NowTrayID = RstrTrayID;
                        cIMMainClass.CIMparams.NowRecipeID = RecipeID;
                    }
                    cIMMainClass.CIMparams.SavePrm();

                    //只要对配置文件做了写入动作，则在此时将配置全部写入到备份配置文件
                    //备份的文件
                    ele1.Save(file_B);

                }
                else
                {
                    ToolSet.Log.Info("判定值TrayRTCode" + TrayRTCode.ToString());
                    if (TrayRTCode == 1)
                    { 
                        TextBoxOutput("TrayID验证NG，请重新扫描流程单！！");                        
                    }
                    if (TrayRTCode == 2)
                    {
                        TextBoxOutput("TrayID --- BC端trayID回复异常，请查看对面机台是否有此报警，\r\n" +
                            "如果有请联系CIM部门，没有请重启CIM软件！！");
                    }
                    if (cIMMainClass.controlBCR.queueInTrayID.Count == 1)
                    {
                        SetNextTrayTestState("NG");
                    }
                    else if (cIMMainClass.controlBCR.queueInTrayID.Count == 0)
                    {
                        SetNowTrayTestState("NG");
                    }
               }
            }
            ));
        }
        //BCR显示加发送
        public void BCRDispaly(object sender, EventArgs e)
        {
            if (cIMMainClass.CIMparams.OfflineMode)
                return;
            this.Invoke(new Action(delegate
            {
                if (cIMMainClass.controlBCR.queueInTrayID.Count == 0)
                {
                    SetNowTrayTestState("NT");
                    tb_NowTrayID.Text = Encoding.UTF8.GetString(cIMMainClass.controlBCR.AllData.ToArray());
                }
                else
                {
                    if (cIMMainClass.controlBCR.queueInTrayID.Count == 1)
                    {
                        SetNextTrayTestState("NT");
                        tb_NextTrayID.Text = Encoding.UTF8.GetString(cIMMainClass.controlBCR.AllData.ToArray());
                    }
                }
               cIMMainClass.addDataToSQLite("", Encoding.UTF8.GetString(cIMMainClass.controlBCR.AllData.ToArray()));
            }
            ));
        }



        public void SetPanelTestState(string str1,string str2,string str3,string str4,string str5 = "NT", string str6 = "NT")
        {
            Dictionary<string, Color> dictcolor = new Dictionary<string, Color>();
            dictcolor.Add("NG", Color.Red);
            dictcolor.Add("NT", Color.Yellow);
            dictcolor.Add("OK", Color.Green);
            lb_panelOneState.Text = str1;
            lb_panelTwoState.Text = str2;
            lb_panelThreeState.Text = str3;
            lb_panelFourState.Text = str4;
            lb_panelFiveState.Text = str5;
            lb_panelSixState.Text = str6;

            lb_panelOneState.BackColor = dictcolor[str1];
            lb_panelTwoState.BackColor = dictcolor[str2];
            lb_panelThreeState.BackColor = dictcolor[str3];
            lb_panelFourState.BackColor = dictcolor[str4];
            lb_panelFiveState.BackColor = dictcolor[str5];
            lb_panelSixState.BackColor = dictcolor[str6];
        }
        public void SetNowTrayTestState(string str)
        {
            Dictionary<string, Color> dictcolor = new Dictionary<string, Color>();
            dictcolor.Add("NG", Color.Red);
            dictcolor.Add("NT", Color.Yellow);
            dictcolor.Add("OK", Color.Green);
            lb_NowTrayState.Text = str;
            lb_NowTrayState.BackColor = dictcolor[str];
        }

        public void SetNextTrayTestState(string str)
        {
            Dictionary<string, Color> dictcolor = new Dictionary<string, Color>();
            dictcolor.Add("NG", Color.Red);
            dictcolor.Add("NT", Color.Yellow);
            dictcolor.Add("OK", Color.Green);
            lb_NextTrayState.Text = str;
            lb_NextTrayState.BackColor = dictcolor[str];
        }

        public void VCRDispaly(bool []check)
        {
            this.BeginInvoke(new Action(delegate
            {
                ToolSet.Log.Info(string.Format("VCR读码数据显示及存储...check={0}", check[0]));
                string[] strState = new string[6];
                for (int i = 0; i < 6; i++)
                {
                    if (check[i])
                    {
                        strState[i] = "OK";
                    }
                    else
                    {
                        strState[i] = "NG";
                    }
                }
                SetPanelTestState(strState[0], strState[1], strState[2], strState[3], strState[4], strState[5]);
                string TrayID = "";
                if (this.cIMMainClass.controlBCR.queueInTrayID.Count != 0)
                {
                    TrayID = this.cIMMainClass.controlBCR.queueInTrayID.Peek();
                }
                //添加panelID数据到数据库,重复的不添加
                foreach (string PanelID in cIMMainClass.controlVCR.StationPanelID)
                {
                    if (PanelID == "")
                    {
                        ToolSet.Log.Info("VCR读码数据为空");
                        continue;
                    }
                    cIMMainClass.addDataToSQLite(PanelID, TrayID);
                }
            }
             )); 
            
        }
        /// <summary>
        /// 显示读取成功率
        /// </summary>
        public void DispalyReadOKRate()
        {
            this.Invoke(new Action(delegate
            {

                //cIMMainClass.CIMparams.ReadPrm();
                this.tb_ReadCodeOKRate.Text = (((cIMMainClass.CIMparams.ReadOKNum * 1.0) / ((cIMMainClass.CIMparams.ReadOKNum + cIMMainClass.CIMparams.ReadNGNum) * 1.0))*100).ToString("0.00");
                this.tb_ReadCodeOKNum.Text = cIMMainClass.CIMparams.ReadOKNum.ToString();
                this.tb_ReadCodeNGNum.Text = cIMMainClass.CIMparams.ReadNGNum.ToString();
            }
            )); 
        }

        //VCR读取成功后，在界面上显示六个工位的panelID
        public void VCRDispaly()
        { 
            this.Invoke(new Action(delegate
            {
                 //cIMMainClass.CIMparams.ReadPrm();
                cIMMainClass.CIMparams.ReadOKNum = cIMMainClass.CIMparams.ReadOKNum + cIMMainClass.controlVCR.StationNumber;
                cIMMainClass.CIMparams.DayReadOKNum = cIMMainClass.CIMparams.DayReadOKNum + cIMMainClass.controlVCR.StationNumber;

                //cIMMainClass.CIMparams.SavePrm();  
                DispalyReadOKRate();
                SetPanelTestState("NT", "NT", "NT", "NT", "NT", "NT");//未对比状态
                ftb_NewPanelIDOne.Text = cIMMainClass.controlVCR.StationPanelID[0];
                tb_NewPanelIDTwo.Text = cIMMainClass.controlVCR.StationPanelID[1];
                tb_NewPanelIDThree.Text = cIMMainClass.controlVCR.StationPanelID[2];
                tb_NewPanelIDFour.Text = cIMMainClass.controlVCR.StationPanelID[3];
                tb_NewPanelIDFive.Text = cIMMainClass.controlVCR.StationPanelID[4];
                tb_NewPanelIDSix.Text = cIMMainClass.controlVCR.StationPanelID[5]; 
            }
            ));
            DayReadCodeSave();
         
        }
        private void CIMMainForm_Load(object sender, EventArgs e)
        {
            //获取当前活动进程的模块名称
            string moduleName = Process.GetCurrentProcess().MainModule.ModuleName;
            //返回指定路径字符串的文件名
            string processName = System.IO.Path.GetFileNameWithoutExtension(moduleName);
            //根据文件名创建进程资源数组
            Process[] processes = Process.GetProcessesByName(processName);
            //如果该数组长度大于1，说明多次运行
            if (processes.Length > 1)
            {
                MessageBox.Show("本程序一次只能运行一个实例！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);//弹出提示信息
                this.Close();//关闭当前窗体
            }
            else
            {
                if(!cIMMainClass.CIMparams.OutLineDefine)
                {
                    btn_CIMAlive_Click(null, null);
                }
                else
                {
                    CIMOffLine();
                }
            }
        }
        //VCR串口
        private void cmb_VCRPort_Click(object sender, EventArgs e)
        {
            cmb_VCRPort.Items.Clear();
            cmb_VCRPort.Items.AddRange(cIMMainClass.controlVCR.GetPortNames());
            if (cmb_VCRPort.Items.Count > 0)
            {
                cmb_VCRPort.SelectedIndex = 0;
            }
        }
        private void cmb_BCRPort_Click(object sender, EventArgs e)
        {
            cmb_BCRPort.Items.Clear();
            cmb_BCRPort.Items.AddRange(cIMMainClass.controlVCR.GetPortNames());
            if (cmb_BCRPort.Items.Count > 0)
            {
                cmb_BCRPort.SelectedIndex = 0;
            }
        }
        /// <summary>
        /// 连接VCR
        /// </summary>
        /// <param name="VCRPort"></param>
        private void ConnectVCR(string VCRPort)
        {

            bool Flag = true;
            try
            {
                Flag = cIMMainClass.controlVCR.Switch(VCRPort, 115200);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (Flag == true)
            {
                cmb_VCRPort.Text = VCRPort;
                cmb_VCRPort.Enabled = false;
                btn_ConnectVCR.Text = "已连接VCR";
                btn_ConnectVCR.BackColor = Color.Green;
                btn_ConnectVCR.Enabled = false;
            }
            else
            {
                cmb_VCRPort.Enabled = true;
                btn_ConnectVCR.Text = "已断开VCR";
                btn_ConnectVCR.BackColor = Color.Red;
            }                       
        }

        private void ConnectBCR(string BCRPort)
        {
            bool Flag = true;
            try
            {
                Flag = cIMMainClass.controlBCR.Switch(BCRPort, 9600);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (Flag == true)
            {
                cmb_BCRPort.Text = BCRPort;
                cmb_BCRPort.Enabled = false;
                btn_ConnectBCR.Text = "已连接BCR";
                btn_ConnectBCR.BackColor = Color.Green;
                btn_ConnectBCR.Enabled = false;
            }
            else
            {
                cmb_BCRPort.Enabled = true;
                btn_ConnectBCR.Text = "已断开BCR";
                btn_ConnectBCR.BackColor = Color.Red;
            }
        }
        //连接VCR串口
        private void btn_ConnectVCR_Click(object sender, EventArgs e) 
        {
            if (cmb_VCRPort.Items.Count <= 0)
            {
                MessageBox.Show("没有发现串口,请检查线路！");
                return;
            }
            ConnectVCR(cmb_VCRPort.SelectedItem.ToString());
         }
        private void btn_ConnectBCR_Click(object sender, EventArgs e)  
        {
            if (cmb_BCRPort.Items.Count <= 0)
            {
                MessageBox.Show("没有发现串口,请检查线路！");
                return;
            }
            ConnectBCR(cmb_BCRPort.SelectedItem.ToString());
        }
        public void CIMOffLine()
        {
            if (cIMMainClass.CIMparams.OfflineMode)
                return;

            cIMMainClass.variableMap.BitOffAllTagValue();//off所有变量
            this.check_LotUnlimited.Enabled = false;
            cIMMainClass.variableMap.CtLToBC_CIMMode(false);
            cIMMainClass.variableMap.CtLToBC_EqpAlive(false);
            cIMMainClass.variableMap.WindowHandle(this.Handle);//最关键的一步
            btn_CIMAlive.Text = "CIM离线";
            ToolSet.Log.Info("CIM离线,所有CIM通信已中断");
            TextBoxOutput("CIM离线,所有CIM通信已中断");
            //check_PLC_CIMSwitch.Checked = false;
            btn_CIMAlive.BackColor = Color.Red;
        }
        
        //CIM状态
        private void btn_CIMAlive_Click(object sender, EventArgs e)
        {
            if (cIMMainClass.CIMparams.OfflineMode)
                return;
           
            try
            {                
                if (btn_CIMAlive.Text == "CIM离线")
                {
                    //关闭CIM离线后的计时
                    m_timerWaterTank.Stop();
                    this.check_PLC_CIMSwitch.Enabled = false;
                    cIMMainClass.variableMap.BitOffAllTagValue();//off所有变量
                    this.check_LotUnlimited.Enabled = true;
                    cIMMainClass.variableMap.CtLToBC_CIMMode(true);
                    cIMMainClass.variableMap.CtLToBC_EqpAlive(true);
                    cIMMainClass.variableMap.WindowHandle(this.Handle);//最关键的一步
                    btn_CIMAlive.Text = "CIM在线";
                    ToolSet.Log.Info("CIM在线");
                    btn_CIMAlive.BackColor = Color.Green;
                    check_PLC_CIMSwitch.Checked = true;
                    if(EqpStatusChange != null)
                    {
                        EqpStatusChange.BeginInvoke(null, null);
                    }
                }
                else if (btn_CIMAlive.Text == "CIM在线")
                {
                    
                    if (this.tb_ReadCodeOKNum.Visible == false)
                    {
                        MessageBox.Show("你没有权限操作CIM离线！");
                        this.check_PLC_CIMSwitch.Enabled = false;
                        return;
                    }
                    //此处添加计时弹窗，时长开放出来
                    
                    m_timerWaterTank.Start();
                    this.check_PLC_CIMSwitch.Enabled = true;
                    string file_B = Path.Combine(".\\params", "CIMConfig_beifen");
                    File.Delete(file_B);
                    if (this.cIMMainClass.controlVCR.ReadCodeFlow == false)
                    {
                        CIMOffLine();
                        this.cIMMainClass.controlVCR.CIMswitch = false;  
                    }
                    else
                    {
                        this.cIMMainClass.controlVCR.CIMswitch = true;       
                    }
                    //两种状态：1、读码交互过程中 2、非读码交互过程
                }
            }
            catch(Exception)
            {
                cIMMainClass.variableMap.Dipose();
            }
        }

        private void m_timerWaterTank_Tick(object sender, EventArgs e)
        {
            MsgBoxOutput("CIM手动离线中！！！");
            TextBoxOutput("CIM手动离线中！！！"); 
        }
        //拔片成功
        public void RemoveDownPanel(bool[] CheckRemoveStation)
        {
            for (int i = 0; i < cIMMainClass.controlVCR.StationNumber; i++)
            {
                if (CheckRemoveStation[i])
                {
                    cIMMainClass.variableMap.CtLToBC_PanelRemoveTask(cIMMainClass.controlVCR.LastStationPanelID[i], VariableMap.waitTime);
                    Thread.Sleep(1000);
                }
            }
        }
        //VCR开关
        private void check_PLC_CIMSwitch_CheckedChanged(object sender, EventArgs e)
        {
            cIMMainClass.controlVCR.W_CIMSwitchForPLC(check_PLC_CIMSwitch.Checked);
            if (check_PLC_CIMSwitch.Checked)
            {
                check_PLC_CIMSwitch.BackColor = Color.Green;
            }
            else
            {
                check_PLC_CIMSwitch.BackColor = Color.Red;
            }
        }
        //无限上报
        private void check_LotUnlimited_CheckedChanged(object sender, EventArgs e)
        {
            cIMMainClass.controlVCR.LotUnlimited = check_LotUnlimited.Checked;
        }

        private void CIMMainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            #region
            //ToolSet.Log.Info("点击关闭按钮！！！");
            //if (this.tb_ReadCodeOKNum.Visible == false)
            //{
            //    MessageBox.Show("你没有权限关闭软件！");
            //    e.Cancel = true;
            //    return;
            //}
            //ToolSet.Log.Info("确定退出！！！");
            //cIMMainClass.CIMparams.SavePrm();
            //this.check_LotUnlimited.Enabled = false;
            //cIMMainClass.variableMap.CtLToBC_CIMMode(false);
            //cIMMainClass.variableMap.CtLToBC_EqpAlive(false);
            ////LH
            ////cIMMainClass.variableMap.WindowHandle(this.Handle);//最关键的一步
            //btn_CIMAlive.Text = "CIM离线";
            //TextBoxOutput("CIM离线,所有CIM通信已中断");
            //check_PLC_CIMSwitch.Checked = false;
            //btn_CIMAlive.BackColor = Color.Red;
            //cIMMainClass.controlVCR.W_CIMSwitchForPLC(false);
            //DialogResult dr;
            //dr = MessageBox.Show("确定要退出吗？", "提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            //if (dr == DialogResult.OK)
            //{
            //    try
            //    {
            //        //File.Delete(Path.Combine(".\\params", "CIMConfig_beifen"));
            //        cIMMainClass.variableMap.Close();
            //        cIMMainClass.controlVCR.Close();
            //        cIMMainClass.controlBCR.ClearSelf();
            //        cIMMainClass.cutSoftwareCommunication.Close();
            //        //Application.Exit();
            //        //获取所有进程
            //        Process[] processIdAry = Process.GetProcessesByName("CIM通讯");
            //        //如果有这个进程运行那么就是
            //        if (processIdAry.Length > 0)
            //        {
            //            MessageBox.Show("程序关闭，请重新开启CIM软件！！！");
            //            ToolSet.Log.Info("程序关闭，请重新开启CIM软件！！！");
            //            for (int i = 0; i < processIdAry.Length; i++)
            //            {
            //                for (int j = 0; j < processIdAry[i].Threads.Count; j++)
            //                {
            //                    processIdAry[i].Threads[j].Dispose();
            //                    ToolSet.Log.Info("第" + j + "个线程关闭！");
            //                }
            //                processIdAry[i].Kill();
            //                ToolSet.Log.Info("第" + i + "个程序的ID:" + processIdAry[i].Id + "关闭！");
            //            }
            //        }
            //        else
            //        {
            //            ToolSet.Log.Info("这个进程没有运行");
            //        }
            //        e.Cancel = false;
            //    }
            //    catch
            //    {
            //        Console.WriteLine("无法关闭此进程！");
            //        ToolSet.Log.Info("无法关闭此进程！");
            //    }
                ToolSet.Log.Info("程序关闭！");
            //}
            //else
            //{
            //    e.Cancel = true;
            //}
            #endregion
        }
        //自动跳过NG片
        private void check_AutoJumpNG_CheckedChanged(object sender, EventArgs e)
        {
            cIMMainClass.controlVCR.checkAutoJumpNG = this.check_AutoJumpNG.Checked;
            if (this.check_AutoJumpNG.Checked)
            {
                this.check_PLC_CIMSwitch.Enabled = false;
            }
            else
            {
                this.check_PLC_CIMSwitch.Enabled = true;
            }
        }
        ////测试读码启动，是否进入后续事件
        //private void button4_Click(object sender, EventArgs e)
        //{
        //    //cIMMainClass.controlVCR.workStart();
        //    //#region 删除图片
        //    //DateTime dt = new DateTime();
        //    //dt = DateTime.Now;
        //    //string ImagePath = System.Environment.CurrentDirectory + "\\Image\\" + dt.Year.ToString() + "\\";
        //    //MessageBox.Show(ImagePath);
        //    //Cognex.DataMan.SDK.MainForm.DeleteImage(ImagePath);
        //    //#endregion

        //    //cIMMainClass.controlVCR.Test();
        //    //cIMMainClass.controlBCR.BCRReadOK("S91P202043G");
        //    //cIMMainClass.ReadBCDateTime("20190111103200");
        //    //cIMMainClass.controlVCR.CIMAlaram(true);
        //    this.BeginInvoke(new Action(delegate
        //    {
        //        cIMMainClass.variableMap.CtLToBC_TrayInfoRequestTask(VariableMap.waitTime, this.tb_NewTrayID.Text);
        //    }
        //  )); 
        //}
        //测试保存图片功能
        private void SaveImage(Image image)
        {
            DateTime dt = new DateTime();
            dt = DateTime.Now;
            String FileName = dt.ToString("yyyyMMddHHmmss");
            String ImageName = System.Environment.CurrentDirectory + "\\Image";
            String YearName = ImageName + "\\" + dt.Year.ToString();
            String MonthName =YearName + "\\" + dt.Month.ToString();
            String DayName = MonthName + "\\" + dt.Day.ToString();

            CreateDir(ImageName);//创建存放图片的文件夹
            CreateDir(YearName);//年
            CreateDir(MonthName);//月
            CreateDir(DayName);//日
            String FilePath = DayName + "\\" + FileName + ".bmp";
            image.Save(FilePath);
        }
        private void CreateDir(string subdir)
        {
            string path = subdir;
            if (Directory.Exists(path))
            {
                Console.WriteLine("此文件夹已经存在，无需创建！");
            }
            else
            {
                Directory.CreateDirectory(path);
                Console.WriteLine(path + " 创建成功!");
            }
        }
        //PLC报警信息
        private void AlarmTimer_Tick(object sender, EventArgs e)
        {
            ////只要当设备状态为Run时
            //bool stateRun = false;
            //BeckhoffRW.ReadPlcVariable(".boGreenLight", ref stateRun);
            //if (stateRun)
            //{
            //    b_PM.Visible = false;
            //    b_MC.Visible = false;
            //}
            //else
            //{
            //    b_PM.Visible = true;
            //    b_MC.Visible = true;
            //}
            TimeSpan ts = DateTime.Now - ToolStripdTime;
            if (ToolStripdTime != DateTime.Now.Date && ts.TotalSeconds > 300)//登录之后，300s/五分钟以后关闭
            {
                DisabledForm();
                ToolStripdTime = DateTime.Now.Date;
            }

        }
        public void theout(object source, System.Timers.ElapsedEventArgs e)
        {
            
            MessageBox.Show("OK!");
        }
        DateTime ToolStripdTime = DateTime.Now.Date;
        private void 登录ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LockSwitchForm lockSwitchForm = new LockSwitchForm(cIMMainClass.CIMparams.SystemKey);
            lockSwitchForm.Show();
            lockSwitchForm.ss(true);
            
        }
        
        private void DisabledForm()
        {
            this.tb_NowTrayID.Enabled = false;
            this.tb_NextTrayID.Enabled = false;
            this.check_LotUnlimited.Enabled = false;
            this.手动上传LotIDToolStripMenuItem.Enabled = false;
            this.参数设置ToolStripMenuItem1.Enabled = false;
            this.重连TCPToolStripMenuItem.Enabled = false;
           // groupBox1.Visible = false;
            this.check_AutoJumpNG.Visible = false;
            this.tb_ReadCodeNGNum.Visible = false;
            this.tb_ReadCodeOKNum.Visible = false;
            this.tb_ReadCodeOKRate.Visible = false;
            this.label13.Visible = false;
            this.label15.Visible = false;
            this.label14.Visible = false;
            this.label16.Visible = false;
            //this.check_PLC_CIMSwitch.Enabled = false;
            this.ClearLotID.Visible = false;
            this.Clear_ReadCode.Visible = false;

            this.b_PM.Visible = false;
            this.b_MC.Visible = false;
            this.btn_CIMAlive.Enabled = false;

            this.登出ToolStripMenuItem.Enabled = false;
            this.登录ToolStripMenuItem.Enabled = true;
        }
        public void EnabledForm()
        {
            this.tb_NowTrayID.Enabled = true;
            this.tb_NextTrayID.Enabled = true;
            this.check_LotUnlimited.Enabled = true;
            this.手动上传LotIDToolStripMenuItem.Enabled = true;
            this.参数设置ToolStripMenuItem1.Enabled = true;
            this.重连TCPToolStripMenuItem.Enabled = true;
           // groupBox1.Visible = true;
            //this.check_AutoJumpNG.Visible = true;
            this.tb_ReadCodeNGNum.Visible = true;
            this.tb_ReadCodeOKNum.Visible = true;
            this.tb_ReadCodeOKRate.Visible = true;
            this.label13.Visible = true;
            this.label15.Visible = true;
            this.label14.Visible = true;
            this.label16.Visible = true;
            //this.check_PLC_CIMSwitch.Enabled = true;
            this.登出ToolStripMenuItem.Enabled = true;
            this.登录ToolStripMenuItem.Enabled = false;
            this.ClearLotID.Visible = true;
            this.Clear_ReadCode.Visible = true;

            this.b_PM.Visible = true;
            this.b_MC.Visible = true;
            this.btn_CIMAlive.Enabled = true;
            ToolStripdTime = DateTime.Now;

        }

        private void 登出ToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            DisabledForm();
        }
        //测试读码启动，是否进入后续事件
        private void button2_Click_2(object sender, EventArgs e)
        {
            //手动上传
            TextBoxOutput("等待上传....");
            this.BeginInvoke(new Action(delegate
            {
                cIMMainClass.variableMap.CtLToBC_TrayInfoRequestTask(VariableMap.waitTime, this.tb_NowTrayID.Text);
            }
          ));
            TextBoxOutput("上传完毕....");
        }

        private void 参数设置ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void 参数设置ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ParamsSetForm paramsSetForm = new ParamsSetForm(cIMMainClass.CIMparams);
            if(paramsSetForm.ShowDialog() == DialogResult.OK)
            {
                MessageBox.Show("参数设置成功，重启CIM软件后生效！");
            }
        }

        private void 重连TCPToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cIMMainClass.cutSoftwareCommunication.Connected();
        }

        private void 上报TTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cIMMainClass.cutSoftwareCommunication.GetTactTime();
        }

        private void 上报产能ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cIMMainClass.cutSoftwareCommunication.GetCapacityInfo();
        }

        private void 换班清产能ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cIMMainClass.cutSoftwareCommunication.ClearCapacityInfo();
        }

        private void 手动上传LotIDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (cIMMainClass.CIMparams.OfflineMode)
                return;
            //手动上传
            TextBoxOutput("等待上传....");
            //  this.BeginInvoke(new Action(delegate
            //  {
            //      cIMMainClass.variableMap.CtLToBC_TrayInfoRequestTask(VariableMap.waitTime, this.tb_NowTrayID.Text);
            //  }
            //));
            //TextBoxOutput("上传完毕....");

            //LH
            string strNowTrayID = this.tb_NowTrayID.Text;
            Task task = new Task(new Action(() =>
            {
                cIMMainClass.variableMap.CtLToBC_TrayInfoRequestTask(VariableMap.waitTime, this.tb_NowTrayID.Text);
                TextBoxOutput("上传完毕....");
            }));
            task.Start();

        }

        private void 数据库ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.BeginInvoke(new Action(delegate
            {

                //SQLiteForm sQLiteForm = new SQLiteForm(cIMMainClass.LoadInfo());
                //SQLiteForm sQLiteForm = new SQLiteForm(list);
                //sQLiteForm.ShowDialog();
            }
         ));
        }

        private void 保修ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (cIMMainClass.CIMparams.OfflineMode)
                return;
            EqpRepairForm eqpRepairForm = new EqpRepairForm(cIMMainClass, this.eqpRepairFlow);
            eqpRepairForm.ShowDialog();
        }

        private void 重新读码ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("确定拔片完成？需要再一次启动读码流程？", "警告", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if (dr == DialogResult.OK)
            {
                cIMMainClass.controlVCR.W_ReStartVCR(true);
                cIMMainClass.controlVCR.CIMAlaram(false);//清除报警
                cIMMainClass.controlVCR.W_StopFeedAndFinish(false);
            }
            else
            {
                cIMMainClass.controlVCR.W_ReStartVCR(false);
            }
        }

        private void 手动拔片ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (cIMMainClass.CIMparams.OfflineMode)
                return;

            if (check_StationOne.Checked || this.check_StationTwo.Checked
                    || this.check_StationThree.Checked || this.check_StationFour.Checked
                    || this.check_StationFive.Checked || this.check_StationSix.Checked)
                {
                    string q = "";
                    if (check_StationOne.Checked)
                    {
                        q = q + "第1工位\r\n";
                    }
                    if (check_StationTwo.Checked)
                    {
                        q = q + "第2工位\r\n";
                    }
                    if (check_StationThree.Checked)
                    {
                        q = q + "第3工位\r\n";
                    }
                    if (check_StationFour.Checked)
                    {
                        q = q + "第4工位\r\n";
                    }
                    if (check_StationFive.Checked)
                    {
                        q = q + "第5工位\r\n";
                    }
                    if (check_StationSix.Checked)
                    {
                        q = q + "第6工位\r\n";
                    }
                    string str = string.Format("确认下料拔片工位勾选正确:\r\n" + q +"必须确认勾选的为NG品，不可流入下个工序！！！");
                    DialogResult dr = MessageBox.Show(str, "警告", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    if (dr == DialogResult.OK)
                    {
                        bool[] CheckRemoveStation = new bool[]{ this.check_StationOne.Checked,this.check_StationTwo.Checked,
                                                                this.check_StationThree.Checked,this.check_StationFour.Checked,
                                                                this.check_StationFive.Checked,this.check_StationSix.Checked };
                        CanRemveDownPanel.BeginInvoke(CheckRemoveStation, null, null);
                    }
                }
                else
                {
                    MessageBox.Show("请勾选要NG片的工位！！！");
                }
        }

        private void 手动上报ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 测试ToolStripMenuItem_Click(object sender, EventArgs e)
        {
   
        }

        private void 打开数据库ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //WriteTxtFile(cIMMainClass.LoadInfo());
            DataForm dlg = new DataForm(cIMMainClass);
            dlg.ShowDialog();
        }

        public void WriteTxtFile(List<CIMData> list)
        {
            string str = Path.Combine(".\\params", "VCRSQL.txt"); //写参数
            using (System.IO.StreamWriter file = new System.IO.StreamWriter(str, false))
            {
                foreach (CIMData line in list)
                {
                    file.WriteLine(line.Datatime + "    " + line.TrayID + "    " + line.PanelID + "    " +  line.RTCode);// 直接追加文件末尾，换行 
                }
            }

            System.Diagnostics.Process.Start("notepad.exe", str); 
        }

        private void 清除读码率_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("此操作会清空每日读码率和总的读码率", "警告", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if (dr == DialogResult.OK)
            {
                MessageBox.Show("数据清除成功！！！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cIMMainClass.CIMparams.DayReadNGNum = 0;
                cIMMainClass.CIMparams.DayReadOKNum = 0;
            }
            else
            {
                MessageBox.Show("总数读码清除成功/每日读码未清除！！！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                
                cIMMainClass.CIMparams.ReadNGNum = 0;
                cIMMainClass.CIMparams.ReadOKNum = 0;
            }
            cIMMainClass.CIMparams.SavePrm();
        }

        private void ClearLotID_Click(object sender, EventArgs e)
        {
            //清除LotID信息
            string file_B = Path.Combine(".\\params", "CIMConfig_beifen");
            File.Delete(file_B);

            cIMMainClass.CIMparams.NowTrayID = "";
            cIMMainClass.CIMparams.NextTrayID = "";
            cIMMainClass.CIMparams.NowWorkOrderID = "";
            cIMMainClass.CIMparams.NextWorkOrderID = "";
            cIMMainClass.CIMparams.NowRecipeID = "";
            cIMMainClass.CIMparams.NextRecipeID = "";

            tb_NowTrayID.Text = cIMMainClass.CIMparams.NowTrayID;
            tb_WorkOrderID.Text = cIMMainClass.CIMparams.NowWorkOrderID;
            tb_RecipeID.Text = cIMMainClass.CIMparams.NowRecipeID;
            cIMMainClass.CIMparams.SavePrm();
            cIMMainClass.CIMparams.ReadPrm();
        }
        
        //每日读码存储
        public void DayReadCodeSave()
        {
            DateTime dt = new DateTime();
            dt = DateTime.Now;
            String FileName = dt.ToString("yyyyMMddHHmmss");
            String CodeName = System.Environment.CurrentDirectory + "\\DayReadCode";
            String YearName = CodeName + "\\" + dt.Year.ToString();
            String MonthName = YearName + "\\" + dt.Month.ToString();
            String DayName = MonthName + "\\" + dt.Day.ToString();
            CreateDir(CodeName);//创建存放的文件夹
            CreateDir(YearName);//年
            CreateDir(MonthName);//月
            CreateDir(DayName);//日
            String FilePath = DayName + "\\" + ".log";
            bool b = Directory.Exists(FilePath);//此目录是否存在
            if (!b)
            {
                string FilePath_Day = MonthName + "\\" + (dt.Day - 1).ToString() + "\\" + ".log";
                try
                {
                    DirectoryInfo dyInfo = new DirectoryInfo(FilePath_Day);
                    //获取文件夹下所有的文件
                    DirectoryInfo info2 = dyInfo.Parent;
                    //FileInfo[] feInfo = dyInfo.GetFiles();
                    foreach (FileInfo feInfo in info2.GetFiles())
                    {
                        //判断文件日期是否小于今天，是则删除
                        if (feInfo.CreationTime < DateTime.Today)
                        {
                            cIMMainClass.CIMparams.DayReadOKNum = 0;
                            cIMMainClass.CIMparams.DayReadNGNum = 0;
                            cIMMainClass.CIMparams.SavePrm();

                        }
                    }
                }
                catch (Exception FileEx)
                {
                    //MessageBox.Show("读码文件路径无效,请查看"+ FilePath_Day+"文件是否存在！！！");
                    cIMMainClass.CIMparams.DayReadOKNum = 0;
                    cIMMainClass.CIMparams.DayReadNGNum = 0;
                    cIMMainClass.CIMparams.SavePrm();
                }
            }
            
            
            double DayReadCodeOKRate = (((cIMMainClass.CIMparams.DayReadOKNum * 1.0) / ((cIMMainClass.CIMparams.DayReadOKNum + cIMMainClass.CIMparams.DayReadNGNum) * 1.0)) * 100);
            File.WriteAllText(FilePath, "读码OK：" + cIMMainClass.CIMparams.DayReadOKNum.ToString() + "\r\n" +
            "读码NG：" + cIMMainClass.CIMparams.DayReadNGNum.ToString() + "\r\n" +
            "读码成功率：" + DayReadCodeOKRate.ToString());

        }
        public void TimerDayReadCode(object source, System.Timers.ElapsedEventArgs e)
        {
            DayReadCodeSave();
        }
       
        #region 鼠标点击事件
        
        private void CIMMainForm_MouseClick(object sender, MouseEventArgs e)
        {
            ToolStripdTime = DateTime.Now;
        }

        private void Btn_CIMAlive_MouseClick(object sender, MouseEventArgs e)
        {
            ToolStripdTime = DateTime.Now;
        }

        private void Check_PLC_CIMSwitch_MouseClick(object sender, MouseEventArgs e)
        {
            ToolStripdTime = DateTime.Now;
        }

        private void Check_AutoJumpNG_MouseClick(object sender, MouseEventArgs e)
        {
            ToolStripdTime = DateTime.Now;
        }

        private void 用户登录ToolStripMenuItem_MouseDown(object sender, MouseEventArgs e)
        {
            ToolStripdTime = DateTime.Now;
        }

        private void 数据库ToolStripMenuItem_MouseDown(object sender, MouseEventArgs e)
        {
            ToolStripdTime = DateTime.Now;
        }

        private void 参数设置ToolStripMenuItem_MouseDown(object sender, MouseEventArgs e)
        {
            ToolStripdTime = DateTime.Now;
        }

        private void 手动上报ToolStripMenuItem_MouseDown(object sender, MouseEventArgs e)
        {
            ToolStripdTime = DateTime.Now;
        }
        #endregion

        //维护、保养类计时
        //按钮点击之后开始记时长，在运行状态，PM和MC是不能点击的
        public bool Time_b = false;
        private void Button1_Click(object sender, EventArgs e)
        {
            if (!Time_b)
            {
                //1.点击之后，按钮变红
                b_PM.BackColor = Color.Red;
                //2.计时开始
                cIMMainClass.DataTime_start(ref Time_b,"PM");
                //当使用PM按钮时，MC按钮可见但不能点击
                b_MC.Enabled = false;
                return;
            }
            //3.当有一个条件成立时
            //4.按钮变绿
            b_PM.BackColor = Color.Green;
            //5.计时停止
            cIMMainClass.DataTime_stop(ref Time_b,"PM");
            b_MC.Enabled = true;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            //cIMMainClass.addDataToSQLite("1234","5678");
            //测试（多次）获取VCR读码信息
            //cIMMainClass.controlVCR.RMany_ReadVCR(1);
            if (!Time_b)
            {
                //1.点击之后，按钮变红
                b_MC.BackColor = Color.Red;
                //2.计时开始
                cIMMainClass.DataTime_start(ref Time_b,"MC");
                b_PM.Enabled = false;
                return;
            }
            //3.当有一个条件成立时
            //4.按钮变绿
            b_MC.BackColor = Color.Green;
            //5.计时停止
            cIMMainClass.DataTime_stop(ref Time_b,"MC");
            b_PM.Enabled = true;
        }

        private void Button1_Click_1(object sender, EventArgs e)
        {
            //cIMMainClass.cutSoftwareCommunication.GetProcessData();
            //cIMMainClass.ReadCutSoftwareMsg("GetProcessData: ");
            cIMMainClass.PanelSendOut();
        }

        private void 清除lotToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string file_B = Path.Combine(".\\params", "CIMConfig_beifen");
            File.Delete(file_B);
        }
    }
}
