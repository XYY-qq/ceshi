﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ParamModule;

namespace CIM通讯
{
    public class CIMParams : Params
    {
      
        #region 内部数据、初始化
        private static string[] intPrmNames;
        private static string[] doublePrmNames;
        private static string[] stringPrmNames;
        private static string[] boolPrmNames;

        protected override string[] IntPrmNames
        {
            get
            {
                return intPrmNames;
            }
        }
        protected override string[] DoublePrmNames
        {
            get
            {
                return doublePrmNames;
            }
        }
        protected override string[] StringPrmNames
        {
            get
            {
                return stringPrmNames;
            }
        }
        protected override string[] BoolPrmNames
        {
            get
            {
                return boolPrmNames;
            }
        }
        static CIMParams()
        {
            intPrmNames = new string[] { "NowSetPlateNum", "NextSetPlateNum", "ReadOKNum", "ReadNGNum", "DayReadNGNum", 
                "DayReadOKNum", "dataSaveDays", "SQLitePanelNum", "NowPlateNum" , "m_iDataStartHour",
                "m_iDataStartMin","m_iOffLine" };
            doublePrmNames = new string[] { };
            stringPrmNames = new string[] { "NowTrayID", "NowWorkOrderID", "NextTrayID", "NextWorkOrderID", "NowRecipeID", "NextRecipeID", "UnitID", "Prefix", "SystemKey" };
            boolPrmNames = new string[] { "bCognexFlag", "OutLineDefine", "FourStationEnable","OfflineMode" };
        }
        public CIMParams(string file, string section)
            : base(file, section)
        {
            ReadPrm();
        }
        #endregion
        #region 参数列表 
        /// <summary>
        /// 是否使能康耐视的功能
        /// </summary>
        public bool bCognexFlag
        {
            get
            {
                return (bool)prmsHt["bCognexFlag"];
            }
            set
            {
                prmsHt["bCognexFlag"] = value;
            }
        }
        /// <summary>
        /// 读码NG次数
        /// </summary>
        public int ReadNGNum
        {
            get
            {
                return (int)prmsHt["ReadNGNum"];
            }
            set
            {
                prmsHt["ReadNGNum"] = value;
            }
        }
        
        ///每天的读码NG次数
        public int DayReadNGNum
        {
            get
            {
                return (int)prmsHt["DayReadNGNum"];
            }
            set
            {
                prmsHt["DayReadNGNum"] = value;
            }
        }

        ///每天的读码OK次数
        public int DayReadOKNum
        {
            get
            {
                return (int)prmsHt["DayReadOKNum"];
            }
            set
            {
                prmsHt["DayReadOKNum"] = value;
            }
        }

        /// <summary>
        /// 读码OK次数
        /// </summary>
        public int ReadOKNum
        {
            get
            {
                return (int)prmsHt["ReadOKNum"];
            }
            set
            {
                prmsHt["ReadOKNum"] = value;
            }
        }

        /// <summary>
        /// 数据保存天数
        /// </summary>
        public int dataSaveDays
        {
            get
            {
                return (int)prmsHt["dataSaveDays"];
            }
            set
            {
                prmsHt["dataSaveDays"] = value;
            }
        }
        /// <summary>
        /// 当前保存的信息数量
        /// </summary>
        public int SQLitePanelNum
        {
            get
            {
                return (int)prmsHt["SQLitePanelNum"];
            }
            set
            {
                prmsHt["SQLitePanelNum"] = value;
            }
        }
        public int NowSetPlateNum
        {
            get
            {
                return (int)prmsHt["NowSetPlateNum"];
            }
            set
            {
                prmsHt["NowSetPlateNum"] = value;
            }
        }

        public int NextSetPlateNum
        {
            get
            {
                return (int)prmsHt["NextSetPlateNum"];
            }
            set
            {
                prmsHt["NextSetPlateNum"] = value;
            }
        }
        //当前加工的工单还剩多少盘
        public int NowPlateNum
        {
            get
            {
                return (int)prmsHt["NowPlateNum"];
            }
            set
            {
                prmsHt["NowPlateNum"] = value;
            }
        }
        //设备的UnitID
        public string UnitID
        {
            get
            {
                return (string)prmsHt["UnitID"];
            }
            set
            {
                prmsHt["UnitID"] = value;
            }
        }

        //TrayID
        public string NowTrayID
        {
            get
            {
                return (string)prmsHt["NowTrayID"];
            }
            set
            {
                prmsHt["NowTrayID"] = value;
            }
        }

        public string NextTrayID
        {
            get
            {
                return (string)prmsHt["NextTrayID"];
            }
            set
            {
                prmsHt["NextTrayID"] = value;
            }
        }

        //工单号
        public string NowWorkOrderID
        {
            get
            {
                return (string)prmsHt["NowWorkOrderID"];
            }
            set
            {
                prmsHt["NowWorkOrderID"] = value;
            }
        }

        public string NextWorkOrderID
        {
            get
            {
                return (string)prmsHt["NextWorkOrderID"];
            }
            set
            {
                prmsHt["NextWorkOrderID"] = value;
            }
        }

        //产品型号
        public string NowRecipeID
        {
            get
            {
                return (string)prmsHt["NowRecipeID"];
            }
            set
            {
                prmsHt["NowRecipeID"] = value;
            }
        }

        public string NextRecipeID
        {
            get
            {
                return (string)prmsHt["NextRecipeID"];
            }
            set
            {
                prmsHt["NextRecipeID"] = value;
            }
        }
        //前缀
        public string Prefix
        {
            get
            {
                return (string)prmsHt["Prefix"];
            }
            set
            {
                prmsHt["Prefix"] = value;
            }
        }
        //管理员密码
        public string SystemKey
        {
            get
            {
                return (string)prmsHt["SystemKey"];
            }
            set
            {
                prmsHt["SystemKey"] = value;
            }
        }

        //默认CIM离线
        public bool OutLineDefine
        {
            get
            {
                return (bool)prmsHt["OutLineDefine"];
            }
            set
            {
                prmsHt["OutLineDefine"] = value;
            }
        }

        //四工位模式使能
        public bool FourStationEnable
        {
            get
            {
                return (bool)prmsHt["FourStationEnable"];
            }
            set
            {
                prmsHt["FourStationEnable"] = value;
            }
        }

        //脱机模式，不加载和客户服务器的通讯
        public bool OfflineMode
        {
            get
            {
                return (bool)prmsHt["OfflineMode"];
            }
            set
            {
                prmsHt["OfflineMode"] = value;
            }
        }
        #region 参数列表

        //起始时间
        public int m_iDataStartHour
        {
            get
            {
                return (int)prmsHt["m_iDataStartHour"];
            }
            set
            {
                prmsHt["m_iDataStartHour"] = value;
            }
        }

        public int m_iDataStartMin
        {
            get
            {
                return (int)prmsHt["m_iDataStartMin"];
            }
            set
            {
                prmsHt["m_iDataStartMin"] = value;
            }
        }
        //切割重复品，手动CIM离线弹窗时长，分钟
        public int m_iOffLine
        {
            get
            {
                return (int)prmsHt["m_iOffLine"];
            }
            set
            {
                prmsHt["m_iOffLine"] = value;
            }
        }

        #endregion
    }

    #endregion


}
