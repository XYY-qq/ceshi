﻿namespace CIM通讯
{
    partial class EqpRepairForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_CallOperatorID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_RepairOperatorID = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_EndOperatorID = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_EndTime = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_RepairStartTime = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tb_CallStartTime = new System.Windows.Forms.TextBox();
            this.btn_Call = new System.Windows.Forms.Button();
            this.btn_Repair = new System.Windows.Forms.Button();
            this.btn_End = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tb_CallOperatorID
            // 
            this.tb_CallOperatorID.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_CallOperatorID.Location = new System.Drawing.Point(201, 39);
            this.tb_CallOperatorID.MaxLength = 20;
            this.tb_CallOperatorID.Name = "tb_CallOperatorID";
            this.tb_CallOperatorID.Size = new System.Drawing.Size(126, 26);
            this.tb_CallOperatorID.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Control;
            this.label1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(90, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "操作员工号";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.Control;
            this.label2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(90, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "操作员工号";
            // 
            // tb_RepairOperatorID
            // 
            this.tb_RepairOperatorID.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_RepairOperatorID.Location = new System.Drawing.Point(201, 78);
            this.tb_RepairOperatorID.MaxLength = 20;
            this.tb_RepairOperatorID.Name = "tb_RepairOperatorID";
            this.tb_RepairOperatorID.Size = new System.Drawing.Size(126, 26);
            this.tb_RepairOperatorID.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.Control;
            this.label3.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(90, 118);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "操作员工号";
            // 
            // tb_EndOperatorID
            // 
            this.tb_EndOperatorID.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_EndOperatorID.Location = new System.Drawing.Point(201, 115);
            this.tb_EndOperatorID.MaxLength = 20;
            this.tb_EndOperatorID.Name = "tb_EndOperatorID";
            this.tb_EndOperatorID.Size = new System.Drawing.Size(126, 26);
            this.tb_EndOperatorID.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.Control;
            this.label4.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.Location = new System.Drawing.Point(399, 118);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 16);
            this.label4.TabIndex = 11;
            this.label4.Text = "修理结束时间";
            // 
            // tb_EndTime
            // 
            this.tb_EndTime.Enabled = false;
            this.tb_EndTime.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_EndTime.Location = new System.Drawing.Point(525, 115);
            this.tb_EndTime.MaxLength = 14;
            this.tb_EndTime.Name = "tb_EndTime";
            this.tb_EndTime.Size = new System.Drawing.Size(126, 26);
            this.tb_EndTime.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.Control;
            this.label5.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label5.Location = new System.Drawing.Point(399, 81);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 16);
            this.label5.TabIndex = 9;
            this.label5.Text = "修理开始时间";
            // 
            // tb_RepairStartTime
            // 
            this.tb_RepairStartTime.Enabled = false;
            this.tb_RepairStartTime.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_RepairStartTime.Location = new System.Drawing.Point(525, 78);
            this.tb_RepairStartTime.MaxLength = 14;
            this.tb_RepairStartTime.Name = "tb_RepairStartTime";
            this.tb_RepairStartTime.Size = new System.Drawing.Size(126, 26);
            this.tb_RepairStartTime.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.Control;
            this.label6.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label6.Location = new System.Drawing.Point(399, 42);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(104, 16);
            this.label6.TabIndex = 7;
            this.label6.Text = "叫修开始时间";
            // 
            // tb_CallStartTime
            // 
            this.tb_CallStartTime.Enabled = false;
            this.tb_CallStartTime.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_CallStartTime.Location = new System.Drawing.Point(525, 39);
            this.tb_CallStartTime.MaxLength = 14;
            this.tb_CallStartTime.Name = "tb_CallStartTime";
            this.tb_CallStartTime.Size = new System.Drawing.Size(126, 26);
            this.tb_CallStartTime.TabIndex = 6;
            // 
            // btn_Call
            // 
            this.btn_Call.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_Call.Location = new System.Drawing.Point(125, 212);
            this.btn_Call.Name = "btn_Call";
            this.btn_Call.Size = new System.Drawing.Size(101, 37);
            this.btn_Call.TabIndex = 12;
            this.btn_Call.Text = "叫修";
            this.btn_Call.UseVisualStyleBackColor = true;
            this.btn_Call.Click += new System.EventHandler(this.btn_Call_Click);
            // 
            // btn_Repair
            // 
            this.btn_Repair.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_Repair.Location = new System.Drawing.Point(292, 212);
            this.btn_Repair.Name = "btn_Repair";
            this.btn_Repair.Size = new System.Drawing.Size(101, 37);
            this.btn_Repair.TabIndex = 13;
            this.btn_Repair.Text = "修理";
            this.btn_Repair.UseVisualStyleBackColor = true;
            this.btn_Repair.Click += new System.EventHandler(this.btn_Repair_Click);
            // 
            // btn_End
            // 
            this.btn_End.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_End.Location = new System.Drawing.Point(462, 212);
            this.btn_End.Name = "btn_End";
            this.btn_End.Size = new System.Drawing.Size(101, 37);
            this.btn_End.TabIndex = 14;
            this.btn_End.Text = "完毕";
            this.btn_End.UseVisualStyleBackColor = true;
            this.btn_End.Click += new System.EventHandler(this.btn_End_Click);
            // 
            // EqpRepairForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(700, 278);
            this.Controls.Add(this.btn_End);
            this.Controls.Add(this.btn_Repair);
            this.Controls.Add(this.btn_Call);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tb_EndTime);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tb_RepairStartTime);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tb_CallStartTime);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tb_EndOperatorID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tb_RepairOperatorID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_CallOperatorID);
            this.Name = "EqpRepairForm";
            this.Text = "叫修界面";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_CallOperatorID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_RepairOperatorID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_EndOperatorID;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_EndTime;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_RepairStartTime;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tb_CallStartTime;
        private System.Windows.Forms.Button btn_Call;
        private System.Windows.Forms.Button btn_Repair;
        private System.Windows.Forms.Button btn_End;
    }
}