﻿namespace CIM通讯
{
    partial class ParamsSetForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_UnitID = new System.Windows.Forms.Label();
            this.tb_UnitID = new System.Windows.Forms.TextBox();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.btn_Save = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.cmb_Prefix = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_dataSaveDays = new System.Windows.Forms.TextBox();
            this.check_OutLineDefine = new System.Windows.Forms.CheckBox();
            this.check_FourStationEnable = new System.Windows.Forms.CheckBox();
            this.check_OfflineMode = new System.Windows.Forms.CheckBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Out_Int = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_UnitID
            // 
            this.lb_UnitID.AutoSize = true;
            this.lb_UnitID.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_UnitID.Location = new System.Drawing.Point(20, 88);
            this.lb_UnitID.Name = "lb_UnitID";
            this.lb_UnitID.Size = new System.Drawing.Size(47, 12);
            this.lb_UnitID.TabIndex = 38;
            this.lb_UnitID.Text = "UnitID:";
            // 
            // tb_UnitID
            // 
            this.tb_UnitID.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_UnitID.Location = new System.Drawing.Point(87, 89);
            this.tb_UnitID.Name = "tb_UnitID";
            this.tb_UnitID.Size = new System.Drawing.Size(85, 21);
            this.tb_UnitID.TabIndex = 37;
            // 
            // btn_cancel
            // 
            this.btn_cancel.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_cancel.Location = new System.Drawing.Point(155, 193);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(81, 28);
            this.btn_cancel.TabIndex = 41;
            this.btn_cancel.Text = "取消";
            this.btn_cancel.UseVisualStyleBackColor = true;
            this.btn_cancel.Click += new System.EventHandler(this.btn_cancel_Click);
            // 
            // btn_Save
            // 
            this.btn_Save.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_Save.Location = new System.Drawing.Point(50, 193);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(81, 28);
            this.btn_Save.TabIndex = 40;
            this.btn_Save.Text = "保存参数";
            this.btn_Save.UseVisualStyleBackColor = true;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(20, 120);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 12);
            this.label1.TabIndex = 43;
            this.label1.Text = "前缀:";
            // 
            // cmb_Prefix
            // 
            this.cmb_Prefix.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.cmb_Prefix.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cmb_Prefix.FormattingEnabled = true;
            this.cmb_Prefix.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.cmb_Prefix.Items.AddRange(new object[] {
            "CtL",
            "CtR",
            "Ct1L",
            "Ct1R"});
            this.cmb_Prefix.Location = new System.Drawing.Point(87, 117);
            this.cmb_Prefix.Name = "cmb_Prefix";
            this.cmb_Prefix.Size = new System.Drawing.Size(85, 20);
            this.cmb_Prefix.TabIndex = 44;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(20, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 12);
            this.label2.TabIndex = 46;
            this.label2.Text = "数据暂存天数:";
            // 
            // tb_dataSaveDays
            // 
            this.tb_dataSaveDays.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_dataSaveDays.Location = new System.Drawing.Point(144, 57);
            this.tb_dataSaveDays.MaxLength = 2;
            this.tb_dataSaveDays.Name = "tb_dataSaveDays";
            this.tb_dataSaveDays.Size = new System.Drawing.Size(25, 21);
            this.tb_dataSaveDays.TabIndex = 45;
            // 
            // check_OutLineDefine
            // 
            this.check_OutLineDefine.AutoSize = true;
            this.check_OutLineDefine.Location = new System.Drawing.Point(202, 60);
            this.check_OutLineDefine.Name = "check_OutLineDefine";
            this.check_OutLineDefine.Size = new System.Drawing.Size(90, 16);
            this.check_OutLineDefine.TabIndex = 47;
            this.check_OutLineDefine.Text = "默认CIM离线";
            this.check_OutLineDefine.UseVisualStyleBackColor = true;
            this.check_OutLineDefine.CheckedChanged += new System.EventHandler(this.check_OutLineDefine_CheckedChanged);
            // 
            // check_FourStationEnable
            // 
            this.check_FourStationEnable.AutoSize = true;
            this.check_FourStationEnable.Location = new System.Drawing.Point(202, 88);
            this.check_FourStationEnable.Name = "check_FourStationEnable";
            this.check_FourStationEnable.Size = new System.Drawing.Size(84, 16);
            this.check_FourStationEnable.TabIndex = 48;
            this.check_FourStationEnable.Text = "四工位模式";
            this.check_FourStationEnable.UseVisualStyleBackColor = true;
            this.check_FourStationEnable.CheckedChanged += new System.EventHandler(this.check_FourStationEnable_CheckedChanged);
            // 
            // check_OfflineMode
            // 
            this.check_OfflineMode.AutoSize = true;
            this.check_OfflineMode.Location = new System.Drawing.Point(202, 30);
            this.check_OfflineMode.Name = "check_OfflineMode";
            this.check_OfflineMode.Size = new System.Drawing.Size(72, 16);
            this.check_OfflineMode.TabIndex = 49;
            this.check_OfflineMode.Text = "脱机模式";
            this.check_OfflineMode.UseVisualStyleBackColor = true;
            this.check_OfflineMode.CheckedChanged += new System.EventHandler(this.check_OfflineMode_CheckedChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(192, 162);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(17, 12);
            this.label8.TabIndex = 54;
            this.label8.Text = "分";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(129, 163);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(17, 12);
            this.label7.TabIndex = 53;
            this.label7.Text = "时";
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Location = new System.Drawing.Point(152, 157);
            this.numericUpDown2.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(40, 21);
            this.numericUpDown2.TabIndex = 52;
            this.numericUpDown2.Value = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.numericUpDown2.ValueChanged += new System.EventHandler(this.NumericUpDown2_ValueChanged);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(85, 157);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            23,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(40, 21);
            this.numericUpDown1.TabIndex = 51;
            this.numericUpDown1.Value = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.NumericUpDown1_ValueChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(20, 163);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 12);
            this.label6.TabIndex = 50;
            this.label6.Text = "起始时间:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(20, 30);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 12);
            this.label3.TabIndex = 56;
            this.label3.Text = "手动离线后弹窗时长:";
            // 
            // Out_Int
            // 
            this.Out_Int.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Out_Int.Location = new System.Drawing.Point(145, 27);
            this.Out_Int.MaxLength = 2;
            this.Out_Int.Name = "Out_Int";
            this.Out_Int.Size = new System.Drawing.Size(25, 21);
            this.Out_Int.TabIndex = 55;
            this.Out_Int.Text = "3";
            // 
            // ParamsSetForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(297, 235);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Out_Int);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.numericUpDown2);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.check_OfflineMode);
            this.Controls.Add(this.check_FourStationEnable);
            this.Controls.Add(this.check_OutLineDefine);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tb_dataSaveDays);
            this.Controls.Add(this.cmb_Prefix);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_cancel);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.lb_UnitID);
            this.Controls.Add(this.tb_UnitID);
            this.Name = "ParamsSetForm";
            this.Text = "参数设置";
            this.Load += new System.EventHandler(this.ParamsSetForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_UnitID;
        private System.Windows.Forms.TextBox tb_UnitID;
        private System.Windows.Forms.Button btn_cancel;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmb_Prefix;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_dataSaveDays;
        private System.Windows.Forms.CheckBox check_OutLineDefine;
        private System.Windows.Forms.CheckBox check_FourStationEnable;
        private System.Windows.Forms.CheckBox check_OfflineMode;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Out_Int;
    }
}