﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace CIM通讯
{
    public class ControlBCR : mySerialPort
    {
        private bool m_bOfflineMode = false;
        public event Action<string> BCRReadOKEvent;
        /// <summary>
        /// 存放VCR读码成功的TrayID，VCR读码成功后入队，Sendout之后出队
        /// </summary>
        public Queue<string> queueInTrayID = new Queue<string>();
        public Queue<string> queueOutTrayID = new Queue<string>();
        public ControlBCR(bool bOffline)
        {
            m_bOfflineMode = bOffline;
            OpFrameHeadAndTail = false;
            Hex_CmdHead = 0XF0;
            Hex_CmdTail = 0X1A;
            ReceivedAllDataEvent += new ReceivedAllDataEventHandler(BCRReadOK);
        }
        public void BCRReadOK(object sender, EventArgs e)
        {
            if (BCRReadOKEvent != null)
            {
                BCRReadOKEvent.BeginInvoke(Encoding.UTF8.GetString(AllData.ToArray()), null, null);
            }
        }
        //test 手动上传TrayID
        public void BCRReadOK(string TrayID)
        {
            if (BCRReadOKEvent != null)
            {
                System.Console.WriteLine("BCR触发事件线程ID为：{0}", Thread.CurrentThread.ManagedThreadId);
                BCRReadOKEvent.BeginInvoke(TrayID, null, null);
            }
        }
    }
}
