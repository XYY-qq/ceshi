﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

namespace CIM通讯
{
    /// <summary>
    /// 字节序转换
    /// </summary>
    ///   
    [StructLayoutAttribute(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public static class Endian
    {
        public static short SwapInt16(this short n)
        {
            return (short)(((n & 0xff) << 8) | ((n >> 8) & 0xff));
        }

        public static ushort SwapUInt16(this ushort n)
        {
            return (ushort)(((n & 0xff) << 8) | ((n >> 8) & 0xff));
        }

        public static int SwapInt32(this int n)
        {
            return (int)(((SwapInt16((short)n) & 0xffff) << 0x10) |
                          (SwapInt16((short)(n >> 0x10)) & 0xffff));
        }

        public static uint SwapUInt32(this uint n)
        {
            return (uint)(((SwapUInt16((ushort)n) & 0xffff) << 0x10) |
                           (SwapUInt16((ushort)(n >> 0x10)) & 0xffff));
        }

        public static long SwapInt64(this long n)
        {
            return (long)(((SwapInt32((int)n) & 0xffffffffL) << 0x20) |
                           (SwapInt32((int)(n >> 0x20)) & 0xffffffffL));
        }

        public static ulong SwapUInt64(this ulong n)
        {
            return (ulong)(((SwapUInt32((uint)n) & 0xffffffffL) << 0x20) |
                            (SwapUInt32((uint)(n >> 0x20)) & 0xffffffffL));
        }
    }
    /// <summary>
    /// 结构体和字节数组互转
    /// </summary>
    //unsafe static class byteTostruct
    //{
    //    //将Byte转换为结构体类型
    //    public static byte[] StructToBytes(object structObj, int size)
    //    {
    //        byte[] bytes = new byte[size];
    //        IntPtr structPtr = Marshal.AllocHGlobal(size);
    //        //将结构体拷到分配好的内存空间
    //        Marshal.StructureToPtr(structObj, structPtr, false);
    //        //从内存空间拷贝到byte 数组
    //        Marshal.Copy(structPtr, bytes, 0, size);
    //        //释放内存空间
    //        Marshal.FreeHGlobal(structPtr);
    //        return bytes;
    //    }
    //    //将Byte转换为结构体类型
    //    public static object ByteToStruct(byte[] bytes, Type type)
    //    {
    //        int size = Marshal.SizeOf(type);
    //        if (size > bytes.Length)
    //        {
    //            return null;
    //        }
    //        //分配结构体内存空间
    //        IntPtr structPtr = Marshal.AllocHGlobal(size);
    //        //将byte数组拷贝到分配好的内存空间
    //        Marshal.Copy(bytes, 0, structPtr, size);
    //        //将内存空间转换为目标结构体
    //        object obj = Marshal.PtrToStructure(structPtr, type);
    //        //释放内存空间
    //        Marshal.FreeHGlobal(structPtr);
    //        return obj;
    //    }
    //}
}
