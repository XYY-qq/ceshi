﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;

namespace CIM通讯
{
    public partial class ErrorForm : Form
    {
        string Msg = "";
        public ErrorForm(string Msg)
        {
            InitializeComponent();
            this.Msg = Msg;
        }

        private void btn_Close_Click(object sender, EventArgs e)
        {
            this.Close();
        }
   
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void ErrorForm_Load(object sender, EventArgs e)
        {
            label1.Text = Msg;
        }
    }
}
