﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIM通讯
{
    //一组PanelID的数据
    public class PanelIDMessageClass
    {
        public string[] PanelID;
        public bool bFeedUnitIN;
        public bool bFeedUnitToCutingUnit;
        public bool bCutingUnitToBrakeUnit;
        public bool bBrakeUnitToFinishUnit;
        public bool bFinishUnitOUT;

        public PanelIDMessageClass()
        { 
            PanelID = new string[6];
            bFeedUnitIN = false;
            bFeedUnitToCutingUnit = false;
            bCutingUnitToBrakeUnit = false;
            bBrakeUnitToFinishUnit = false;
            bFinishUnitOUT = false;
        }
    }
}
