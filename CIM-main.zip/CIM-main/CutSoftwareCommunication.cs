﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CIM通讯
{
    public class CutSoftwareCommunication
    {
        TcpClient tcpClient = new TcpClient(IPAddress.Parse("127.0.0.1".Trim()), 8000);
        public delegate void ReceiveFromCutSoftwareEventHandler(string str);
        public event ReceiveFromCutSoftwareEventHandler ReceiveFromCutSoftwareEvent;
        public event Action<string> TCPExceptionEvent;
        public string GetTactTimeString
        {
            get
            {
                return "GetTactTime:";
            }
        }

        public string GetCapacityInfoString
        {
            get
            {
                return "GetCapacityInfo:";
            }
        }

        public string CutingUnitStartString
        {
            get
            {
                return "CIMStart";
            }
        }
        //清除产能
        public string ClearCapacityInfoString
        {
            get
            {
                return "ClearCapacityInfo:";
            }
        }

        public string GetProcessDataString
        {
            get
            {
                return "GetProcessData:";
            }
        }
        public  CutSoftwareCommunication()
        {
            tcpClient.TcpClientReceiveEvent += new TcpClient.TcpClientReceiveEventHandler(receiveMessage);
            tcpClient.TCPExceptionEvent += TCPException;
            tcpClient.Connected();
        }
        public void TCPException(string Msg)
        {
            TCPExceptionEvent.BeginInvoke(Msg,null,null);
        }
        public void Connected()
        {
            tcpClient.Connected();
        }
        //发送信息给服务器
        private void sendMessage(string value)
        {
            tcpClient.SendMsg(value);
            
        }

        public void cutingUnitOK()
        {
            tcpClient.SendMsg("OK");
        }

        public void cutingUnitNG()//不暂停切割单元
        {
            //tcpClient.SendMsg("NG");
        }

        public void GetTactTime()
        {
            tcpClient.SendMsg("GetTactTime");
        }

        public void GetProcessData()
        {
            tcpClient.SendMsg("GetProcessData");
        }

        public void GetCapacityInfo()
        {
            tcpClient.SendMsg("GetCapacityInfo");
        }

        public void ClearCapacityInfo()
        {
            tcpClient.SendMsg("ClearCapacityInfo");
        }
        //接收信息
        public void receiveMessage(string str)
        {
            if (ReceiveFromCutSoftwareEvent != null)
            {
                System.Console.WriteLine("TCP触发事件线程ID为：{0}", Thread.CurrentThread.ManagedThreadId);
                ReceiveFromCutSoftwareEvent.BeginInvoke(str,null,null);
            }
        }

        public void Close()
        {
            try
            {
                tcpClient.Close();
            }
            catch(Exception) { }
        }
    }
}
///1、切割单元 OK 或者 NG
///NG-切割单元立即宕机
///在收到NG之后，等待OK信号
///2、获取TactTime
///客户端：格式-"GetTactTime"
///服务器：格式-"GetTactTime"+"工序时间"
///3、获取ProcessData（制程参数）
///客户端：格式-"GetProcessData"
///服务器：格式-"GetProcessData+"切割速度""+"激光器功率"+“激光焦距”（目前先这些）
///4、获取CapacityInfo（产能上报，5分钟上报一次）
///客户端：格式-"GetCapacityInfo"
///服务器：格式-"GetCapacityInfo"+"产能"
///5、CapacityInfo清零（换班清零）
///客户端：格式-"ClearCapacityInfo"
///服务器：格式-"ClearCapacityInfo"+"OK"
///全部使用字符串。