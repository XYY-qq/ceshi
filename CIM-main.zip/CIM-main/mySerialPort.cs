﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Windows.Forms;

namespace CIM通讯
{
    public class mySerialPort //帧头+数据+校验+帧尾
        //1.1 帧头+数据长度+数据+校验值
        //1.2包长+校验值
    {
        public bool ReceivedFlag  //标识有没有读到一次完整的数据
        {
            get
            {
                return receivedFlag;
            }
            set
            {
                  receivedFlag = value;
            }
        }
        public List<byte> AllData //接收完整的数据包
        {
            get
            {
                return allData;
            }
            set
            {
                  allData = value;
            }
        } 
        protected byte Hex_CmdHead  //帧头
        {
            get
            {
                return hex_CmdHead;
            }
            set
            {
                 hex_CmdHead = value;
            }
        }
        protected byte Hex_CmdTail  //帧尾
        {
            get
            {
                return hex_CmdTail;
            }
            set
            {
                hex_CmdTail = value;
            }
        }
        protected bool OpFrameHeadAndTail
        {
            get
            {
                return opFrameHeadAndTail;
            }
            set
            {
                opFrameHeadAndTail = value;
            }
        }
        private bool opFrameHeadAndTail = false;
        private bool receivedFlag = false;
        private byte[] ReDatas = null; //缓冲区的数据      
        private List<byte> allData = null;
        private byte hex_CmdTail = 0xF0;
        private byte hex_CmdHead = 0X1A;

        public delegate void ReceivedAllDataEventHandler(object sender, EventArgs e);//数据接收完成
        public event ReceivedAllDataEventHandler ReceivedAllDataEvent;

        private SerialPort ComDevice = new SerialPort();
        public mySerialPort()
        {
            allData = new List<byte>();
            ComDevice.DataReceived += new SerialDataReceivedEventHandler(Com_DataReceived);//绑定事件  
        }
        public string[] GetPortNames()
        {
            return SerialPort.GetPortNames();
        }
        public bool Switch(string PortName, int BaudRate)
        {
            if (ComDevice.IsOpen == false)
            {
                ComDevice.PortName = PortName;
                ComDevice.BaudRate = BaudRate;
                ComDevice.Parity = Parity.None;//0
                ComDevice.DataBits = 8;
                ComDevice.StopBits = StopBits.One;//1
                ComDevice.Open();
            }
            else
            {
                ComDevice.Close();
            }
            return ComDevice.IsOpen;
        }
        //串口接收函数，接收的标志位为ReceivedFlag，接收的数据存放在AllData链表里
        private void Com_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            if (ComDevice.BytesToRead > 0)
            {
                ReceivedFlag = false;//接收数据不成功状态
                ReDatas = new byte[ComDevice.BytesToRead];
                ComDevice.Read(ReDatas, 0, ReDatas.Length);//读取数据
                if ((ReDatas[0] == this.Hex_CmdHead) || (OpFrameHeadAndTail == false))
                {
                    AllData.Clear();
                    AllData.AddRange(ReDatas);
                }
                else
                {
                    AllData.AddRange(ReDatas);
                }
                if ((ReDatas[ReDatas.Length - 1] == this.Hex_CmdTail) || (OpFrameHeadAndTail == false))
                {
                    if (OpFrameHeadAndTail)
                    {                      
                        allData.RemoveAt(0);
                        allData.RemoveAt(allData.Count - 1); 
                    }                   
                    List<byte> Data = new List<byte>();
                    foreach (var data in AllData)
                    {                      
                        if ((data < 32) || (data > 126))
                        {
                            continue;
                        }
                        Data.Add(data);
                    }
                    allData = Data;
                    ReceivedFlag = true;//接收数据成功状态
                    if (ReceivedAllDataEvent != null)
                    {
                        ReceivedAllDataEvent(this, new EventArgs());
                    }
                }
            }
        }

        /// <summary>
        /// 发送数据
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public bool SendData(byte[] data)
        {
            if (ComDevice.IsOpen)
            {
                try
                {
                    ComDevice.Write(data, 0, data.Length);//发送数据
                    return true;
                }
                catch (Exception)
                {
                    return false;
                }
            }
            else
            {
                return false;
            }

        }
        /// <summary>
        /// 关闭串口
        /// </summary>
        public void ClearSelf()
        {
            if (ComDevice.IsOpen)
            {
                ComDevice.Close();
            }
        }
    }
}
