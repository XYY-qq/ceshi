﻿using System;
using System.Windows.Forms;
using System.Collections.Generic;
using TwinCAT.Ads;

namespace CIM通讯
{
    //倍福寄存器的定义
    //I 输入   Q 输出  M 内存定位
    public enum RegisterType
    { 
        I = 0X0000F020,
        Q = 0X0000F030,
        M = 0X00004020,
    }
    public class BeckhoffRW : TcAdsClient
    {
        
        public static Dictionary<string, int> notificationHandles;
        public static TcAdsClient adsClient = null;
        public static bool  BeckhoffEn = true;

        /// <summary>
        /// 提供变量变化的事件函数
        /// </summary>
        public static event Action<int> notificationEvent;
        public static void BeckhoffBase_Init()
        {
            if (!BeckhoffEn)
            {
                return;
            }
            AmsNetId netID = new AmsNetId("127.255.255.1.1.1");
            adsClient = new TcAdsClient();
            notificationHandles = new Dictionary<string, int>();           
            try
            {
                adsClient.AdsNotificationEx += new AdsNotificationExEventHandler(adsClient_AdsNotificationEx);
                adsClient.Connect(netID, 801);
            }
            catch (Exception ex)
            {
                MessageBox.Show("未连接倍福");
                MessageBox.Show(ex.ToString());
                MessageBox.Show(string.Format("IsConnected = {0}", adsClient.IsConnected));
            }
            
        }
        /// <summary>
        /// 添加变量到通知
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="PLC_variable_name"></param>
        public static void AddDeviceNotification<T>(string PLC_variable_name)
        {
            if (!BeckhoffEn)
            {
                return;
            }
            notificationHandles.Add(PLC_variable_name, adsClient.AddDeviceNotificationEx(PLC_variable_name, AdsTransMode.OnChange, 100, 0, new object(), typeof(T)));
        }
        private static void adsClient_AdsNotificationEx(object sender, AdsNotificationExEventArgs e)
        {
            if (!BeckhoffEn)
            {
                return;
            }
            if (notificationEvent != null)
            {
                notificationEvent.BeginInvoke(e.NotificationHandle,null,null);
            }

        }
        /// <summary>
        /// 读倍福PLC变量
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="PLC_variable_name"></param>
        /// <param name="read_value"></param>
        /// <param name="string_len"></param>
        public static void ReadPlcVariable<T>(string PLC_variable_name, ref T read_value,int string_len = 0)
        {

            if (!BeckhoffEn)
            {
                return;
            }
                try
                {
                    int head;
                    head = adsClient.CreateVariableHandle(PLC_variable_name);

                    if (typeof(T) == typeof(string))
                    {
                        read_value = (T)adsClient.ReadAny(head, typeof(string), new int[] { string_len });//这里需要测试 
                    }
                    else if (typeof(T) == typeof(Boolean) || typeof(T) == typeof(short) || typeof(T) == typeof(double))
                    {
                        read_value = (T)adsClient.ReadAny(head, typeof(T));
                    }
                }
                catch (Exception)
                {
                   
                }
        }
        /// <summary>
        /// 写倍福PLC变量
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="PLC_variable_name"></param>
        /// <param name="write_value"></param>
        public static void WritePlcVariable<T>(string PLC_variable_name, T write_value)
        {
            if (!BeckhoffEn)
            {
                return;
            }
            try
            {
                int head;
                head = adsClient.CreateVariableHandle(PLC_variable_name);
                if (typeof(T) == typeof(string))
                {
                    adsClient.WriteAny(head, write_value, new int[] { write_value.ToString().Length });
                }
                else if (typeof(T) == typeof(Boolean) || typeof(T) == typeof(short) || typeof(T) == typeof(double))
                {
                    adsClient.WriteAny(head, write_value);
                }
            }
            catch (Exception)
            {
                              
            }
        }

        public static void WriteAddrMemory(RegisterType registerType,uint indexOffset,object value)
        {
            if (!BeckhoffEn)
            {
                return;
            }
            adsClient.WriteAny((uint)registerType, indexOffset, value);
        }

        public static object ReadAddrMemory(RegisterType registerType, uint indexOffset, Type type)
        {
            if (!BeckhoffEn)
            {
                return -1;
            }
            return  adsClient.ReadAny((uint)registerType,indexOffset, type);
        }


        public static void BeckhoffMotionDisconnect()
        {
            if (!BeckhoffEn)
            {
                return;
            }
            adsClient.Disconnect();
        }
        public static void BeckhoffMotionDispose()
        {
            if (!BeckhoffEn)
            {
                return;
            }
            adsClient.Close();
            adsClient.Dispose();
        }
    }
}
