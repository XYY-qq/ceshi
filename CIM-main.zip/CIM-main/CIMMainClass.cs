﻿using ParamModule;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using TimeOperate;
using System.IO;
using System.Threading.Tasks;
using System.Data.SQLite;
using System.Collections;
using System.Data;
using System.Threading.Tasks;
using ASPOSE;
using System.Xml;
using System.Xml.Linq;

namespace CIM通讯
{
   public class CIMMainClass
    {

        #region SQL命令定义
        public string dbPath = "";
        public string dbName = "";
        private SQLiteCommand dbCommand;
        public SQLiteConnection conn = null;//数据库读到的信息
        #endregion
        public ControlVCR controlVCR;
        public ControlBCR controlBCR;
        public List<string> LBCMessage = new List<string>();
        public VariableMap variableMap = null;
        public CutSoftwareCommunication cutSoftwareCommunication = new CutSoftwareCommunication();

        public event Action DispalyReadOKRateEvent;
        public event Action DispalyBCREvent; //当前工单生产完毕时，还有操作此事件
        public event Action<string> NormalLog;
        public event Action<string> BCNormalLog;
        public event Action<string> WarningLog;
        public event Action<string> BCWarningLog;
        public event Action<int> DisplayNowPlateNum;

        private CIMParams cIMparams;

       //报警表对应的PLC变量
        public List<string> AlarmTable_PLC = new List<string>();
        public Dictionary<string, int> dictAlarmTable = new Dictionary<string, int>();
        public Dictionary<string, bool> dictAlarmState = new Dictionary<string, bool>();

        public CIMParams CIMparams
        {
            get
            {
                return cIMparams;
            }
        }
        XElement ele1;
        XElement ele;
        string file_B;
        string file_A;
        public CIMMainClass()
        {
            try
            {
                file_A = Path.Combine(".\\params", "CIMConfig.ini");
                cIMparams = new CIMParams(file_A, "CIM");

                file_B = Path.Combine(".\\params", "CIMConfig_beifen");
                ele = CIMparams.ToXml();
                if (File.Exists(file_B) == false)
                {
                    XElement ele2 = CIMparams.ToXml();
                    ele2.Save(file_B);
                }
                ele1 = XElement.Load(file_B);
                if (ele.ToString() != ele1.ToString())
                {

                    CIMparams.InitWithXml(XElement.Load(file_B));
                    CIMparams.SavePrm();
                }
            }
            catch (Exception e)
            {
                ToolSet.Log.Info(e.ToString());
            }

            controlVCR = new ControlVCR(cIMparams.OfflineMode,cIMparams.FourStationEnable);
            controlBCR = new ControlBCR(cIMparams.OfflineMode);

            variableMap = new VariableMap(cIMparams);
            variableMap.BCDateTimeCanReadEvent += ReadBCDateTime;
            variableMap.BCMessageCanReadEvent += ReadBCMessage;
            variableMap.BCPNLValidationCanReadEvent += ReadBCPanelMsg;
            variableMap.BCTrayValidationCanReadEvent += ReadBCTrayMsg;
            variableMap.TimeOutEvent += TimeOutMsg;
            controlVCR.VCRReadOKEvent += new ControlVCR.VCRReadOKEventHandler(startSendPanelIDToBC);
            controlVCR.VCRReadNGEvent += new ControlVCR.VCRReadNGEventHandler(startSendPanelIDToDispaly);
            //controlVCR.PanelSendOutEvent += PanelSendOut;//出料事件
            controlVCR.PanelBrakeUnitToFinishUnitEvent += PanelBrakeUnitToFinishUnit; //裂片台到下料单元
            controlVCR.PanelCutingUnitToBrakeUnitEvent += PanelCutingUnitToBrakeUnit; //切割单元到裂片台
            controlVCR.PanelFeedUnitToCutingUnitEvent += PanelFeedUnitToCutingUnit; //上料单元到切割单元
            controlBCR.BCRReadOKEvent += SendBCRMsgToBC;
            controlVCR.EqpStatusEvent += EqpStatusChange;
            //注销报警测试出账问题
            //controlVCR.EqpAlarmEvent += EqpAlarmMsg;
            controlVCR.WorkOrderOffEvent += controlVCR_WorkOrderOffEvent;
            cutSoftwareCommunication.ReceiveFromCutSoftwareEvent += new CutSoftwareCommunication.ReceiveFromCutSoftwareEventHandler(ReadCutSoftwareMsg);
            cutSoftwareCommunication.TCPExceptionEvent += this.TimeOutMsg;
            SQLiteForm.ClearSQLiteEvent += ClearSQLite;
            SQLiteInit();//初始化数据库
            GenerateAlarmTable();//生成报警表
            //上传设备状态信息
            //variableMap.CtLToBC_EqpStatusTask(controlVCR.R_EqpStatus(),  VariableMap.waitTime);
        }
        private void TimeOutMsg(string msg)
        {
            if (WarningLog != null && variableMap.BCToCtL_BCAlive() == true)
            {
                this.controlVCR.CIMAlaram(true);
                WarningLog(msg);
            }
        }
       /// <summary>
       /// 生成报警表
       /// </summary>
        private void GenerateAlarmTable()
        {
            #region 上料单元报警表PLC变量
            AlarmTable_PLC.AddRange(new string[] { 
              ".MsgList[1]"
            , ".MsgList[2]"
            , ".MsgList[3]"
            , ".MsgList[4]"
            , ".MsgList[5]"
            , ".MsgList[6]"
            , ".MsgList[7]"
            , ".MsgList[8]"
            , ".MsgList[9]"
            , ".MsgList[10]"
            , ".MsgList[11]"
            , ".MsgList[12]"
            , ".MsgList[13]"
            , ".MsgList[14]"
            , ".MsgList[15]"
            , ".MsgList[16]"
            , ".MsgList[17]"
            , ".MsgList[18]"
            , ".MsgList[19]"
            , ".MsgList[20]"
            , ".MsgList[21]"
            , ".MsgList[22]"
            , ".MsgList[23]"
            , ".MsgList[24]"
            , ".MsgList[25]"
            , ".MsgList[26]"
            , ".MsgList[27]"
            , ".MsgList[28]"
            , ".MsgList[29]"
            , ".MsgList[30]"
            , ".MsgList[31]"
            , ".MsgList[32]"
            , ".MsgList[33]"
            , ".MsgList[34]"
            , ".MsgList[35]"
            , ".MsgList[36]"
            , ".MsgList[37]"
            , ".MsgList[38]"
            , ".MsgList[39]"
            , ".MsgList[40]"
            , ".MsgList[41]"
            , ".MsgList[42]"
            , ".MsgList[43]"
            , ".MsgList[44]"
            , ".MsgList[45]"
            , ".MsgList[46]"
            , ".MsgList[47]"
            , ".MsgList[48]"});
            #endregion

            #region 切割单元报警表PLC变量
            AlarmTable_PLC.AddRange(new string[] { 
              ".MsgList1[1]"
            , ".MsgList1[2]"
            , ".MsgList1[3]"
            , ".MsgList1[4]"
            , ".MsgList1[5]"
            , ".MsgList1[6]"
            , ".MsgList1[7]"
            , ".MsgList1[8]"
            , ".MsgList1[9]"
            , ".MsgList1[10]"
            , ".MsgList1[11]"
            , ".MsgList1[12]"
            , ".MsgList1[13]"
            , ".MsgList1[14]"
            , ".MsgList1[15]"
            , ".MsgList1[16]"
            , ".MsgList1[17]"
            , ".MsgList1[18]"});
            #endregion

            #region 裂片单元报警表PLC变量
            AlarmTable_PLC.AddRange(new string[] { 
              ".Break_MsgList[1]"
            , ".Break_MsgList[2]"
            , ".Break_MsgList[3]"
            , ".Break_MsgList[4]"
            , ".Break_MsgList[5]"
            , ".Break_MsgList[6]"
            , ".Break_MsgList[7]"
            , ".Break_MsgList[8]"
            , ".Break_MsgList[9]"
            , ".Break_MsgList[10]"
            , ".Break_MsgList[11]"
            , ".Break_MsgList[12]"
            , ".Break_MsgList[13]"
            , ".Break_MsgList[14]"
            , ".Break_MsgList[15]"
            , ".Break_MsgList[16]"
            , ".Break_MsgList[17]"
            , ".Break_MsgList[18]"
            , ".Break_MsgList[19]"
            , ".Break_MsgList[20]"
            , ".Break_MsgList[21]"
            , ".Break_MsgList[22]"
            , ".Break_MsgList[23]"
            , ".Break_MsgList[24]"
            , ".Break_MsgList[25]"
            , ".Break_MsgList[26]"
            , ".Break_MsgList[27]"});
            #endregion

            #region 下料单元报警表PLC变量
            AlarmTable_PLC.AddRange(new string[] { 
              ".Finish_MsgList[1]"
            , ".Finish_MsgList[2]"
            , ".Finish_MsgList[3]"
            , ".Finish_MsgList[4]"
            , ".Finish_MsgList[5]"
            , ".Finish_MsgList[6]"
            , ".Finish_MsgList[7]"
            , ".Finish_MsgList[8]"
            , ".Finish_MsgList[9]"
            , ".Finish_MsgList[10]"
            , ".Finish_MsgList[11]"
            , ".Finish_MsgList[12]"
            , ".Finish_MsgList[13]"
            , ".Finish_MsgList[14]"
            , ".Finish_MsgList[15]"
            , ".Finish_MsgList[16]"
            , ".Finish_MsgList[17]"
            , ".Finish_MsgList[18]"
            , ".Finish_MsgList[19]"
            , ".Finish_MsgList[20]"
            , ".Finish_MsgList[21]"
            , ".Finish_MsgList[22]"
            , ".Finish_MsgList[23]"
            , ".Finish_MsgList[24]"
            , ".Finish_MsgList[25]"
            , ".Finish_MsgList[26]"
            , ".Finish_MsgList[27]"
            , ".Finish_MsgList[28]"
            , ".Finish_MsgList[29]"
            , ".Finish_MsgList[30]"
            , ".Finish_MsgList[31]"
            , ".Finish_MsgList[32]"
            , ".Finish_MsgList[33]"
            , ".Finish_MsgList[34]"
            , ".Finish_MsgList[35]"
            , ".Finish_MsgList[36]"
            , ".Finish_MsgList[37]"});
            #endregion

            for (int i = 10001; i <= 10048; i++)
            {
                string str = string.Format(".MsgList[{0}]",i-10000);
                dictAlarmTable.Add(str,i);
                dictAlarmState.Add(str,false);
            }
            for (int i = 20001; i <= 20018; i++)
            {
                string str = string.Format(".MsgList1[{0}]", i-20000);
                dictAlarmTable.Add(str, i);
                dictAlarmState.Add(str, false);
            }
            for (int i = 30001; i <= 30027; i++)
            {
                string str = string.Format(".Break_MsgList[{0}]", i-30000);
                dictAlarmTable.Add(str, i);
                dictAlarmState.Add(str, false);
            }
            for (int i = 40001; i <= 40037; i++)
            {
                string str = string.Format(".Finish_MsgList[{0}]", i-40000);
                dictAlarmTable.Add(str, i);
                dictAlarmState.Add(str, false);
            }
        }
       //上报报警信息
        public void EqpAlarmMsg()
        {
            //LH
            // Task task = new Task(() =>
            //{
                DateTime dTime = new DateTime();
                dTime = DateTime.Now; 
                bool state = false;
                foreach (string Alarm in AlarmTable_PLC)
                {
                    BeckhoffRW.ReadPlcVariable(Alarm, ref state);
                    if (state != dictAlarmState[Alarm])
                    {
                        if (state)
                        {
                            variableMap.CtLToBC_EventAlarmTask(dictAlarmTable[Alarm], VariableMap.AlarmLevel.Heavy, VariableMap.AlarmStatus.AlarmSet,  VariableMap.waitTime);
                            m_NormalLog("报警提示：" + dictAlarmTable[Alarm].ToString());
                        }
                        else
                        {
                            variableMap.CtLToBC_EventAlarmTask(dictAlarmTable[Alarm], VariableMap.AlarmLevel.Heavy, VariableMap.AlarmStatus.AlarmClear,  VariableMap.waitTime);
                            m_NormalLog("报警清除：" + dictAlarmTable[Alarm].ToString());
                        }
                        //LH
                        Thread.Sleep(5000);
                    }
                    dictAlarmState[Alarm] = state;
                    //Thread.Sleep(5000);
                }
                TimeSpan ts = DateTime.Now - dTime;
                //ToolSet.Log.Info("报警处理时长:" + ts.TotalSeconds.ToString());
            //});
            //task.Start();
            //task.Wait();
        }

        #region 工件流程
        //委托异步
        public void PanelBrakeUnitToFinishUnit()
        {
           if (controlVCR.queueLastStationPanelID.Count <= 0)
           {
               m_NormalLog("裂片到下料: 队列中无数据!");
               return;
           }
           string[] testPanelID = new string[6];
           //PanelIDMessageClass c1 = new PanelIDMessageClass();
           List<PanelIDMessageClass> c1 = new List<PanelIDMessageClass>();
           controlVCR.GetCurrentPanelIDMessage(ref controlVCR.queueLastStationPanelID, ref c1, "BrakeToFinish");
           foreach (PanelIDMessageClass c11 in c1)
           {
               testPanelID = c11.PanelID;
               if (testPanelID[0] == null)
               {
                   return;
               }
               ToolSet.Log.Info("裂片到下料---" + testPanelID[0].ToString());
               m_NormalLog("裂片到下料---" + testPanelID[0].ToString());
               for (int i = 0; i < controlVCR.StationNumber; i++)
               {
                   //Task task = new Task(() =>
                   //{
                   //    variableMap.CtLToBC_PanelUnitOut2Task(testPanelID[i], VariableMap.waitTime);
                   //    if (!this.variableMap._waitPanelUnitOut2CheackHandle.WaitOne(4000, true)) //线程同步事件
                   //     {
                   //        ToolSet.Log.Info("PanelUnitOut2---BC端无回复！");
                   //    }
                   //});
                   //task.Start();
                   //task.Wait();
                   try
                   {
                       //string kk = ss[0];
                       //kk = ss[1];
                       //kk = ss[2];
                       //ToolSet.Log.Info("CtLToBC_ProcessDataTask：40000, 13630,\n");
                       //variableMap.CtLToBC_ProcessDataTask(cIMparams.NowRecipeID, (int)(double.Parse(ss[0]) * 1000),
                       //                                    (int)(double.Parse(ss[1]) * 1000), (int)(double.Parse(ss[2]) * 1000),
                       //                                    "111", VariableMap.waitTime);//发送制程参数
                       variableMap.CtLToBC_ProcessDataTask(cIMparams.NowRecipeID, 40000, 13630, 0,
                                                           testPanelID[i], VariableMap.waitTime);//发送制程参数
                       ToolSet.Log.Info("发送制程参数完成\n");
                   }
                   catch (Exception e)
                   {
                       ToolSet.Log.Info("RecipeID格式不正确: " + cIMparams.NowRecipeID);
                       m_NormalLog("RecipeID格式不正确: " + cIMparams.NowRecipeID);
                   }
                   //if (!this.variableMap._waitProcessDataCheackHandle.WaitOne(4000, true)) //线程同步事件
                   //{
                   //    ToolSet.Log.Info("ProcessData---BC端无回复！");
                   //}  
                   variableMap.CtLToBC_PanelSendOutTask(testPanelID[i], VariableMap.waitTime);
               }
               controlVCR.queueLastStationPanelID.Dequeue();//出队
               ToolSet.Log.Info("出料并出队列完成---" + testPanelID[0].ToString());
               m_NormalLog("出料并出队列完成---" + testPanelID[0].ToString());
           }
           
        }

        //委托异步
        public void PanelCutingUnitToBrakeUnit()
        {
            //m_NormalLog("切割到裂片");
            if (controlVCR.queueLastStationPanelID.Count <= 0)
            {
                m_NormalLog("切割到裂片: 队列中无数据!");
                return;
            }
            string[] testPanelID = new string[6];
            //PanelIDMessageClass c1 = new PanelIDMessageClass();
            List<PanelIDMessageClass> c1 = new List<PanelIDMessageClass>();
            controlVCR.GetCurrentPanelIDMessage(ref controlVCR.queueLastStationPanelID, ref c1, "CutingToBrake");
            foreach (PanelIDMessageClass c11 in c1)
            {
                testPanelID = c11.PanelID;
                if (testPanelID[0] == null)
                {
                    return;
                }
                ToolSet.Log.Info("切割到裂片---" + testPanelID[0].ToString());
                m_NormalLog("切割到裂片---" + testPanelID[0].ToString());
                for (int i = 0; i < controlVCR.StationNumber; i++)
                {
                    //LH
                    //Task task = new Task(() =>
                    //{
                    variableMap.CtLToBC_PanelUnitOut1Task(testPanelID[i], VariableMap.waitTime);
                    //if (!this.variableMap._waitPanelUnitOut1CheackHandle.WaitOne(4000, true)) //线程同步事件
                    //{
                    //    ToolSet.Log.Info("PanelUnitOut1---BC端无回复！");
                    //}    
                    variableMap.CtLToBC_PanelUnitIn2Task(testPanelID[i], VariableMap.waitTime);
                    //if (!this.variableMap._waitPanelUnitIn2CheackHandle.WaitOne(4000, true)) //线程同步事件
                    //{
                    //    ToolSet.Log.Info("PanelUnitIn2---BC端无回复！");
                    //}
                    variableMap.CtLToBC_PanelUnitOut2Task(testPanelID[i], VariableMap.waitTime);
                    //if (!this.variableMap._waitPanelUnitOut2CheackHandle.WaitOne(4000, true)) //线程同步事件
                    //{
                    //    ToolSet.Log.Info("PanelUnitOut2---BC端无回复！");
                    //}
                    //});
                    //task.Start();
                    //task.Wait();

                }
            }
        }

        //委托异步
        public void PanelFeedUnitToCutingUnit()
        {
            //m_NormalLog("上料到切割");
            if (controlVCR.queueLastStationPanelID.Count <= 0)
            {
                m_NormalLog("上料到切割: 队列中无数据!");
                return;
            }
            string[] testPanelID = new string[6];
            //PanelIDMessageClass c1 = new PanelIDMessageClass();
             List<PanelIDMessageClass> c1 = new List<PanelIDMessageClass>();
            controlVCR.GetCurrentPanelIDMessage(ref controlVCR.queueLastStationPanelID, ref c1, "FeedToCuting");
            foreach (PanelIDMessageClass c11 in c1)
            {
                testPanelID = c11.PanelID;
                ToolSet.Log.Info("上料到切割---" + testPanelID[0].ToString());
                m_NormalLog("上料到切割---" + testPanelID[0].ToString());
                for (int i = 0; i < controlVCR.StationNumber; i++)
                {
                    variableMap.CtLToBC_PanelReceiveTask(testPanelID[i], VariableMap.waitTime);
                    //if (!this.variableMap._waitPanelReceiveCheackHandle.WaitOne(4000, true)) //线程同步事件
                    //{
                    //    ToolSet.Log.Info("PanelReceive---BC端无回复！");
                    //}    
                    variableMap.CtLToBC_PanelUnitIn1Task(testPanelID[i], VariableMap.waitTime);
                    //if (!this.variableMap._waitPanelUnitIn1CheackHandle.WaitOne(4000, true)) //线程同步事件
                    //{
                    //    ToolSet.Log.Info("PanelUnitIn1---BC端无回复！");
                    //}    
                    variableMap.CtLToBC_ProcessStartTask(testPanelID[i], VariableMap.waitTime);
                    //if (!this.variableMap._waitProcessStartCheackHandle.WaitOne(4000, true)) //线程同步事件
                    //{
                    //    ToolSet.Log.Info("ProcessStart---BC端无回复！");
                    //}    
                }
            }
        }

        /// <summary>
        /// 出料
        /// 异步委托
        /// </summary>
        public void PanelSendOut()
        {
            //ToolSet.Log.Info("进入出料！！！");
            if (controlVCR.queueLastStationPanelID.Count <= 0)
            {
                m_NormalLog("出料: 队列中无数据!");
                return;
            }
            //ToolSet.Log.Info("出料获取工艺参数"); ;
            //cutSoftwareCommunication.GetProcessData();
            //ToolSet.Log.Info("出料获取工艺参数完成--");
            string[] testPanelID = new string[6];
            //PanelIDMessageClass c1 = new PanelIDMessageClass();
            List<PanelIDMessageClass> c1 = new List<PanelIDMessageClass>();
            controlVCR.GetCurrentPanelIDMessage(ref controlVCR.queueLastStationPanelID, ref c1, "Finish");
            foreach (PanelIDMessageClass c11 in c1)
            {
                testPanelID = c11.PanelID;
                if (testPanelID[0] == null)
                {
                    return;
                }
                ToolSet.Log.Info("出料---" + testPanelID[0].ToString());
                ////controlBCR.queueOutTrayID出料不需要上传TrayID.
                for (int i = 0; i < controlVCR.StationNumber; i++)
                {

                    //try
                    //{
                    //    //string kk = ss[0];
                    //    //kk = ss[1];
                    //    //kk = ss[2];
                    //    ToolSet.Log.Info("CtLToBC_ProcessDataTask：40000, 13630,\n");
                    //    //variableMap.CtLToBC_ProcessDataTask(cIMparams.NowRecipeID, (int)(double.Parse(ss[0]) * 1000),
                    //    //                                    (int)(double.Parse(ss[1]) * 1000), (int)(double.Parse(ss[2]) * 1000),
                    //    //                                    "111", VariableMap.waitTime);//发送制程参数
                    //    variableMap.CtLToBC_ProcessDataTask(cIMparams.NowRecipeID, 40000, 13630,0,
                    //                                        testPanelID[i], VariableMap.waitTime);//发送制程参数
                    //    ToolSet.Log.Info("发送制程参数完成\n");
                    //}
                    //catch (Exception e)
                    //{
                    //    ToolSet.Log.Info("RecipeID格式不正确: " + cIMparams.NowRecipeID);
                    //    m_NormalLog("RecipeID格式不正确: " + cIMparams.NowRecipeID);
                    //}
                    ////if (!this.variableMap._waitProcessDataCheackHandle.WaitOne(4000, true)) //线程同步事件
                    ////{
                    ////    ToolSet.Log.Info("ProcessData---BC端无回复！");
                    ////}  
                    variableMap.CtLToBC_PanelSendOutTask(testPanelID[i], VariableMap.waitTime);
                    ////if (!this.variableMap._waitPanelSendOutCheackHandle.WaitOne(4000, true)) //线程同步事件
                    ////{
                    ////    ToolSet.Log.Info("PanelSendOut---BC端无回复！");
                    ////} 
                }
                controlVCR.queueLastStationPanelID.Dequeue();//出队
                ToolSet.Log.Info("出料并出队列完成---" + testPanelID[0].ToString());
            }
        }
        #endregion
        private void controlVCR_WorkOrderOffEvent()
        {
            WarningLog("当前LotID产量已经生产完毕，请重新上传LotID!!!");
        }

        #region 数据库操作

        public void SQLiteInit()
        {
            dbPath = "Data Source =" + Environment.CurrentDirectory + "\\CIM_VCR.db";
            dbName = Environment.CurrentDirectory + "\\CIM_VCR.db";
            SQLiteHelper.connectionString = dbPath;
            conn = new SQLiteConnection(SQLiteHelper.connectionString);
            conn.Open();//打开数据库，若文件不存在会自动创建  
            //表的创建和数据的插入
            string sql = "CREATE TABLE IF NOT EXISTS CIM_VCR" + "([DateTme] DATE, [TrayID] VARCHAR,[PanelID] VARCHAR);";
            SQLiteCommand cmdCreateTable = new SQLiteCommand(sql, conn);
            cmdCreateTable.ExecuteNonQuery();//如果表不存在，创建数据表  
            SQLiteCommand cmdInsert = new SQLiteCommand(conn);
        }
        /// <summary>
        /// 增加一条数据到数据库,TrayID可以为空，PanelID不能为空
        /// </summary>
        /// <param name="panelID"></param>
        /// <param name="trayID"></param>
        /// <returns></returns>
        public bool addDataToSQLite(string panelID, string trayID = "")
        {
            //cIMparams.ReadPrm();
            //if (cIMparams.dataSaveDays * 100000 <= cIMparams.SQLitePanelNum)
            //{
            //    cIMparams.SQLitePanelNum = 0;
            //    cIMparams.ReadOKNum = 0;
            //    cIMparams.ReadNGNum = 0;
            //   // cIMparams.SavePrm();
            //    List<string> ListStrName = GetTableNameList();
            //    foreach (string str1 in ListStrName)
            //    {
            //        RemoveTableFromdb(str1);
            //    }
            //    //初始化数据库
            //    SQLiteInit();
            //}

            //cIMparams.ReadPrm();
            cIMparams.SQLitePanelNum++;
            //cIMparams.SavePrm();

            //List<CIMData> Ldata = LoadInfo();
            //foreach (CIMData mydata in Ldata)
            //{
            //    if ((panelID == mydata.PanelID) && (panelID != ""))
            //    {
            //        return false;
            //    }
            //    if ((trayID == mydata.TrayID) && (trayID != ""))
            //    {
            //        return false;
            //    }
            //}
            CIMData data = new CIMData();
            data.Datatime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            data.PanelID = panelID;
            data.TrayID = trayID;
            return InsertInfo(data);
        }
        private void ClearSQLite()
        {
            string str = "此操作会导致数据库数据丢失! 未经允许操作者，必追责111\r\n确认是否操作？";
            DialogResult dr = MessageBox.Show(str, "警告", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if (dr == DialogResult.OK)
            {
                //清除读码OK,NG次数
                
                MessageBox.Show("数据清除成功！！！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
         
                //CIMparams.ReadPrm();
                CIMparams.ReadNGNum = 0;
                CIMparams.ReadOKNum = 0;
                CIMparams.SQLitePanelNum = 0;
                //CIMparams.SavePrm();
                if (DispalyReadOKRateEvent != null)
                {
                    DispalyReadOKRateEvent();
                }
                List<string>ListStrName = GetTableNameList();
                foreach (string str1 in ListStrName)
                {
                    RemoveTableFromdb(str1);
                }
                //初始化数据库
                SQLiteInit();
            }
            else
            {
                MessageBox.Show("数据未清除！！！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);

                return;
            }

        }
       /// <summary>
       /// 将表从数据库中清除掉
       /// </summary>
       /// <param name="tableName"></param>
        public void RemoveTableFromdb(string tableName)
        {
            string sql = "DROP TABLE " + tableName;
            SQLiteCommand cmdCreateTable = new SQLiteCommand(sql, conn);
            cmdCreateTable.ExecuteNonQuery();//如果表不存在，创建数据表  
            SQLiteCommand cmdInsert = new SQLiteCommand(conn);
        }
        /// <summary>
        /// 从数据库中获取表名
        /// </summary>
        /// <returns></returns>
        private List<string> GetTableNameList()
        {
            List<string> list = new List<string>();
            StringBuilder strSql = new StringBuilder();
            strSql.Append(@"select name from sqlite_master where type='table' order by name;");
            foreach (System.Data.DataTable table in SQLiteHelper.Query(strSql.ToString()).Tables)
            {
                foreach (DataRow row in table.Rows)
                {
                    list.Add(row[0].ToString());
                }
                break;
            }
            return list;
        }
        /// <summary>
        /// 从数据库中加载数据到链表(获取表数据)
        /// </summary>
        /// <returns></returns>
        public List<CIMData> LoadInfo()
        {
            List<CIMData> list = new List<CIMData>();
            StringBuilder strSql = new StringBuilder();
            strSql.Append(@"select DateTme,TrayID,PanelID from " + "CIM_VCR");
            foreach (System.Data.DataTable table in SQLiteHelper.Query(strSql.ToString()).Tables)
            {
                foreach (DataRow row in table.Rows)
                {
                    CIMData ld = new CIMData();
                    ld.Datatime = row[0].ToString();
                    ld.TrayID = row[1].ToString();
                    ld.PanelID = row[2].ToString();
                    list.Add(ld);
                }
                break;
            }
            return list;
        }

        public void QueryTableByTray(ListView listView, string strTrayID)
        {
            ShowTable(listView, GetTableByTray(strTrayID));
        }

        public void QueryTableByPanel(ListView listView, string strPanelID)
        {
            ShowTable(listView, GetTableByPanel(strPanelID));
        }

        public void QueryTableByDay(ListView listView, DateTime starttime, DateTime endtime)
        {
            ShowTable(listView, GetTableByDay(starttime, endtime));
        }

        DataSet GetTableByDay(DateTime starttime, DateTime endtime)
        {
            string strFmt = string.Format("select DateTme,TrayID,PanelID from CIM_VCR where DateTme between datetime('{0}') and  datetime('{1}')", starttime.ToString("yyyy-MM-dd 00:00:00"), endtime.ToString("yyyy-MM-dd 24:00:00"));
            return SQLiteHelper.Query(strFmt);
        }

        DataSet GetTableByPanel(string strPanelID)
        {
            string strFmt = string.Format("select DateTme,TrayID,PanelID from CIM_VCR where PanelID ='{0}'", strPanelID);
            return SQLiteHelper.Query(strFmt);
        }

        DataSet GetTableByTray(string strTrayID)
        {
            string strFmt = string.Format("select DateTme,TrayID,PanelID from CIM_VCR where TrayID ='{0}'", strTrayID);
            return SQLiteHelper.Query(strFmt);
        }

        private void ShowTable(ListView listView, DataSet data)
        {
            listView.Items.Clear();
            listView.Columns.Clear();

            listView.Columns.Add("时间", 200, HorizontalAlignment.Center);
            listView.Columns.Add("TrayID", 200, HorizontalAlignment.Center);
            listView.Columns.Add("PanelID", 200, HorizontalAlignment.Center);
            listView.View = System.Windows.Forms.View.Details;  //这命令比较重要，否则不能显示。

            foreach (System.Data.DataTable table in data.Tables)
            {
                foreach (DataRow row in table.Rows)
                {
                    ListViewItem item = new ListViewItem();
                    item.Text = row[0].ToString();
                    item.SubItems.Add(row[1].ToString());
                    item.SubItems.Add(row[2].ToString());

                    listView.Items.Add(item);
                }
                break;
            }
        }

        /// <summary>
        /// 插入一条记录
        /// </summary>
        /// <param name="ld">一组CIM数据的实例</param>
        /// <returns>true为成功</returns>
        public bool InsertInfo(CIMData ld)
        {
            Hashtable ht = new Hashtable();

            StringBuilder strSql = new StringBuilder();
            strSql.Append("insert into " + "CIM_VCR(");
            strSql.Append("DateTme,TrayID,PanelID)");
            strSql.Append(" values (");
            strSql.Append("@DateTme,@TrayID,@PanelID)");
            SQLiteParameter[] parameters = {
                    SQLiteHelper.MakeSQLiteParameter("@DateTme", DbType.DateTime,ld.Datatime),
                    SQLiteHelper.MakeSQLiteParameter("@TrayID", DbType.String,ld.TrayID),
                    SQLiteHelper.MakeSQLiteParameter("@PanelID", DbType.String,ld.PanelID),
                    };

            ht.Add(strSql, parameters);

            return SQLiteHelper.ExecuteSqlTran(ht);
        }

        public void ToExcel(DateTime starttime, DateTime endtime)
        {
            DataSet data = GetTableByDay(starttime, endtime);
            if(data.Tables.Count <= 0)
            {
                MessageBox.Show("查询数据为空！");
                return;
            }

            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Title = "保存EXECL文件";
            sfd.Filter = string.Format("Excel文件(*.xls)|*.xls | Excel文件(*.xlsx)|*.xlsx");
            sfd.CheckPathExists = true;
            sfd.DefaultExt = ".xlsx";
            sfd.OverwritePrompt = true;
            sfd.ValidateNames = true;
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                string strRtn = "";
                if(aspose.CreateAutoSheet(sfd.FileName, data,ref strRtn))
                {
                    MessageBox.Show("导出到EXCEL完成");
                }
                else
                {
                    ToolSet.Log.Info("导出到Excel失败:" + strRtn);
                    MessageBox.Show("导出到Excel失败: " + strRtn);
                }
                
            }
        }

        #endregion

        /// <summary>
        /// 设备状态改变
        /// </summary>
        /// <param name="eqpStatus"></param>
        public void EqpStatusChange(VariableMap.EqpStatus eqpStatus)
        {
            variableMap.CtLToBC_EqpStatusTask(eqpStatus, VariableMap.waitTime);
        }

        //委托异步
        object obSendBCRmsgToBC = new object();
        public void SendBCRMsgToBC(string strTrayID)
        {
            if (controlBCR.queueInTrayID.Count < 2)//  0/1
            {
                lock(obSendBCRmsgToBC)
                {
                    CIMparams.SavePrm();
                    string file_B = Path.Combine(".\\params", "CIMConfig_beifen");
                    XElement ele = CIMparams.ToXml();
                    ele.Save(file_B);
                    //LH
                    ToolSet.Log.Info("发送BCR信息给BC!" + strTrayID);
                    this.variableMap._waitTrayIDCheackHandle.Reset();
                    variableMap.CtLToBC_TrayInfoRequestTask(VariableMap.waitTime, strTrayID);
                    //LH
                    if (!this.variableMap._waitTrayIDCheackHandle.WaitOne(8000)) //线程同步事件
                    {
                        ToolSet.Log.Info("等待_waitTrayIDCheackHandle 超时" + strTrayID);
                        variableMap.BCTrayValidationDisplayEvent.BeginInvoke(strTrayID, 2, "", 0, "", null, null);
                    }
                    ToolSet.Log.Info("等待_waitTrayIDCheackHandle完成" + strTrayID);
                    this.variableMap._waitTrayIDCheackHandle.Reset();
                }
            }
            else//已经是2
            {
                controlVCR.CIMAlaram(true);
                WarningLog("10秒后报警自动清除：当前工单尚未生产完毕，请勿上传新的LotID!!!");
                ToolSet.Log.Info("当前工单尚未生产完毕，请勿上传新的LotID!!!");
                Thread.Sleep(10000);
                controlVCR.CIMAlaram(false);
            }
        }

        /// <summary>
        /// 读切割软件的回传数据
        /// 委托异步
        /// </summary>
        /// <param name="str"></param>
        string[] ss = {"0","0","0" };
        public void ReadCutSoftwareMsg(string str)
        {
            string capacityInfo_Shift = "";
            //8:30  ==>    8.5
            double dDataStartTime = (double)CIMparams.m_iDataStartHour + CIMparams.m_iDataStartMin / 60.0;
            int d_dateTime = DateTime.Now.Minute;
            double dd = (DateTime.Now.Hour + d_dateTime / 60.0);
            if ((dd - dDataStartTime) <= 12 && (dd - dDataStartTime) >= 0)
            {
                //是白班
                capacityInfo_Shift = "白班";
            }
            else
            {
                //是夜班
                capacityInfo_Shift = "夜班";
            }
            //if (CIMparams.OfflineMode)
            //{
            //    return;
            //}

            if (str.Contains(cutSoftwareCommunication.GetTactTimeString))
            {
                m_NormalLog(str);
                int a = int.Parse(str.Replace(cutSoftwareCommunication.GetTactTimeString, ""));
                variableMap.CtLToBC_TactTimeTask(a,VariableMap.waitTime);
            }
            else if (str.Contains(cutSoftwareCommunication.CutingUnitStartString))
            {
                m_NormalLog("切割单元开始加工");
                //切割软件给开始加工程序........
            }
            else if (str.Contains(cutSoftwareCommunication.GetCapacityInfoString))
            {
                m_NormalLog(str);
                int a = int.Parse(str.Replace(cutSoftwareCommunication.GetCapacityInfoString, ""));
                if (capacityInfo_Shift == "白班")
                {
                    variableMap.CtLToBC_CapacityInfoTask(a, 1, VariableMap.CapacityInfo_Reason.NormalReporting, VariableMap.waitTime);
                }
                else
                {
                    //夜班
                    variableMap.CtLToBC_CapacityInfoTask(a, 0, VariableMap.CapacityInfo_Reason.NormalReporting, VariableMap.waitTime);
                }
            }
            else if (str.Contains(cutSoftwareCommunication.ClearCapacityInfoString))
            {
                m_NormalLog(str);
                if (capacityInfo_Shift == "白班")
                {
                    variableMap.CtLToBC_CapacityInfoTask(0, 1, VariableMap.CapacityInfo_Reason.ShiftToZero, VariableMap.waitTime);
                }
                else
                {
                    variableMap.CtLToBC_CapacityInfoTask(0, 0, VariableMap.CapacityInfo_Reason.ShiftToZero, VariableMap.waitTime);
                }
            }
            else if (str.Contains(cutSoftwareCommunication.GetProcessDataString))
            {
                m_NormalLog(str);
                //str.Replace((cutSoftwareCommunication.GetProcessDataString),"1,");

                ss = str.Replace(cutSoftwareCommunication.GetProcessDataString, "").Split(','); 
                string strRecipeID = cIMparams.NowRecipeID;
                for (int i = 0; i < controlVCR.StationNumber; i++)
                {
                    //int i1 = (int)(double.Parse(ss[1]) * 1000);
                    try
                    {
                        //2020-09-11
                    //    ToolSet.Log.Info("切割回复ProcessData---" + ss[0] + ss[1] + ss[2]);
                    //    variableMap.CtLToBC_ProcessDataTask(strRecipeID, (int)(double.Parse(ss[0]) * 1000), (int)(double.Parse(ss[1]) * 1000),
                    //        /*(int)(double.Parse(ss[2]) * 1000),*/ controlVCR.StationPanelID[i], VariableMap.waitTime);//发送制程参数
                    }
                    catch (Exception e)
                    {
                        ToolSet.Log.Info("切割回复ProcessData---RecipeID格式不正确: " + cIMparams.NowRecipeID);
                        m_NormalLog("切割回复ProcessData---RecipeID格式不正确: " + cIMparams.NowRecipeID);
                        //MessageBox.Show(e.ToString());
                    }
                }
                    
            }
        }
        //发送PanelID信息到BC
        public void SendPanelID()
        {
            string TrayID = "";
            if (this.controlVCR.LotUnlimited)
            {
                TrayID = this.CIMparams.NowTrayID;
            }
            if (controlBCR.queueInTrayID.Count != 0)
            {
                TrayID = controlBCR.queueInTrayID.Peek();
            }

            for (int i = 0; i < controlVCR.StationNumber; i++)
            {
                this.variableMap._waitPanelIDCheackHandle.Reset();
                variableMap.CtLToBC_PanelInfoRequestTask(controlVCR.StationPanelID[i], TrayID, VariableMap.waitTime);
                //LH 4000->8000
                if (!this.variableMap._waitPanelIDCheackHandle.WaitOne(8000)) //线程同步事件
                {
                    ToolSet.Log.Info("BC端对PanelID无验证消息下发");
                    //variableMap.BCPNLValidationCanReadEvent.BeginInvoke(controlVCR.StationPanelID[i],2,null,null);
                }
                else
                {
                    ToolSet.Log.Info("BC端对PanelID验证完成");
                }
                this.variableMap._waitPanelIDCheackHandle.Reset();
            }
            ToolSet.Log.Info("发送Panel给BC完成!");
        }
        public void ReadBCDateTime(string dataTime)//从BC端获取时间更改本地时间
        {
            SetSystemTime(dataTime);
            m_NormalLog("DateTime:" + dataTime);
        }
        public void ReadBCMessage(string Msg)
        {
            BCWarningLog("BCMessage:" + Msg);
        }
        string WarningMsg = "";
       /// <summary>
       /// 将6次从BC端获取的信息存放，并触发VCR对比判定
       /// </summary>
       /// <param name="sender"></param>
       /// <param name="e"></param>
        public void ReadBCPanelMsg(string RstrPanelID, int PanelRTCode)
        {
            for (int k = 0; k < controlVCR.StationNumber; k++)
            {
                if (RstrPanelID.Contains(controlVCR.StationPanelID[k]))
                {
                    ToolSet.Log.Info("3-判定值PanelRTCode"+ PanelRTCode.ToString());
                    if (PanelRTCode == 2)
                    {
                        WarningMsg = WarningMsg + string.Format("工位{0}---BC-Panel回复异常，请查看对面机台是否有此报警，\r\n" +
                            "如果有请联系CIM部门，没有请重启CIM软件！！！\r\n", k);
                    }
                    if(PanelRTCode == 1)
                    {
                        WarningMsg = WarningMsg + string.Format("工位{0}---BC端验证NG，混料！混料！\r\n", k);
                    }
                    controlVCR.ReadStationPanelID[k] = RstrPanelID;
                    controlVCR.ReadStationVCRCheck[k] = (PanelRTCode == 0); //0-OK,1-NG
                    ControlVCR.ReadFromBCStationCount = k;
                    BCNormalLog(ControlVCR.ReadFromBCStationCount.ToString() + ":  " + controlVCR.StationPanelID[ControlVCR.ReadFromBCStationCount]);
                }
            }
            BCNormalLog("BCPanelMsg：" + "第" + (ControlVCR.ReadFromBCStationCount+1).ToString() + "工位" + RstrPanelID + "  " + PanelRTCode.ToString());
            m_NormalLog(ControlVCR.ReadFromBCStationCount.ToString());

            if (ControlVCR.ReadFromBCStationCount == (controlVCR.StationNumber-1))//读取六次BC端的panelID验证之后，进入VCR确认阶段
            {
                VCRFlow();
            }
        }

       /// <summary>
       /// 思路:每次读6片，上传，看BC回馈信息是否OK，如果OK，继续往下流；如果NG的话，就Remove掉所有，从新启动读码流程
       /// </summary>
        public void VCRFlow()
        {
            ToolSet.Log.Info("进入VCRFlow");
            m_NormalLog("进入VCRFlow");
            string str = "";
            controlVCR.AllReadStationVCRCheck = true;
            for (int i = 0; i < controlVCR.StationNumber; i++)//核实6个有没有NG品
            {
                ToolSet.Log.Info(string.Format("{0}对比核实:BC回传码:{1},VCR读码:{2},回传结果：{3}",i+1, controlVCR.ReadStationPanelID[i], controlVCR.StationPanelID[i], controlVCR.ReadStationVCRCheck[i]));
                controlVCR.AllReadStationVCRCheck = controlVCR.AllReadStationVCRCheck && controlVCR.ReadStationVCRCheck[i];
                if (!controlVCR.ReadStationPanelID[i].Contains(controlVCR.StationPanelID[i]))
                {                  
                    str = str + string.Format("工位{0}核对{1}\r\n", i, controlVCR.ReadStationVCRCheck[i]);
                    ToolSet.Log.Info("核实6个有没有NG品" + controlVCR.ReadStationVCRCheck[i]);
                }
            }
            //更新VCR界面显示验证结果，以及把数据存入数据库
            if (variableMap.BCPNLValidationDisplayEvent != null)
            {
                variableMap.BCPNLValidationDisplayEvent.BeginInvoke(controlVCR.ReadStationVCRCheck, null, null);
            }
            //PlanID全部核对OK
            if (controlVCR.AllReadStationVCRCheck)//如果OK，就保存下来继续往下流
            {
                PanelIDMessageClass panelIDMsg = new PanelIDMessageClass();
                for (int i = 0; i < controlVCR.StationNumber; i++)
                {
                    panelIDMsg.PanelID[i] = controlVCR.StationPanelID[i];
                }
                panelIDMsg.bFeedUnitIN = true;
                controlVCR.queueLastStationPanelID.Enqueue(panelIDMsg);//将读码成功的数据入队
                for (int i = 0; i < controlVCR.StationNumber; i++)
                {
                    controlVCR.LastStationPanelID[i] = controlVCR.StationPanelID[i];
                }
                ToolSet.Log.Info("PlanID全部核对OK");
                ToolSet.Log.Info("controlVCR.queueLastStationPanelID.Count：" + controlVCR.queueLastStationPanelID.Count()); 
                controlVCR.W_CheakBCReadPanelIDOK(true);
                m_NormalLog("上料-" + panelIDMsg.PanelID[0].ToString());
                //记录trayID
                //CIMparams.ReadPrm();

                if (CIMparams.NowPlateNum > 0)
                {
                    CIMparams.NowPlateNum--;
                }
                //CIMparams.SavePrm();
                if (DisplayNowPlateNum != null)
                {
                    DisplayNowPlateNum(CIMparams.NowPlateNum);
                }

                //CIMparams.SavePrm();
                //加工完毕且不是无限Lot模式
                if ((CIMparams.NowPlateNum <= 0))   //当前使用工单号对应的可使用盘数已经用完
                {
                    if (this.controlVCR.LotUnlimited)
                    {
                        CIMparams.NowPlateNum = CIMparams.NowSetPlateNum;
                        m_NormalLog("无限上报模式中!!!");
                    }
                    else
                    {
                        if (controlBCR.queueInTrayID.Count == 0)//Tray队列已经清空
                        {
                            controlVCR.WorkOrderOff = true;//用尽
                            controlVCR.W_StopFeedAndFinish(true);//暂停上下料，等待扫码
                            m_WarningLog("当前工单的工件已经全部加工完毕，请上传新的TrayID!!!");
                        }
                        else 
                        {
                            ToolSet.Log.Info("TrayID出队列");
                            controlBCR.queueInTrayID.Dequeue();//出队列
                            if (controlBCR.queueInTrayID.Count == 0)//Tray队列已经清空
                            {
                                controlVCR.WorkOrderOff = true;//用尽
                                controlVCR.W_StopFeedAndFinish(true);//暂停上下料，等待扫码
                                m_WarningLog("当前工单的工件已经全部加工完毕，请上传新的TrayID!!!");
                                
                            }
                            //更新Tray相关计数，以及Tray界面显示
                            if (DispalyBCREvent != null)
                            {
                                DispalyBCREvent.BeginInvoke(null, null);
                            }
                        }              
                    }
                }
            }
            else//如果有NG品，就Remove上传的6片，再拔片重新读码上传操作
            {
                cutSoftwareCommunication.cutingUnitNG();               
                controlVCR.W_CheakBCReadPanelIDNG(true);
               // str = str + "出现混料！出现混料！\r\n请按步骤操作：\r\n" + "1、将对中台上的玻璃片取下。\r\n2、放6片新的玻璃片到对中台上。\r\n3、点击软件上“重新读码”按钮！";
                m_NormalLog("核对信息：" + WarningMsg);               
                this.controlVCR.CIMAlaram(true);
                WarningLog(WarningMsg);
                WarningMsg = "";//清空信息
                ToolSet.Log.Info("有NG品,就Remove上传的6片，再拔片重新读码上传操作");
                for (int i = 0; i < controlVCR.StationNumber; i++)
                {
                    variableMap.CtLToBC_PanelRemoveTask(controlVCR.StationPanelID[i], VariableMap.waitTime);
                    //if (!this.variableMap._waitPanelRemoveCheackHandle.WaitOne(4000, true)) //线程同步事件
                    //{
                    //    ToolSet.Log.Info("PanelRemove---BC端无回复！");
                    //}               
                }
            }
            this.controlVCR.ReadCodeFlow = false;
        }
        //扫描枪扫完TrayID以后验证
        public void ReadBCTrayMsg(string RstrTrayID, int TrayRTCode,string WorkOrderID,int Quantity,string RecipeID)
        {
            ToolSet.Log.Info("BCTrayID验证进入确认，修改界面!");
            if (TrayRTCode == 0)//0-OK,1-NG
            {
                if (controlBCR.queueInTrayID.Count == 0)
                {
                    this.controlVCR.WorkOrderOff = false;
                    controlBCR.queueInTrayID.Enqueue(RstrTrayID);
                    controlBCR.queueOutTrayID.Enqueue(RstrTrayID);
                    controlVCR.W_StopFeedAndFinish(false);//确定上下料
                    cIMparams.NowTrayID = RstrTrayID;
                    CIMparams.NowWorkOrderID = WorkOrderID;
                    CIMparams.NowRecipeID = RecipeID;
                    CIMparams.NowSetPlateNum = Quantity / 6;
                    CIMparams.NowPlateNum = Quantity / 6;
                }
                else// 1
                {
                    this.controlVCR.WorkOrderOff = false;
                    controlBCR.queueInTrayID.Enqueue(RstrTrayID);
                    controlBCR.queueOutTrayID.Enqueue(RstrTrayID);
                    controlVCR.W_StopFeedAndFinish(false);//确定上下料
                    cIMparams.NextTrayID = RstrTrayID;
                    CIMparams.NextWorkOrderID = WorkOrderID;
                    CIMparams.NextRecipeID = RecipeID;
                    CIMparams.NextSetPlateNum = Quantity / 6;
                }
                CIMparams.SavePrm();
                ele1.Save(file_B);

                WarningLog("TrayID上传成功，请点击上下料启动按钮开始加工。");
            }
            else
            {
                controlVCR.W_StopFeedAndFinish(true);//暂停上下料，等待扫码
                WarningLog("TrayID:" + RstrTrayID + " NG\r\n工单号:" + WorkOrderID + "\r\n产品型号:" + RecipeID + " \r\nQuantity:" + Quantity.ToString() +  "\r\n请查验TrayID,并重新扫码.");
            }
        }
        /// <summary>
        /// 设置系统时间
        /// </summary>
        public void SetSystemTime(string dateTime)
        {
            SystemTime systemTime = new TimeOperate.SystemTime();
            List<char> datatime = new List<char>();
            datatime.AddRange(dateTime.ToCharArray());
            if (datatime.Count < 14)
            {
                return;
            }
            systemTime.year = ushort.Parse(string.Join("", datatime.GetRange(0, 4).ToArray()));
            systemTime.month = ushort.Parse(string.Join("", datatime.GetRange(4, 2).ToArray()));
            systemTime.day = ushort.Parse(string.Join("", datatime.GetRange(6, 2).ToArray()));
            systemTime.hour = ushort.Parse(string.Join("", datatime.GetRange(8, 2).ToArray()));
            systemTime.minute = ushort.Parse(string.Join("", datatime.GetRange(10, 2).ToArray()));
            systemTime.second = ushort.Parse(string.Join("", datatime.GetRange(12, 2).ToArray()));
            systemTime.milliseconds = 0;
            TimeAPI.SetLocalTime(ref systemTime);
        }
        public string GetLogSystemTime()
        {
            SystemTime systemTime = new TimeOperate.SystemTime();
            TimeAPI.GetLocalTime(ref systemTime);
            string datatime = systemTime.hour.ToString() + ":" + systemTime.minute.ToString() + ":" + systemTime.second.ToString() + "---";
            return datatime;
        }
        public string GetSystemTime()
        {
            SystemTime systemTime = new TimeOperate.SystemTime();
            TimeAPI.GetLocalTime(ref systemTime);
            string datatime = systemTime.year.ToString("00") + systemTime.month.ToString("00") + systemTime.day.ToString("00") + systemTime.hour.ToString("00") + systemTime.minute.ToString("00") + systemTime.second.ToString("00");
            return datatime;
        }
       /// <summary>
       /// VCR读码成功，发送数据给BC
       /// </summary>
        public void startSendPanelIDToBC()
        {
            //if (controlBCR.queueInTrayID.Count != 0)
            //{
                SendPanelID();
            //}
            //else
            //{
            //    controlVCR.WorkOrderOff = true;//用尽
            //    controlVCR.W_StopFeedAndFinish(true);//暂停上下料，等待扫码
            //    m_WarningLog("当前工单的工件已经全部加工完毕，请上传新的TrayID!!!");
            //}
        }
        public void startSendPanelIDToDispaly(bool[] check)//放到主界面
        {
            //CIMparams.ReadPrm();
            string str = "";
            for (int i = 0; i < controlVCR.StationNumber; i++)
            {
                if (check[i] == false)
                {
                    CIMparams.ReadNGNum++;
                    CIMparams.DayReadNGNum++;
                    str = str + string.Format("第{0}工位读码失败\r\n", i + 1);
                }
                else
                {
                    CIMparams.ReadOKNum++;
                    CIMparams.DayReadOKNum++;
                }
            }
            if (DispalyReadOKRateEvent != null)
            {
                DispalyReadOKRateEvent();
            }
            if (!this.controlVCR.checkAutoJumpNG)
            {
                WarningLog("VCR报警信息： " + str);
                ToolSet.Log.Info("VCR报警信息： " + str);
            }
        }


        //计时
        DateTime dt = new DateTime();
        
        public void DataTime_start(ref bool d,string s)
        {
            VariableMap.EQP_ReasonCode = 0;
            dt = DateTime.Now;
            d = true;
            try
            {
                //if (btn_CIMAlive.Text == "CIM离线")
                //{

                //}
                VariableMap.EqpStatus eqpStatus = VariableMap.EqpStatus.II;
                if (s == "PM")
                {
                    eqpStatus = VariableMap.EqpStatus.PM;
                }
                if (s == "MC")
                {
                    eqpStatus = VariableMap.EqpStatus.MC;

                }
                variableMap.CtLToBC_EqpStatusTask(eqpStatus, VariableMap.waitTime);

            }
            catch (Exception)
            {
                
            }
        }
        public void DataTime_stop(ref bool d,string s)
        {
            VariableMap.EQP_ReasonCode = 1;
            TimeSpan ts = DateTime.Now - dt;
            d = false;
            try
            {
                //if (btn_CIMAlive.Text == "CIM离线")
                //{

                //}
                VariableMap.EqpStatus eqpStatus = VariableMap.EqpStatus.II;
                if (s == "PM")
                {
                    eqpStatus = VariableMap.EqpStatus.PM;
                }
                if (s == "MC")
                {
                    eqpStatus = VariableMap.EqpStatus.MC;

                }
                variableMap.CtLToBC_EqpStatusTask(eqpStatus, VariableMap.waitTime);

            }
            catch (Exception)
            {
                variableMap.Dipose();
            }
            MessageBox.Show(string.Format("{0}小时{1}分钟{2}秒",ts.Hours,ts.Minutes,ts.Seconds));

        }
        #region 打印到界面文件
        public void m_NormalLog(string msg)
        {
            if (NormalLog != null)
            {
               NormalLog(msg);
            }
        }
        public void m_WarningLog(string msg)
        {
            if (WarningLog != null)
            {
                WarningLog(msg);
            }
        }
        #endregion
    }
}
