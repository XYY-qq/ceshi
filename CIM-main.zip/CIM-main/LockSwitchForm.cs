﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CIM通讯
{
    public partial class LockSwitchForm : Form
    {
        private string key = "";
        public static event Action KeyRightEvent;
        public static event Action KeyRightEvent_2;
        public static event Action KeyErrorEvent;

        public LockSwitchForm(string key)
        {
            InitializeComponent();
            this.key = key;
        }

        private void LockSwitchForm_Load(object sender, EventArgs e)
        {

        }
        bool ssss = false;
        public void ss(bool s)
        {
            ssss = s;
        }
        private void btn_ok_Click(object sender, EventArgs e)
        {
            if (key == tb_LockSwitchKey.Text)
            {
                //打开门锁
                if (KeyRightEvent != null)
                {
                    if (ssss)
                    {
                        KeyRightEvent_2();
                        this.Close();
                    }
                    else
                    {
                        KeyRightEvent();
                    }
                    
                }
            }
            else
            {
                
                MessageBox.Show("密码输入错误，请重新输入！");
            }
            //点击确定以后清空输入框
            tb_LockSwitchKey.Clear();
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       
    }
}
