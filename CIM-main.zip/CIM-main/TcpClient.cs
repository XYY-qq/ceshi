﻿using System;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace CIM通讯
{
    class TcpClient
    {
        public bool bConnected = false;
        public int count = 0;
        private Thread threadClient = null; // 创建用于接收服务端消息的线程；
        private Socket sockClient = null;   //创建客户端的套接字
        private IPAddress ip = null;        //IP地址
        private int port;                   //端口号
        private IPEndPoint endPoint = null; //网络端点

        public event Action<string> TCPExceptionEvent;
        public delegate void TcpClientReceiveEventHandler(string str);
        public event TcpClientReceiveEventHandler TcpClientReceiveEvent;

        public TcpClient(IPAddress ip, int port)
        {
            this.ip = ip;
            this.port = port;
            endPoint = new IPEndPoint(ip, port);
            sockClient = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        }
        public void Connected()
        {
            try
            {
                sockClient.Connect(endPoint);
                bConnected = true;
            }
            catch (Exception se)
            {
                bConnected = false;
                ToolSet.Log.Info("与切割软件TCP连接失败！请打开切割软件，再在CIM软件上尝试重新连接TCP!");
                MessageBox.Show("与切割软件TCP连接失败！请打开切割软件，再在CIM软件上尝试重新连接TCP!");
                return;
            }
            string str = "";
            //threadClient = new Thread(RecMsg);
            threadClient = new Thread(() =>
            {
                Thread.Sleep(10);
                RecMsg(ref str);
            });
            threadClient.IsBackground = true;
            threadClient.Start();

        }
        public void SendMsg(string str)
        {
            try
            {
                if (bConnected)
                {
                    byte[] arrMsg = System.Text.Encoding.UTF8.GetBytes(str);
                    sockClient.Send(arrMsg); // 发送消息；
                }
            }
            catch (Exception x)
            {
                ToolSet.Log.Info(x.ToString() + "\r\n" + "与切割软件TCP连接失败！请重启CIM软件！");
                TCPExceptionEvent(x.ToString() + "\r\n" + "与切割软件TCP连接失败！请重启CIM软件！");

            }
        }
        private void RecMsg(ref string strMsg)
        {
            while (true)
            {
                count++;
                // 定义一个2M的缓存区；
                byte[] arrMsgRec = new byte[1024 * 1024 * 2];
                // 将接受到的数据存入到输入  arrMsgRec中；
                int length = -1;
                try
                {
                    length = sockClient.Receive(arrMsgRec); // 接收数据，并返回数据的长度；
                    strMsg = System.Text.Encoding.UTF8.GetString(arrMsgRec, 0, length);
                    if (TcpClientReceiveEvent != null)
                    {
                        TcpClientReceiveEvent(strMsg);
                    }
                }
                catch (SocketException)
                {
                    return;
                }
                catch (Exception)
                {
                    return;
                }
            }
        }

        public void Close()
        {
            sockClient.Close();
            sockClient.Dispose();
        }
    }
}
