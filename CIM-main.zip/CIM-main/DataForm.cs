﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CIM通讯
{
    public partial class DataForm : Form
    {
        private CIMMainClass CIMMain;

        public DataForm(CIMMainClass cimMain)
        {
            InitializeComponent();
            CIMMain = cimMain;
        }

        private void DataForm_Load(object sender, EventArgs e)
        {
            dateTimePicker_Start.Value = DateTime.Now;
            dateTimePicker_End.Value = DateTime.Now;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CIMMain.QueryTableByDay(listView1, dateTimePicker_Start.Value, dateTimePicker_End.Value);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string strTrayID = text_Tray.Text;
            if(strTrayID == "")
            {
                MessageBox.Show("TrayID不能为空！");
                return;
            }

            CIMMain.QueryTableByTray(listView1, strTrayID);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string strPanelID = text_Panel.Text;
            if (strPanelID == "")
            {
                MessageBox.Show("PanelID不能为空！");
                return;
            }

            CIMMain.QueryTableByPanel(listView1, strPanelID);
        }

        private void button_ToExcel_Click(object sender, EventArgs e)
        {
            CIMMain.ToExcel(dateTimePicker_Start.Value, dateTimePicker_End.Value);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            CIMData data = new CIMData();
            data.Datatime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            data.PanelID = "Panel123";
            data.TrayID = "Tray123";
            CIMMain.InsertInfo(data);
        }
    }
}
