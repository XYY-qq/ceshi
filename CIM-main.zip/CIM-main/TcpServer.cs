﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;  // IP，IPAddress, IPEndPoint，端口等；
using System.Threading;
using System.IO;

namespace CIM通讯
{
    class TcpServer
    {
        Thread threadWatch = null; // 负责监听客户端连接请求的 线程；
        Socket socketWatch = null;
        private IPAddress ip = null;        //IP地址
        private int port;                   //端口号
        private IPEndPoint endPoint = null; //网络端点
        Dictionary<string, Socket> dict = new Dictionary<string, Socket>();
        Dictionary<string, Thread> dictThread = new Dictionary<string, Thread>();

        /// <summary>
        /// 服务器构造函数
        /// </summary>
        /// <param name="ip"></param>
        /// <param name="port"></param>
        public TcpServer(IPAddress ip, int port)
        {
            this.ip = ip;
            this.port = port;
            endPoint = new IPEndPoint(ip, port);
            socketWatch = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        }

        public void Bind(int length)
        {
            try
            {
                // 将负责监听的套接字绑定到唯一的ip和端口上；
                socketWatch.Bind(endPoint);
            }
            catch (SocketException se)
            {
                MessageBox.Show("异常：" + se.Message);
                return;
            }
            // 设置监听队列的长度；
            socketWatch.Listen(length);
            // 创建负责监听的线程；
            threadWatch = new Thread(WatchConnecting);
            threadWatch.IsBackground = true;
            threadWatch.Start();
            MessageBox.Show("S --- 服务器启动监听成功！");
        }

        /// <summary>
        /// 监控连接
        /// </summary>
        private void WatchConnecting()
        {
            while (true)  // 持续不断的监听客户端的连接请求；
            {
                // 开始监听客户端连接请求，Accept方法会阻断当前的线程；
                Socket sokConnection = socketWatch.Accept(); // 一旦监听到一个客户端的请求，就返回一个与该客户端通信的 套接字；
                // 将与客户端连接的 套接字 对象添加到集合中；
                dict.Add(sokConnection.RemoteEndPoint.ToString(), sokConnection);
                //MessageBox.Show("S --- 客户端连接成功！");
                Thread thr = new Thread(RecMsg);
                thr.IsBackground = true;
                thr.Start(sokConnection);
                dictThread.Add(sokConnection.RemoteEndPoint.ToString(), thr);  //  将新建的线程 添加 到线程的集合中去。
            }
        }
        /// <summary>
        /// 接受对应socket中的数据
        /// </summary>
        /// <param name="sokConnectionparn"></param>
        private void RecMsg(object sokConnectionparn)
        {
            Socket sokClient = sokConnectionparn as Socket;
            while (true)
            {
                // 定义一个2M的缓存区；
                byte[] arrMsgRec = new byte[1024 * 1024 * 2];
                // 将接受到的数据存入到输入  arrMsgRec中；
                int length = -1;
                try
                {
                    length = sokClient.Receive(arrMsgRec); // 接收数据，并返回数据的长度；
                }
                catch (SocketException)
                {
                    // MessageBox.Show("S --- 异常：" + se.Message);
                    // 从 通信套接字 集合中删除被中断连接的通信套接字；
                    dict.Remove(sokClient.RemoteEndPoint.ToString());
                    // 从通信线程集合中删除被中断连接的通信线程对象；
                    dictThread.Remove(sokClient.RemoteEndPoint.ToString());
                    break;
                }
                catch (Exception)
                {
                    //MessageBox.Show("S --- 异常：" + e.Message);
                    // 从 通信套接字 集合中删除被中断连接的通信套接字；
                    dict.Remove(sokClient.RemoteEndPoint.ToString());
                    // 从通信线程集合中删除被中断连接的通信线程对象；
                    dictThread.Remove(sokClient.RemoteEndPoint.ToString());
                    break;
                }
            }
        }

        /// <summary>
        /// 给指定客户端发送信息
        /// </summary>
        /// <param name="iPEndPoint"></param>
        /// <param name="Msg"></param>
        private void SendMsg(IPEndPoint iPEndPoint, string Msg)
        {
            byte[] arrMsg = System.Text.Encoding.UTF8.GetBytes(Msg); // 将要发送的字符串转换成Utf-8字节数组；  
            dict[iPEndPoint.ToString()].Send(arrMsg);// 解决了 sokConnection是局部变量，不能再本函数中引用的问题；
        }
        /// <summary>
        /// 群发信息给所有的客户端
        /// </summary>
        /// <param name="Msg"></param>
        public void SendMsgToAll(string Msg)
        {
            byte[] arrMsg = System.Text.Encoding.UTF8.GetBytes(Msg); // 将要发送的字符串转换成Utf-8字节数组；
            foreach (Socket s in dict.Values)
            {
                s.Send(arrMsg);
            }
        }
    }
}
