﻿using System.Windows.Forms;
using TimeOperate;
using System.Threading;
using System.Threading.Tasks;

namespace CIM通讯
{
    /// <summary>
    /// 调试中出现一个问题，主界面按钮触发事件的函数是同步触发，事件也是在主线程中执行，
    /// 然后在事件函数中创建一个Task任务，任务执行完毕之后，会.Wait.One(),task.wait();
    /// 这样就会阻塞线程实现同步，由于dll中开放的事件也是同步的，所以也在主线程中执行，
    /// Task线程又在等待这个事件的触发，会阻塞UI线程等待。但是主线程被阻塞了，所以dll中
    /// 的事件无法触发。
    /// EqpRepairEvent.BeginInvoke
    /// 分析：EqpRepairEvent.BeginInvoke
    /// </summary>
    public partial class EqpRepairForm : Form
    {
        public enum EqpRepairFlow
        {
            CallEqpRepair = 0,
            EqpRepairStart = 1,
            EqpRepairEnd = 2,
        }
        CIMMainClass cIMMainClass = null;
        public delegate void EqpRepairFlowEventHandler(EqpRepairFlow eqpRepairFlow);
        public static event EqpRepairFlowEventHandler EqpRepairFlowEvent;

        public delegate void EqpRepairEventHandler(VariableMap.EqpRepair_Action eqpRepair_Action);
        public event EqpRepairEventHandler EqpRepairEvent;

        public EqpRepairForm(CIMMainClass cIMMainClass, EqpRepairFlow eqpRepairFlow)
        {
            InitializeComponent();
            this.cIMMainClass = cIMMainClass;
            EqpRepairEvent += new EqpRepairEventHandler(EqpRepairSendEvent);
            switch (eqpRepairFlow)
            {
                case EqpRepairFlow.CallEqpRepair:
                    {
                        btn_Call.Enabled = false;
                        btn_Repair.Enabled = true;
                        btn_End.Enabled = false;
                        tb_CallOperatorID.Enabled = false;
                        tb_RepairOperatorID.Enabled = true;
                        tb_EndOperatorID.Enabled = false;

                        tb_CallOperatorID.Text = CIMMainForm.CallOperatorID;
                    }
                    break;
                case EqpRepairFlow.EqpRepairStart:
                    {
                        btn_Call.Enabled = false;
                        btn_Repair.Enabled = false;
                        btn_End.Enabled = true;
                        tb_CallOperatorID.Enabled = false;
                        tb_RepairOperatorID.Enabled = false;
                        tb_EndOperatorID.Enabled = true;

                        tb_CallOperatorID.Text = CIMMainForm.CallOperatorID;
                        tb_RepairOperatorID.Text = CIMMainForm.StartRepairOperatorID;
                    }
                    break;
                case EqpRepairFlow.EqpRepairEnd:
                    {
                        btn_Call.Enabled = true;
                        btn_Repair.Enabled = false;
                        btn_End.Enabled = false;
                        tb_CallOperatorID.Enabled = true;
                        tb_RepairOperatorID.Enabled = false;
                        tb_EndOperatorID.Enabled = false;
                    }
                    break;
            }
        }
        public void EqpRepairSendEvent(VariableMap.EqpRepair_Action eqpRepair_Action)
        {
            cIMMainClass.variableMap.CtLToBC_EqpRepairTask(eqpRepair_Action, VariableMap.waitTime);
        }
        //开始叫修
        private void btn_Call_Click(object sender, System.EventArgs e)
        {
            if (tb_CallOperatorID.Text == "")
            {
                MessageBox.Show("CallOperatorID不能为空！！");
                return;
            }

            VariableMap.strCallOperatorID = tb_CallOperatorID.Text;
            CIMMainForm.CallOperatorID = tb_CallOperatorID.Text;

            //
            CIMMainForm.CallEqpRepairTime = cIMMainClass.GetSystemTime();
            VariableMap.strCallStartTime = CIMMainForm.CallEqpRepairTime;
            tb_CallStartTime.Text = CIMMainForm.CallEqpRepairTime;
            //

            VariableMap.strRepairOperatorID = "";
            VariableMap.strRepairStartTime = "";
            VariableMap.strEndOperatorID = "";
            VariableMap.strEndTime = ""; 
            btn_Call.Enabled = false;
            btn_Repair.Enabled = true;
            btn_End.Enabled = false;

            tb_CallOperatorID.Enabled = false;
            tb_RepairOperatorID.Enabled = true;
            tb_EndOperatorID.Enabled = false;

            if (EqpRepairFlowEvent != null)
            {
                EqpRepairFlowEvent.BeginInvoke(EqpRepairFlow.CallEqpRepair,null,null);
            }
            if (EqpRepairEvent != null)
            {
                EqpRepairEvent.BeginInvoke(VariableMap.EqpRepair_Action.CallStart,null,null);
            }
        }
        //开始修
        private void btn_Repair_Click(object sender, System.EventArgs e)
        {
            if (tb_RepairOperatorID.Text == "")
            {
                MessageBox.Show("RepairOperatorID不能为空！！");
                return;
            }
            //
            tb_CallOperatorID.Text = CIMMainForm.CallOperatorID;
            VariableMap.strCallOperatorID = CIMMainForm.CallOperatorID;

            VariableMap.strRepairOperatorID = tb_RepairOperatorID.Text;
            CIMMainForm.StartRepairOperatorID = tb_RepairOperatorID.Text;
            //

            VariableMap.strCallStartTime = CIMMainForm.CallEqpRepairTime;
            tb_CallStartTime.Text = CIMMainForm.CallEqpRepairTime;

            //         
            CIMMainForm.RepairStartTime = cIMMainClass.GetSystemTime(); 
            VariableMap.strRepairStartTime = CIMMainForm.RepairStartTime;
            tb_RepairStartTime.Text = CIMMainForm.RepairStartTime;
            //

            VariableMap.strEndOperatorID = "";
            VariableMap.strEndTime = ""; 
            btn_Call.Enabled = false;
            btn_Repair.Enabled = false;
            btn_End.Enabled = true;

            tb_CallOperatorID.Enabled = false;
            tb_RepairOperatorID.Enabled = false;
            tb_EndOperatorID.Enabled = true;
            if (EqpRepairFlowEvent != null)
            {
                EqpRepairFlowEvent.BeginInvoke(EqpRepairFlow.EqpRepairStart, null, null);
            }

            if (EqpRepairEvent != null)
            {
                EqpRepairEvent.BeginInvoke(VariableMap.EqpRepair_Action.RepairStart, null, null);
            }
        }
        //修完了
        private void btn_End_Click(object sender, System.EventArgs e)
        {
            if (tb_EndOperatorID.Text == "")
            {
                MessageBox.Show("EndOperatorID不能为空！！");
                return;
            }
            //
            tb_CallOperatorID.Text = CIMMainForm.CallOperatorID;
            VariableMap.strCallOperatorID = CIMMainForm.CallOperatorID;

            tb_RepairOperatorID.Text = CIMMainForm.StartRepairOperatorID;
            VariableMap.strRepairOperatorID = CIMMainForm.StartRepairOperatorID;

            VariableMap.strEndOperatorID = tb_EndOperatorID.Text;
            CIMMainForm.EndOperatorID = tb_EndOperatorID.Text;
            //

            VariableMap.strCallStartTime = CIMMainForm.CallEqpRepairTime;
            tb_CallStartTime.Text = CIMMainForm.CallEqpRepairTime;

            VariableMap.strRepairStartTime = CIMMainForm.RepairStartTime;
            tb_RepairStartTime.Text = CIMMainForm.RepairStartTime;

            //         
            CIMMainForm.EqpRepairEndTime = cIMMainClass.GetSystemTime();
            VariableMap.strEndTime = CIMMainForm.EqpRepairEndTime;
            tb_EndTime.Text = CIMMainForm.EqpRepairEndTime;
            //

            btn_Call.Enabled = true;
            btn_Repair.Enabled = false;
            btn_End.Enabled = false;

            tb_CallOperatorID.Enabled = true;
            tb_RepairOperatorID.Enabled = false;
            tb_EndOperatorID.Enabled = false;

            if (EqpRepairFlowEvent != null)
            {
                EqpRepairFlowEvent.BeginInvoke(EqpRepairFlow.EqpRepairEnd,null,null);
            }
            if (EqpRepairEvent != null)
            {
                EqpRepairEvent.BeginInvoke(VariableMap.EqpRepair_Action.End, null, null);
            }

        }
    }
}
