﻿using OMRON.Compolet.Variable;
using OMRON.FinsGateway.EventMemory;
using System;
using System.Windows.Forms;
using System.Threading;
using System.Collections.Generic;
using System.Collections;

namespace CIM通讯
{
    public class MACGatewayMsg
    {
        public string CTL_EventChanged;
        public string EventChanged;
        public List<int> EventMessage = new List<int>();
    }
    public class SYSMACGateway
    {
        public static bool CIMModeFlag = false; //记录CIMMode,控制CIM通信
        public static bool CIMFlowFlag = false;
        public static int CIMFlowID = -1;
        public CIMParams CIMparams = null;
        public bool m_bOfflineMode = false;

        public Dictionary<string, int> dictEventID = new Dictionary<string, int>();//用变量名字索引eventID
        public Dictionary<string, string> dictVariableNames = new Dictionary<string, string>();//存放底层的变量名
        List<string> BCToCtlvariableNames = new List<string>();//记录需要被添加到事件中的变量

        #region 事件和委托
        //线程间通讯，自动reset
        public ManualResetEvent _waitSD_BCToCtL_Event_EqpStatusChangeHandle = new ManualResetEvent(false);
        public ManualResetEvent _waitSD_BCToCtL_Event_AlarmHandle = new ManualResetEvent(false);
        public ManualResetEvent _waitSD_BCToCtL_Event_TactTimeHandle = new ManualResetEvent(false);
        public ManualResetEvent _waitSD_BCToCtL_Event_PanelInfoRequestHandle = new ManualResetEvent(false);
        public ManualResetEvent _waitSD_BCToCtL_Event_PanelReceiveHandle = new ManualResetEvent(false);
        public ManualResetEvent _waitSD_BCToCtL_Event_ProcessStartHandle = new ManualResetEvent(false);
        public ManualResetEvent _waitSD_BCToCtL_Event_PanelUnitIn1Handle = new ManualResetEvent(false);
        public ManualResetEvent _waitSD_BCToCtL_Event_PanelUnitIn2Handle = new ManualResetEvent(false);
        public ManualResetEvent _waitSD_BCToCtL_Event_ProcessDataHandle = new ManualResetEvent(false);
        public ManualResetEvent _waitSD_BCToCtL_Event_PanelUnitOut1Handle = new ManualResetEvent(false);
        public ManualResetEvent _waitSD_BCToCtL_Event_PanelUnitOut2Handle = new ManualResetEvent(false);
        public ManualResetEvent _waitSD_BCToCtL_Event_PanelSendOutHandle = new ManualResetEvent(false);
        public ManualResetEvent _waitSD_BCToCtL_Event_PanelRemoveHandle = new ManualResetEvent(false);
        public ManualResetEvent _waitSD_BCToCtL_Event_EqpRepairHandle = new ManualResetEvent(false);
        public ManualResetEvent _waitSD_BCToCtL_Event_TrayInfoRequestHandle = new ManualResetEvent(false);
        public ManualResetEvent _waitSD_BCToCtL_Event_CapacityInfoHandle = new ManualResetEvent(false);

        public ManualResetEvent _waitSD_BCToCtL_Command_MessageHandle = new ManualResetEvent(false); //收到BitOFF之后OFF repaly
        public ManualResetEvent _waitSD_BCToCtL_Command_DateTimeHandle = new ManualResetEvent(false); //收到BitOFF之后OFF repaly
        public ManualResetEvent _waitSD_BCToCtL_Command_TrayValidationHandle = new ManualResetEvent(false); //收到BitOFF之后OFF repaly
        public ManualResetEvent _waitBCToCtL_Command_PNLValidationHandle = new ManualResetEvent(false); //收到BitOFF之后OFF repaly

        #endregion

        protected VariableCompolet variableCompolet = null;
        static protected string eventingName = "";
        static public string EventingName //正在触发的事件，
        {
            get
            {
                return eventingName;
            }
            set
            {
                eventingName = value;
            }
        }
        public string[] variableNames
        {
            get
            {
                return variableCompolet.VariableNames;
            }
        }
        //初始化
        public SYSMACGateway(CIMParams CIMparams)
        {
            CIMparams.ReadPrm();
            this.CIMparams = CIMparams;

            m_bOfflineMode = CIMparams.OfflineMode;
            if (m_bOfflineMode)
                return;

            variableCompolet = new VariableCompolet();

            #region 字典操作
            dictVariableNames.Add("SD_BCToCtL_Command_Message[0]", ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Command_Message[0]"));
            dictVariableNames.Add("SD_BCToCtL_Command_DateTime[0]", ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Command_DateTime[0]"));
            dictVariableNames.Add("SD_BCToCtL_Command_TrayValidation[0]", ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Command_TrayValidation[0]"));
            dictVariableNames.Add("SD_BCToCtL_Command_PNLValidation[0]", ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Command_PNLValidation[0]"));
            dictVariableNames.Add("RV_CtLToBC_Event_EqpAlive", ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_EqpAlive"));
            dictVariableNames.Add("RV_CtLToBC_Event_CIMModeChange", ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_CIMModeChange"));
            dictVariableNames.Add("RV_CtLToBC_Event_EqpStatusChange", ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_EqpStatusChange"));
            dictVariableNames.Add("RV_CtLToBC_Event_Alarm", ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_Alarm"));
            dictVariableNames.Add("RV_CtLToBC_Event_TactTime", ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_TactTime"));
            dictVariableNames.Add("RV_CtLToBC_Event_TrayInfoRequest", ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_TrayInfoRequest"));
            dictVariableNames.Add("RV_CtLToBC_Event_PanelInfoRequest", ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_PanelInfoRequest"));
            dictVariableNames.Add("RV_CtLToBC_Event_PanelReceive", ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_PanelReceive"));
            dictVariableNames.Add("RV_CtLToBC_Event_ProcessStart", ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_ProcessStart"));
            dictVariableNames.Add("RV_CtLToBC_Event_PanelUnitIn1", ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_PanelUnitIn1"));
            dictVariableNames.Add("RV_CtLToBC_Event_PanelUnitIn2", ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_PanelUnitIn2"));
            dictVariableNames.Add("RV_CtLToBC_Event_ProcessData", ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_ProcessData"));
            dictVariableNames.Add("RV_CtLToBC_Event_PanelUnitOut1", ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_PanelUnitOut1"));
            dictVariableNames.Add("RV_CtLToBC_Event_PanelUnitOut2", ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_PanelUnitOut2"));
            dictVariableNames.Add("RV_CtLToBC_Event_PanelSendOut", ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_PanelSendOut"));
            dictVariableNames.Add("RV_CtLToBC_Event_PanelRemove", ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_PanelRemove"));
            dictVariableNames.Add("RV_CtLToBC_Event_EqpRepair", ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_EqpRepair"));
            dictVariableNames.Add("RV_CtLToBC_Command_MessageReply", ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Command_MessageReply"));
            dictVariableNames.Add("RV_CtLToBC_Command_DateTimeReply", ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Command_DateTimeReply"));
            dictVariableNames.Add("RV_CtLToBC_Command_TrayValidationReply", ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Command_TrayValidationReply"));
            dictVariableNames.Add("RV_CtLToBC_Command_PNLValidationReply", ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Command_PNLValidationReply"));
            dictVariableNames.Add("RV_CtLToBC_Event_CapacityInfo", ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_CapacityInfo"));
            dictVariableNames.Add("SD_BCToCtL_Command_BCAlive", ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Command_BCAlive"));
            dictVariableNames.Add("SD_BCToCtL_Command_Message", ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Command_Message"));
            dictVariableNames.Add("SD_BCToCtL_Command_DateTime", ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Command_DateTime"));
            dictVariableNames.Add("SD_BCToCtL_Event_EqpStatusChangeReply", ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Event_EqpStatusChangeReply"));
            dictVariableNames.Add("SD_BCToCtL_Event_AlarmReply", ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Event_AlarmReply"));
            dictVariableNames.Add("SD_BCToCtL_Event_TactTimeReply", ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Event_TactTimeReply"));
            dictVariableNames.Add("SD_BCToCtL_Command_TrayValidation", ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Command_TrayValidation"));
            dictVariableNames.Add("SD_BCToCtL_Event_PanelInfoRequestReply", ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Event_PanelInfoRequestReply"));
            dictVariableNames.Add("SD_BCToCtL_Event_PanelReceiveReply", ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Event_PanelReceiveReply"));
            dictVariableNames.Add("SD_BCToCtL_Event_ProcessStartReply", ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Event_ProcessStartReply"));
            dictVariableNames.Add("SD_BCToCtL_Event_PanelUnitIn1Reply", ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Event_PanelUnitIn1Reply"));
            dictVariableNames.Add("SD_BCToCtL_Event_PanelUnitIn2Reply", ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Event_PanelUnitIn2Reply"));
            dictVariableNames.Add("SD_BCToCtL_Event_ProcessDataReply", ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Event_ProcessDataReply"));
            dictVariableNames.Add("SD_BCToCtL_Event_PanelUnitOut1Reply", ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Event_PanelUnitOut1Reply"));
            dictVariableNames.Add("SD_BCToCtL_Event_PanelUnitOut2Reply", ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Event_PanelUnitOut2Reply"));
            dictVariableNames.Add("SD_BCToCtL_Event_PanelSendOutReply", ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Event_PanelSendOutReply"));
            dictVariableNames.Add("SD_BCToCtL_Event_PanelRemoveReply", ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Event_PanelRemoveReply"));
            dictVariableNames.Add("SD_BCToCtL_Event_EqpRepairReply", ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Event_EqpRepairReply"));
            dictVariableNames.Add("SD_BCToCtL_Event_TrayInfoRequestReply", ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Event_TrayInfoRequestReply"));
            dictVariableNames.Add("SD_BCToCtL_Command_PNLValidation", ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Command_PNLValidation"));
            dictVariableNames.Add("SD_BCToCtL_Event_CapacityInfoReply", ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Event_CapacityInfoReply"));
            if (CIMparams.Prefix != "CtL")
            {
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Command_Message[0]"),"SD_BCToCtL_Command_Message[0]");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Command_DateTime[0]"),"SD_BCToCtL_Command_DateTime[0]");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Command_TrayValidation[0]"),"SD_BCToCtL_Command_TrayValidation[0]");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Command_PNLValidation[0]"),"SD_BCToCtL_Command_PNLValidation[0]");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_EqpAlive"),"RV_CtLToBC_Event_EqpAlive");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_CIMModeChange"),"RV_CtLToBC_Event_CIMModeChange");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_EqpStatusChange"),"RV_CtLToBC_Event_EqpStatusChange");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_Alarm"),"RV_CtLToBC_Event_Alarm");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_TactTime"),"RV_CtLToBC_Event_TactTime");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_TrayInfoRequest"),"RV_CtLToBC_Event_TrayInfoRequest");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_PanelInfoRequest"),"RV_CtLToBC_Event_PanelInfoRequest");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_PanelReceive"),"RV_CtLToBC_Event_PanelReceive");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_ProcessStart"),"RV_CtLToBC_Event_ProcessStart");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_PanelUnitIn1"),"RV_CtLToBC_Event_PanelUnitIn1");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_PanelUnitIn2"),"RV_CtLToBC_Event_PanelUnitIn2");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_ProcessData"),"RV_CtLToBC_Event_ProcessData");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_PanelUnitOut1"),"RV_CtLToBC_Event_PanelUnitOut1");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_PanelUnitOut2"),"RV_CtLToBC_Event_PanelUnitOut2");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_PanelSendOut"),"RV_CtLToBC_Event_PanelSendOut");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_PanelRemove"),"RV_CtLToBC_Event_PanelRemove");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_EqpRepair"),"RV_CtLToBC_Event_EqpRepair");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Command_MessageReply"),"RV_CtLToBC_Command_MessageReply");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Command_DateTimeReply"),"RV_CtLToBC_Command_DateTimeReply");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Command_TrayValidationReply"), "RV_CtLToBC_Command_TrayValidationReply");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Command_PNLValidationReply"),"RV_CtLToBC_Command_PNLValidationReply");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "RV_CtLToBC_Event_CapacityInfo"),"RV_CtLToBC_Event_CapacityInfo");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Command_BCAlive"),"SD_BCToCtL_Command_BCAlive");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Command_Message"),"SD_BCToCtL_Command_Message");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Command_DateTime"),"SD_BCToCtL_Command_DateTime");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Event_EqpStatusChangeReply"),"SD_BCToCtL_Event_EqpStatusChangeReply");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Event_AlarmReply"),"SD_BCToCtL_Event_AlarmReply");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Event_TactTimeReply"),"SD_BCToCtL_Event_TactTimeReply");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Command_TrayValidation"),"SD_BCToCtL_Command_TrayValidation");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Event_PanelInfoRequestReply"),"SD_BCToCtL_Event_PanelInfoRequestReply");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Event_PanelReceiveReply"),"SD_BCToCtL_Event_PanelReceiveReply");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Event_ProcessStartReply"),"SD_BCToCtL_Event_ProcessStartReply");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Event_PanelUnitIn1Reply"),"SD_BCToCtL_Event_PanelUnitIn1Reply");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Event_PanelUnitIn2Reply"),"SD_BCToCtL_Event_PanelUnitIn2Reply");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Event_ProcessDataReply"),"SD_BCToCtL_Event_ProcessDataReply");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Event_PanelUnitOut1Reply"),"SD_BCToCtL_Event_PanelUnitOut1Reply");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Event_PanelUnitOut2Reply"),"SD_BCToCtL_Event_PanelUnitOut2Reply");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Event_PanelSendOutReply"),"SD_BCToCtL_Event_PanelSendOutReply");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Event_PanelRemoveReply"),"SD_BCToCtL_Event_PanelRemoveReply");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Event_EqpRepairReply"),"SD_BCToCtL_Event_EqpRepairReply");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Event_TrayInfoRequestReply"),"SD_BCToCtL_Event_TrayInfoRequestReply");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Command_PNLValidation"),"SD_BCToCtL_Command_PNLValidation");
                dictVariableNames.Add(ConnectVariableNames(CIMparams.Prefix, "SD_BCToCtL_Event_CapacityInfoReply"),"SD_BCToCtL_Event_CapacityInfoReply");
            }
            BCToCtlvariableNames.AddRange(new string[] 
            { dictVariableNames["SD_BCToCtL_Command_Message[0]"], dictVariableNames["SD_BCToCtL_Command_DateTime[0]"], dictVariableNames["SD_BCToCtL_Command_TrayValidation[0]"],
              dictVariableNames["SD_BCToCtL_Command_PNLValidation[0]"], dictVariableNames["SD_BCToCtL_Event_EqpStatusChangeReply"], dictVariableNames["SD_BCToCtL_Event_AlarmReply"],
              dictVariableNames["SD_BCToCtL_Event_TactTimeReply"],dictVariableNames["SD_BCToCtL_Event_PanelInfoRequestReply"],dictVariableNames["SD_BCToCtL_Event_PanelReceiveReply"],
              dictVariableNames["SD_BCToCtL_Event_ProcessStartReply"],dictVariableNames["SD_BCToCtL_Event_PanelUnitIn1Reply"],dictVariableNames["SD_BCToCtL_Event_PanelUnitIn2Reply"],
              dictVariableNames["SD_BCToCtL_Event_ProcessDataReply"], dictVariableNames["SD_BCToCtL_Event_PanelUnitOut1Reply"],dictVariableNames["SD_BCToCtL_Event_PanelUnitOut2Reply"],
              dictVariableNames["SD_BCToCtL_Event_PanelSendOutReply"],dictVariableNames["SD_BCToCtL_Event_PanelRemoveReply"],dictVariableNames["SD_BCToCtL_Event_EqpRepairReply"],
              dictVariableNames["SD_BCToCtL_Event_TrayInfoRequestReply"], dictVariableNames["SD_BCToCtL_Event_CapacityInfoReply"]});
            #endregion
            try
            {
                variableCompolet.Active = true;

            }
            catch (Exception)
            {
                MessageBox.Show("欧姆龙软件未开");
                return;
            }          
            if (!variableNames[0].Contains(CIMparams.Prefix))
            {
                MessageBox.Show("当前变量定义与机型不相符，请核实！");
                Dipose();
            }
            SetBCToCtlEvent();
            BitOffAllTagValue();
        }
        private string ConnectVariableNames(string prefix,string variableNames)
        { 
           return  variableNames.Replace("CtL",prefix);
        }
        #region  注释掉
        //public void ThSD_BCToCtL_Command_Message(List<Int32> listMessage)
        //{
        //    if (SD_BCToCtL_Command_MessageEvent != null)
        //    {
        //        //SD_BCToCtL_Command_MessageEvent.BeginInvoke(null, new EventArgs(), null, null);
        //        IAsyncResult asynResult = SD_BCToCtL_Command_MessageEvent.BeginInvoke(listMessage, (Result) =>
        //        {
        //            SD_BCToCtL_Command_MessageEvent.EndInvoke(Result);
        //        }, null);
        //    }
        //}
        //public void ThSD_BCToCtL_Command_DateTime(List<Int32> listMessage)
        //{
        //    if (SD_BCToCtL_Command_DateTimeEvent != null)
        //    {
        //        //SD_BCToCtL_Command_DateTimeEvent.BeginInvoke(null, new EventArgs(), null, null);
        //        IAsyncResult asynResult = SD_BCToCtL_Command_DateTimeEvent.BeginInvoke(listMessage, (Result) =>
        //        {
        //            SD_BCToCtL_Command_DateTimeEvent.EndInvoke(Result);
        //        }, null);
        //    }
        //}
        //public void ThSD_BCToCtL_Command_TrayValidation(List<Int32> listMessage)
        //{
        //    if (SD_BCToCtL_Command_TrayValidationEvent != null)
        //    {
        //        //SD_BCToCtL_Command_TrayValidationEvent.BeginInvoke(null, new EventArgs(), null, null);
        //        IAsyncResult asynResult = SD_BCToCtL_Command_TrayValidationEvent.BeginInvoke(listMessage, (Result) =>
        //        {
        //            SD_BCToCtL_Command_TrayValidationEvent.EndInvoke(Result);
        //        }, null);
        //    }
        //}
        //public void ThSD_BCToCtL_Command_PNLValidation(List<Int32> listMessage)
        //{
        //    if (SD_BCToCtL_Command_PNLValidationEvent != null)
        //    {
        //        SD_BCToCtL_Command_PNLValidationEvent.BeginInvoke(listMessage, null, null);
        //       // IAsyncResult asynResult = SD_BCToCtL_Command_PNLValidationEvent.BeginInvoke(null, new EventArgs(), (Result) =>
        //       //{
        //       //    SD_BCToCtL_Command_PNLValidationEvent.EndInvoke(Result);
        //       //}, null);
        //    }
        //}
        #endregion
        /// <summary>
        /// 添加句柄
        /// </summary>
        /// <param name="Ptr"></param>
        public void WindowHandle(IntPtr Ptr)
        {
            if (m_bOfflineMode)
                return;
            try
            {
                if (CIMModeFlag == false)
                {
                    // variableCompolet.WindowHandle = IntPtr.Zero;
                    variableCompolet.WindowHandle = Ptr;
                }
                else
                {
                    variableCompolet.WindowHandle = Ptr;
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("欧姆龙通讯错误！！！");
            }
            
        }
        /// <summary>
        /// 读变量,使用字典兼容不同的变量名
        /// </summary>
        /// <param name="VariableNames"></param>
        /// <returns></returns>
        public object ReadVariable(string VariableNames)
        {
            if (m_bOfflineMode)
                return 0;

            if (CIMModeFlag)
            {
            try { 
                    if (VariableNames.Contains("[0]"))
                    {
                        string str = VariableNames.Replace("[0]", "");
                        return variableCompolet.ReadVariable(dictVariableNames[str] + "[0]");
                    }
                    else
                    {
                        return variableCompolet.ReadVariable(dictVariableNames[VariableNames]);
                    } 
                 }catch(Exception e)
                {
                    MessageBox.Show(e.ToString());
                    return null;
                }
            }
            else
            {
                return 0;
            }
        }
        /// <summary>
        /// 写变量,使用字典兼容不同的变量名
        /// </summary>
        /// <param name="VariableNames"></param>
        /// <param name="val"></param>
        public void WriteVariable(string VariableNames,object val)
        {
            if (m_bOfflineMode)
                return;

            if (CIMModeFlag)
            {
                if (VariableNames.Contains("[0]"))
                {
                    string str = VariableNames.Replace("[0]", "");
                    variableCompolet.WriteVariable(dictVariableNames[str] + "[0]", val);
                }
                else
                {
                    variableCompolet.WriteVariable(dictVariableNames[VariableNames], val);
                } 
            }
        }
        /// <summary>
        /// 为某一个标签添加事件
        /// </summary>
        /// <param name="VariableNames"></param>
        /// <param name="EventID"></param>
        private void SetEvent(string VariableNames, int EventID)
        {
            if (m_bOfflineMode)
                return;

            if (!variableCompolet.IsSetEvent(VariableNames))
            {
                variableCompolet.SetEvent(VariableNames, EventID);//这里修改过 1->EventID
            }
        }
        /// <summary>
        /// BitOff所有变量,这里只支持Bit Off 一整个变量和[0]
        /// </summary>
        public void BitOffAllTagValue()
        {
            if (m_bOfflineMode)
                return;

            try
            {
                #region
                for (int i = 0; i < variableNames.Length; i++)
                {
                    if ((variableNames[i] == dictVariableNames["SD_BCToCtL_Command_BCAlive"]) || (variableNames[i] == dictVariableNames["RV_CtLToBC_Event_EqpAlive"]))
                    {
                        continue;
                    }
                    VariableInfo vi = null;
                    vi = variableCompolet.GetVariableInfo(variableNames[i]);
                    if (vi.IsArray)
                    {
                        if (CIMModeFlag)
                        {
                            variableCompolet.WriteVariable(variableNames[i] + "[0]", 0);
                        }
                    }
                    else
                    {
                        if (CIMModeFlag)
                        {
                            variableCompolet.WriteVariable(variableNames[i], 0);
                        }
                    }
                }
                #endregion
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
        }
        public void SetBCToCtlEvent()
        {
            if (m_bOfflineMode)
                return;

            for (int i = 0; i < BCToCtlvariableNames.Count; i++)
            {
                SetEvent(BCToCtlvariableNames[i], i);
                dictEventID.Add(BCToCtlvariableNames[i], i);
            }
        }

        /// <summary>
        /// 清除某一个标签的事件
        /// </summary>
        /// <param name="VariableNames"></param>
        public void ClearEvent(string VariableNames)
        {
            if (m_bOfflineMode)
                return;

            if (variableCompolet.IsSetEvent(dictVariableNames[VariableNames]))
            {
                variableCompolet.ClearEvent(dictVariableNames[VariableNames]);
            }
        }
        /// <summary>
        /// 清除所有标签的事件
        /// </summary>
        public void ClearAllEvent()
        {
            if (m_bOfflineMode)
                return;

            variableCompolet.ClearAllEvents();
        }
        /// <summary>
        /// 返回事件改变的变量名和EventID
        /// </summary>
        /// <param name="variableName"></param>
        /// <param name="eventID"></param>
        /// <param name="TimeLimit"></param>
        /// <returns></returns>
        public bool ReciveEvent(out string variableName, out int eventID, int TimeLimit = 0)
        {
            variableCompolet.ReciveEvent(out variableName, out eventID, TimeLimit);
            if (variableName == null || variableName == "")
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        /// <summary>
        /// 返某个标签的数组长度，单位为字，-1表示标签不存在，除此之外的所有值表示数组的长度。
        /// </summary>
        /// <param name="tagname"></param>
        /// <returns></returns>
        public int variableLength(string tagname)
        {
            VariableInfo vi = null;
            if (tagname.Contains("[0]"))
            {
                return -1;
            }
            foreach (string varName in variableNames)
            {
                if (varName == dictVariableNames[tagname])
                {
                    vi = variableCompolet.GetVariableInfo(varName);
                    break;
                }
            }
            if (vi != null)
            {
                if (vi.IsArray && (vi.Dimension == 1))
                {
                    return (int)vi.NumberOfElements[0];
                }
                else
                {
                    return 1;
                }
            }
            else
            {
                return -1;
            }
        }
        public void Dipose()
        {
            if (m_bOfflineMode)
                return;
            variableCompolet.Dispose();
        }
    }
}
