﻿namespace CIM通讯
{
    partial class SQLiteForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tb_datatime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tb_TrayID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tb_PanelID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_ToWord = new System.Windows.Forms.Button();
            this.tb_Search = new System.Windows.Forms.TextBox();
            this.btn_Search = new System.Windows.Forms.Button();
            this.btn_ClearAQLite = new System.Windows.Forms.Button();
            this.tb_Number = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.tb_datatime,
            this.tb_TrayID,
            this.tb_PanelID});
            this.dataGridView1.Location = new System.Drawing.Point(0, 41);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(524, 412);
            this.dataGridView1.TabIndex = 1;
            // 
            // tb_datatime
            // 
            dataGridViewCellStyle1.Font = new System.Drawing.Font("楷体", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_datatime.DefaultCellStyle = dataGridViewCellStyle1;
            this.tb_datatime.HeaderText = "时间";
            this.tb_datatime.Name = "tb_datatime";
            this.tb_datatime.ReadOnly = true;
            this.tb_datatime.Width = 160;
            // 
            // tb_TrayID
            // 
            dataGridViewCellStyle2.Font = new System.Drawing.Font("楷体", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_TrayID.DefaultCellStyle = dataGridViewCellStyle2;
            this.tb_TrayID.HeaderText = "TrayID";
            this.tb_TrayID.Name = "tb_TrayID";
            this.tb_TrayID.ReadOnly = true;
            this.tb_TrayID.Width = 160;
            // 
            // tb_PanelID
            // 
            dataGridViewCellStyle3.Font = new System.Drawing.Font("楷体", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_PanelID.DefaultCellStyle = dataGridViewCellStyle3;
            this.tb_PanelID.HeaderText = "PanelID";
            this.tb_PanelID.Name = "tb_PanelID";
            this.tb_PanelID.ReadOnly = true;
            this.tb_PanelID.Width = 160;
            // 
            // btn_ToWord
            // 
            this.btn_ToWord.Location = new System.Drawing.Point(0, 455);
            this.btn_ToWord.Name = "btn_ToWord";
            this.btn_ToWord.Size = new System.Drawing.Size(97, 35);
            this.btn_ToWord.TabIndex = 2;
            this.btn_ToWord.Text = "转存文件";
            this.btn_ToWord.UseVisualStyleBackColor = true;
            this.btn_ToWord.Click += new System.EventHandler(this.btn_ToWord_Click);
            // 
            // tb_Search
            // 
            this.tb_Search.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_Search.Location = new System.Drawing.Point(101, 458);
            this.tb_Search.Name = "tb_Search";
            this.tb_Search.Size = new System.Drawing.Size(114, 29);
            this.tb_Search.TabIndex = 3;
            // 
            // btn_Search
            // 
            this.btn_Search.Location = new System.Drawing.Point(217, 455);
            this.btn_Search.Name = "btn_Search";
            this.btn_Search.Size = new System.Drawing.Size(97, 35);
            this.btn_Search.TabIndex = 4;
            this.btn_Search.Text = "查询";
            this.btn_Search.UseVisualStyleBackColor = true;
            this.btn_Search.Click += new System.EventHandler(this.btn_Search_Click);
            // 
            // btn_ClearAQLite
            // 
            this.btn_ClearAQLite.Location = new System.Drawing.Point(315, 456);
            this.btn_ClearAQLite.Name = "btn_ClearAQLite";
            this.btn_ClearAQLite.Size = new System.Drawing.Size(97, 35);
            this.btn_ClearAQLite.TabIndex = 5;
            this.btn_ClearAQLite.Text = "清空数据库";
            this.btn_ClearAQLite.UseVisualStyleBackColor = true;
            this.btn_ClearAQLite.Click += new System.EventHandler(this.btn_ClearAQLite_Click);
            // 
            // tb_Number
            // 
            this.tb_Number.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_Number.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.tb_Number.Location = new System.Drawing.Point(456, 459);
            this.tb_Number.Name = "tb_Number";
            this.tb_Number.Size = new System.Drawing.Size(63, 29);
            this.tb_Number.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(414, 468);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 7;
            this.label1.Text = "数量：";
            // 
            // SQLiteForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(567, 492);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_Number);
            this.Controls.Add(this.btn_ClearAQLite);
            this.Controls.Add(this.btn_Search);
            this.Controls.Add(this.tb_Search);
            this.Controls.Add(this.btn_ToWord);
            this.Controls.Add(this.dataGridView1);
            this.Name = "SQLiteForm";
            this.Text = "数据库操作";
            this.Load += new System.EventHandler(this.SQLiteForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btn_ToWord;
        private System.Windows.Forms.TextBox tb_Search;
        private System.Windows.Forms.Button btn_Search;
        private System.Windows.Forms.Button btn_ClearAQLite;
        private System.Windows.Forms.DataGridViewTextBoxColumn tb_datatime;
        private System.Windows.Forms.DataGridViewTextBoxColumn tb_TrayID;
        private System.Windows.Forms.DataGridViewTextBoxColumn tb_PanelID;
        private System.Windows.Forms.TextBox tb_Number;
        private System.Windows.Forms.Label label1;
    }
}