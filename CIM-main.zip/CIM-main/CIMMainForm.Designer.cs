﻿namespace CIM通讯
{
    partial class CIMMainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CIMMainForm));
            this.cmb_VCRPort = new System.Windows.Forms.ComboBox();
            this.cmb_BCRPort = new System.Windows.Forms.ComboBox();
            this.VCR = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_ConnectVCR = new System.Windows.Forms.Button();
            this.btn_ConnectBCR = new System.Windows.Forms.Button();
            this.tb_NowTrayID = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.ftb_NewPanelIDOne = new System.Windows.Forms.TextBox();
            this.btn_CIMAlive = new System.Windows.Forms.Button();
            this.tb_NewPanelIDTwo = new System.Windows.Forms.TextBox();
            this.tb_NewPanelIDThree = new System.Windows.Forms.TextBox();
            this.tb_NewPanelIDFour = new System.Windows.Forms.TextBox();
            this.tb_NewPanelIDFive = new System.Windows.Forms.TextBox();
            this.tb_NewPanelIDSix = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lb_NowTrayState = new System.Windows.Forms.Label();
            this.lb_panelSixState = new System.Windows.Forms.Label();
            this.lb_panelFiveState = new System.Windows.Forms.Label();
            this.lb_panelFourState = new System.Windows.Forms.Label();
            this.lb_panelThreeState = new System.Windows.Forms.Label();
            this.lb_panelTwoState = new System.Windows.Forms.Label();
            this.lb_panelOneState = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.check_StationFour = new System.Windows.Forms.CheckBox();
            this.check_StationFive = new System.Windows.Forms.CheckBox();
            this.check_StationSix = new System.Windows.Forms.CheckBox();
            this.check_StationThree = new System.Windows.Forms.CheckBox();
            this.check_StationTwo = new System.Windows.Forms.CheckBox();
            this.check_StationOne = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label18 = new System.Windows.Forms.Label();
            this.check_PLC_CIMSwitch = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_WorkOrderID = new System.Windows.Forms.TextBox();
            this.tb_NewPlateNum = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.tb_SetPlateNum = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.check_LotUnlimited = new System.Windows.Forms.CheckBox();
            this.tb_ReadCodeOKNum = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.tb_ReadCodeNGNum = new System.Windows.Forms.TextBox();
            this.tb_ReadCodeOKRate = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.check_AutoJumpNG = new System.Windows.Forms.CheckBox();
            this.panel_CognexSDK = new System.Windows.Forms.Panel();
            this.AlarmTimer = new System.Windows.Forms.Timer(this.components);
            this.lb_BCAlarmMessageOutput = new System.Windows.Forms.ListBox();
            this.label17 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.用户登录ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.登录ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.登出ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.数据库ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.打开数据库ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ClearLotID = new System.Windows.Forms.ToolStripMenuItem();
            this.参数设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.重连TCPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.参数设置ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.重新读码ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Clear_ReadCode = new System.Windows.Forms.ToolStripMenuItem();
            this.手动上报ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.手动上传LotIDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.换班清产能ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.上报产能ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.上报TTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.保修ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.手动拔片ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lb_LogMessageOutput = new System.Windows.Forms.ListBox();
            this.lb_NextTrayState = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.tb_NextTrayID = new System.Windows.Forms.TextBox();
            this.tb_RecipeID = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.b_PM = new System.Windows.Forms.Button();
            this.b_MC = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.清除lotToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmb_VCRPort
            // 
            this.cmb_VCRPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cmb_VCRPort.FormattingEnabled = true;
            this.cmb_VCRPort.Location = new System.Drawing.Point(47, 12);
            this.cmb_VCRPort.Margin = new System.Windows.Forms.Padding(4);
            this.cmb_VCRPort.Name = "cmb_VCRPort";
            this.cmb_VCRPort.Size = new System.Drawing.Size(73, 25);
            this.cmb_VCRPort.TabIndex = 0;
            this.cmb_VCRPort.Click += new System.EventHandler(this.cmb_VCRPort_Click);
            // 
            // cmb_BCRPort
            // 
            this.cmb_BCRPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cmb_BCRPort.FormattingEnabled = true;
            this.cmb_BCRPort.Location = new System.Drawing.Point(270, 12);
            this.cmb_BCRPort.Margin = new System.Windows.Forms.Padding(4);
            this.cmb_BCRPort.Name = "cmb_BCRPort";
            this.cmb_BCRPort.Size = new System.Drawing.Size(73, 25);
            this.cmb_BCRPort.TabIndex = 1;
            this.cmb_BCRPort.Click += new System.EventHandler(this.cmb_BCRPort_Click);
            // 
            // VCR
            // 
            this.VCR.AutoSize = true;
            this.VCR.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.VCR.Location = new System.Drawing.Point(4, 16);
            this.VCR.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.VCR.Name = "VCR";
            this.VCR.Size = new System.Drawing.Size(40, 17);
            this.VCR.TabIndex = 2;
            this.VCR.Text = "VCR:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(231, 13);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "BCR:";
            // 
            // btn_ConnectVCR
            // 
            this.btn_ConnectVCR.BackColor = System.Drawing.Color.Red;
            this.btn_ConnectVCR.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_ConnectVCR.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_ConnectVCR.Location = new System.Drawing.Point(124, 8);
            this.btn_ConnectVCR.Margin = new System.Windows.Forms.Padding(4);
            this.btn_ConnectVCR.Name = "btn_ConnectVCR";
            this.btn_ConnectVCR.Size = new System.Drawing.Size(84, 29);
            this.btn_ConnectVCR.TabIndex = 4;
            this.btn_ConnectVCR.Text = "未连接VCR";
            this.btn_ConnectVCR.UseVisualStyleBackColor = false;
            this.btn_ConnectVCR.Click += new System.EventHandler(this.btn_ConnectVCR_Click);
            // 
            // btn_ConnectBCR
            // 
            this.btn_ConnectBCR.BackColor = System.Drawing.Color.Red;
            this.btn_ConnectBCR.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_ConnectBCR.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_ConnectBCR.Location = new System.Drawing.Point(351, 8);
            this.btn_ConnectBCR.Margin = new System.Windows.Forms.Padding(4);
            this.btn_ConnectBCR.Name = "btn_ConnectBCR";
            this.btn_ConnectBCR.Size = new System.Drawing.Size(84, 29);
            this.btn_ConnectBCR.TabIndex = 5;
            this.btn_ConnectBCR.Text = "未连接BCR";
            this.btn_ConnectBCR.UseVisualStyleBackColor = false;
            this.btn_ConnectBCR.Click += new System.EventHandler(this.btn_ConnectBCR_Click);
            // 
            // tb_NowTrayID
            // 
            this.tb_NowTrayID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_NowTrayID.Location = new System.Drawing.Point(95, 19);
            this.tb_NowTrayID.Margin = new System.Windows.Forms.Padding(4);
            this.tb_NowTrayID.Name = "tb_NowTrayID";
            this.tb_NowTrayID.Size = new System.Drawing.Size(113, 23);
            this.tb_NowTrayID.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(11, 24);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 17);
            this.label2.TabIndex = 7;
            this.label2.Text = "当前TrayID:";
            // 
            // ftb_NewPanelIDOne
            // 
            this.ftb_NewPanelIDOne.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ftb_NewPanelIDOne.Location = new System.Drawing.Point(95, 127);
            this.ftb_NewPanelIDOne.Margin = new System.Windows.Forms.Padding(4);
            this.ftb_NewPanelIDOne.Name = "ftb_NewPanelIDOne";
            this.ftb_NewPanelIDOne.ReadOnly = true;
            this.ftb_NewPanelIDOne.Size = new System.Drawing.Size(113, 23);
            this.ftb_NewPanelIDOne.TabIndex = 8;
            // 
            // btn_CIMAlive
            // 
            this.btn_CIMAlive.BackColor = System.Drawing.Color.Red;
            this.btn_CIMAlive.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_CIMAlive.Location = new System.Drawing.Point(458, 8);
            this.btn_CIMAlive.Margin = new System.Windows.Forms.Padding(4);
            this.btn_CIMAlive.Name = "btn_CIMAlive";
            this.btn_CIMAlive.Size = new System.Drawing.Size(84, 29);
            this.btn_CIMAlive.TabIndex = 10;
            this.btn_CIMAlive.Text = "CIM离线";
            this.btn_CIMAlive.UseVisualStyleBackColor = false;
            this.btn_CIMAlive.Click += new System.EventHandler(this.btn_CIMAlive_Click);
            this.btn_CIMAlive.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Btn_CIMAlive_MouseClick);
            // 
            // tb_NewPanelIDTwo
            // 
            this.tb_NewPanelIDTwo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_NewPanelIDTwo.Location = new System.Drawing.Point(95, 153);
            this.tb_NewPanelIDTwo.Margin = new System.Windows.Forms.Padding(4);
            this.tb_NewPanelIDTwo.Name = "tb_NewPanelIDTwo";
            this.tb_NewPanelIDTwo.ReadOnly = true;
            this.tb_NewPanelIDTwo.Size = new System.Drawing.Size(113, 23);
            this.tb_NewPanelIDTwo.TabIndex = 14;
            // 
            // tb_NewPanelIDThree
            // 
            this.tb_NewPanelIDThree.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_NewPanelIDThree.Location = new System.Drawing.Point(95, 179);
            this.tb_NewPanelIDThree.Margin = new System.Windows.Forms.Padding(4);
            this.tb_NewPanelIDThree.Name = "tb_NewPanelIDThree";
            this.tb_NewPanelIDThree.ReadOnly = true;
            this.tb_NewPanelIDThree.Size = new System.Drawing.Size(113, 23);
            this.tb_NewPanelIDThree.TabIndex = 15;
            // 
            // tb_NewPanelIDFour
            // 
            this.tb_NewPanelIDFour.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_NewPanelIDFour.Location = new System.Drawing.Point(311, 127);
            this.tb_NewPanelIDFour.Margin = new System.Windows.Forms.Padding(4);
            this.tb_NewPanelIDFour.Name = "tb_NewPanelIDFour";
            this.tb_NewPanelIDFour.ReadOnly = true;
            this.tb_NewPanelIDFour.Size = new System.Drawing.Size(113, 23);
            this.tb_NewPanelIDFour.TabIndex = 16;
            // 
            // tb_NewPanelIDFive
            // 
            this.tb_NewPanelIDFive.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_NewPanelIDFive.Location = new System.Drawing.Point(311, 153);
            this.tb_NewPanelIDFive.Margin = new System.Windows.Forms.Padding(4);
            this.tb_NewPanelIDFive.Name = "tb_NewPanelIDFive";
            this.tb_NewPanelIDFive.ReadOnly = true;
            this.tb_NewPanelIDFive.Size = new System.Drawing.Size(113, 23);
            this.tb_NewPanelIDFive.TabIndex = 17;
            // 
            // tb_NewPanelIDSix
            // 
            this.tb_NewPanelIDSix.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_NewPanelIDSix.Location = new System.Drawing.Point(311, 179);
            this.tb_NewPanelIDSix.Margin = new System.Windows.Forms.Padding(4);
            this.tb_NewPanelIDSix.Name = "tb_NewPanelIDSix";
            this.tb_NewPanelIDSix.ReadOnly = true;
            this.tb_NewPanelIDSix.Size = new System.Drawing.Size(113, 23);
            this.tb_NewPanelIDSix.TabIndex = 18;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Gray;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(5, 215);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 19);
            this.label3.TabIndex = 21;
            this.label3.Text = "报警信息输出:";
            // 
            // lb_NowTrayState
            // 
            this.lb_NowTrayState.AutoSize = true;
            this.lb_NowTrayState.BackColor = System.Drawing.Color.Yellow;
            this.lb_NowTrayState.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_NowTrayState.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_NowTrayState.Location = new System.Drawing.Point(209, 21);
            this.lb_NowTrayState.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_NowTrayState.Name = "lb_NowTrayState";
            this.lb_NowTrayState.Size = new System.Drawing.Size(29, 19);
            this.lb_NowTrayState.TabIndex = 27;
            this.lb_NowTrayState.Text = "NT";
            // 
            // lb_panelSixState
            // 
            this.lb_panelSixState.AutoSize = true;
            this.lb_panelSixState.BackColor = System.Drawing.Color.Yellow;
            this.lb_panelSixState.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_panelSixState.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_panelSixState.Location = new System.Drawing.Point(425, 180);
            this.lb_panelSixState.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_panelSixState.Name = "lb_panelSixState";
            this.lb_panelSixState.Size = new System.Drawing.Size(29, 19);
            this.lb_panelSixState.TabIndex = 28;
            this.lb_panelSixState.Text = "NT";
            // 
            // lb_panelFiveState
            // 
            this.lb_panelFiveState.AutoSize = true;
            this.lb_panelFiveState.BackColor = System.Drawing.Color.Yellow;
            this.lb_panelFiveState.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_panelFiveState.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_panelFiveState.Location = new System.Drawing.Point(425, 154);
            this.lb_panelFiveState.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_panelFiveState.Name = "lb_panelFiveState";
            this.lb_panelFiveState.Size = new System.Drawing.Size(29, 19);
            this.lb_panelFiveState.TabIndex = 29;
            this.lb_panelFiveState.Text = "NT";
            // 
            // lb_panelFourState
            // 
            this.lb_panelFourState.AutoSize = true;
            this.lb_panelFourState.BackColor = System.Drawing.Color.Yellow;
            this.lb_panelFourState.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_panelFourState.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_panelFourState.Location = new System.Drawing.Point(425, 128);
            this.lb_panelFourState.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_panelFourState.Name = "lb_panelFourState";
            this.lb_panelFourState.Size = new System.Drawing.Size(29, 19);
            this.lb_panelFourState.TabIndex = 30;
            this.lb_panelFourState.Text = "NT";
            // 
            // lb_panelThreeState
            // 
            this.lb_panelThreeState.AutoSize = true;
            this.lb_panelThreeState.BackColor = System.Drawing.Color.Yellow;
            this.lb_panelThreeState.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_panelThreeState.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_panelThreeState.Location = new System.Drawing.Point(209, 180);
            this.lb_panelThreeState.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_panelThreeState.Name = "lb_panelThreeState";
            this.lb_panelThreeState.Size = new System.Drawing.Size(29, 19);
            this.lb_panelThreeState.TabIndex = 31;
            this.lb_panelThreeState.Text = "NT";
            // 
            // lb_panelTwoState
            // 
            this.lb_panelTwoState.AutoSize = true;
            this.lb_panelTwoState.BackColor = System.Drawing.Color.Yellow;
            this.lb_panelTwoState.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_panelTwoState.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_panelTwoState.Location = new System.Drawing.Point(209, 154);
            this.lb_panelTwoState.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_panelTwoState.Name = "lb_panelTwoState";
            this.lb_panelTwoState.Size = new System.Drawing.Size(29, 19);
            this.lb_panelTwoState.TabIndex = 32;
            this.lb_panelTwoState.Text = "NT";
            // 
            // lb_panelOneState
            // 
            this.lb_panelOneState.AutoSize = true;
            this.lb_panelOneState.BackColor = System.Drawing.Color.Yellow;
            this.lb_panelOneState.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_panelOneState.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_panelOneState.Location = new System.Drawing.Point(209, 128);
            this.lb_panelOneState.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_panelOneState.Name = "lb_panelOneState";
            this.lb_panelOneState.Size = new System.Drawing.Size(29, 19);
            this.lb_panelOneState.TabIndex = 33;
            this.lb_panelOneState.Text = "NT";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(30, 129);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 17);
            this.label4.TabIndex = 43;
            this.label4.Text = "Panel-1:";
            // 
            // check_StationFour
            // 
            this.check_StationFour.AutoSize = true;
            this.check_StationFour.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.check_StationFour.Location = new System.Drawing.Point(235, 12);
            this.check_StationFour.Name = "check_StationFour";
            this.check_StationFour.Size = new System.Drawing.Size(35, 21);
            this.check_StationFour.TabIndex = 44;
            this.check_StationFour.Text = "4";
            this.check_StationFour.UseVisualStyleBackColor = true;
            // 
            // check_StationFive
            // 
            this.check_StationFive.AutoSize = true;
            this.check_StationFive.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.check_StationFive.Location = new System.Drawing.Point(274, 12);
            this.check_StationFive.Name = "check_StationFive";
            this.check_StationFive.Size = new System.Drawing.Size(35, 21);
            this.check_StationFive.TabIndex = 45;
            this.check_StationFive.Text = "5";
            this.check_StationFive.UseVisualStyleBackColor = true;
            // 
            // check_StationSix
            // 
            this.check_StationSix.AutoSize = true;
            this.check_StationSix.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.check_StationSix.Location = new System.Drawing.Point(313, 12);
            this.check_StationSix.Name = "check_StationSix";
            this.check_StationSix.Size = new System.Drawing.Size(35, 21);
            this.check_StationSix.TabIndex = 46;
            this.check_StationSix.Text = "6";
            this.check_StationSix.UseVisualStyleBackColor = true;
            // 
            // check_StationThree
            // 
            this.check_StationThree.AutoSize = true;
            this.check_StationThree.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.check_StationThree.Location = new System.Drawing.Point(196, 12);
            this.check_StationThree.Name = "check_StationThree";
            this.check_StationThree.Size = new System.Drawing.Size(35, 21);
            this.check_StationThree.TabIndex = 47;
            this.check_StationThree.Text = "3";
            this.check_StationThree.UseVisualStyleBackColor = true;
            // 
            // check_StationTwo
            // 
            this.check_StationTwo.AutoSize = true;
            this.check_StationTwo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.check_StationTwo.Location = new System.Drawing.Point(157, 12);
            this.check_StationTwo.Name = "check_StationTwo";
            this.check_StationTwo.Size = new System.Drawing.Size(35, 21);
            this.check_StationTwo.TabIndex = 48;
            this.check_StationTwo.Text = "2";
            this.check_StationTwo.UseVisualStyleBackColor = true;
            // 
            // check_StationOne
            // 
            this.check_StationOne.AutoSize = true;
            this.check_StationOne.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.check_StationOne.Location = new System.Drawing.Point(118, 12);
            this.check_StationOne.Name = "check_StationOne";
            this.check_StationOne.Size = new System.Drawing.Size(35, 21);
            this.check_StationOne.TabIndex = 49;
            this.check_StationOne.Text = "1";
            this.check_StationOne.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.check_StationFour);
            this.groupBox1.Controls.Add(this.check_StationThree);
            this.groupBox1.Controls.Add(this.check_StationTwo);
            this.groupBox1.Controls.Add(this.check_StationOne);
            this.groupBox1.Controls.Add(this.check_StationFive);
            this.groupBox1.Controls.Add(this.check_StationSix);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox1.Location = new System.Drawing.Point(5, 533);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(347, 37);
            this.groupBox1.TabIndex = 50;
            this.groupBox1.TabStop = false;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label18.Location = new System.Drawing.Point(6, 13);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(106, 17);
            this.label18.TabIndex = 50;
            this.label18.Text = "下料拔片工位：";
            // 
            // check_PLC_CIMSwitch
            // 
            this.check_PLC_CIMSwitch.AutoSize = true;
            this.check_PLC_CIMSwitch.BackColor = System.Drawing.Color.Red;
            this.check_PLC_CIMSwitch.Enabled = false;
            this.check_PLC_CIMSwitch.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.check_PLC_CIMSwitch.Location = new System.Drawing.Point(459, 52);
            this.check_PLC_CIMSwitch.Name = "check_PLC_CIMSwitch";
            this.check_PLC_CIMSwitch.Size = new System.Drawing.Size(83, 21);
            this.check_PLC_CIMSwitch.TabIndex = 52;
            this.check_PLC_CIMSwitch.Text = "VCR开关";
            this.check_PLC_CIMSwitch.UseVisualStyleBackColor = false;
            this.check_PLC_CIMSwitch.CheckedChanged += new System.EventHandler(this.check_PLC_CIMSwitch_CheckedChanged);
            this.check_PLC_CIMSwitch.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Check_PLC_CIMSwitch_MouseClick);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(242, 20);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 17);
            this.label5.TabIndex = 53;
            this.label5.Text = "工单号:";
            // 
            // tb_WorkOrderID
            // 
            this.tb_WorkOrderID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_WorkOrderID.Location = new System.Drawing.Point(311, 19);
            this.tb_WorkOrderID.Margin = new System.Windows.Forms.Padding(4);
            this.tb_WorkOrderID.Name = "tb_WorkOrderID";
            this.tb_WorkOrderID.ReadOnly = true;
            this.tb_WorkOrderID.Size = new System.Drawing.Size(113, 23);
            this.tb_WorkOrderID.TabIndex = 54;
            // 
            // tb_NewPlateNum
            // 
            this.tb_NewPlateNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_NewPlateNum.Location = new System.Drawing.Point(309, 210);
            this.tb_NewPlateNum.Margin = new System.Windows.Forms.Padding(4);
            this.tb_NewPlateNum.Name = "tb_NewPlateNum";
            this.tb_NewPlateNum.ReadOnly = true;
            this.tb_NewPlateNum.Size = new System.Drawing.Size(32, 23);
            this.tb_NewPlateNum.TabIndex = 56;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(236, 215);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 17);
            this.label6.TabIndex = 55;
            this.label6.Text = "剩余盘数:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(30, 156);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 17);
            this.label7.TabIndex = 57;
            this.label7.Text = "Panel-2:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(248, 129);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(61, 17);
            this.label8.TabIndex = 59;
            this.label8.Text = "Panel-4:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.Location = new System.Drawing.Point(30, 182);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(61, 17);
            this.label9.TabIndex = 58;
            this.label9.Text = "Panel-3:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.Location = new System.Drawing.Point(248, 182);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(61, 17);
            this.label10.TabIndex = 61;
            this.label10.Text = "Panel-6:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.Location = new System.Drawing.Point(248, 156);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(61, 17);
            this.label11.TabIndex = 60;
            this.label11.Text = "Panel-5:";
            // 
            // tb_SetPlateNum
            // 
            this.tb_SetPlateNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_SetPlateNum.Location = new System.Drawing.Point(399, 210);
            this.tb_SetPlateNum.Margin = new System.Windows.Forms.Padding(4);
            this.tb_SetPlateNum.Name = "tb_SetPlateNum";
            this.tb_SetPlateNum.ReadOnly = true;
            this.tb_SetPlateNum.Size = new System.Drawing.Size(30, 23);
            this.tb_SetPlateNum.TabIndex = 63;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.Location = new System.Drawing.Point(342, 215);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 17);
            this.label12.TabIndex = 62;
            this.label12.Text = "总盘数:";
            // 
            // check_LotUnlimited
            // 
            this.check_LotUnlimited.AutoSize = true;
            this.check_LotUnlimited.Checked = true;
            this.check_LotUnlimited.CheckState = System.Windows.Forms.CheckState.Checked;
            this.check_LotUnlimited.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.check_LotUnlimited.Location = new System.Drawing.Point(459, 79);
            this.check_LotUnlimited.Name = "check_LotUnlimited";
            this.check_LotUnlimited.Size = new System.Drawing.Size(83, 21);
            this.check_LotUnlimited.TabIndex = 67;
            this.check_LotUnlimited.Text = "无限上报";
            this.check_LotUnlimited.UseVisualStyleBackColor = true;
            this.check_LotUnlimited.CheckedChanged += new System.EventHandler(this.check_LotUnlimited_CheckedChanged);
            this.check_LotUnlimited.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CIMMainForm_MouseClick);
            // 
            // tb_ReadCodeOKNum
            // 
            this.tb_ReadCodeOKNum.BackColor = System.Drawing.Color.Green;
            this.tb_ReadCodeOKNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_ReadCodeOKNum.Location = new System.Drawing.Point(440, 545);
            this.tb_ReadCodeOKNum.Margin = new System.Windows.Forms.Padding(4);
            this.tb_ReadCodeOKNum.Name = "tb_ReadCodeOKNum";
            this.tb_ReadCodeOKNum.ReadOnly = true;
            this.tb_ReadCodeOKNum.Size = new System.Drawing.Size(60, 23);
            this.tb_ReadCodeOKNum.TabIndex = 69;
            this.tb_ReadCodeOKNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label13.Location = new System.Drawing.Point(370, 526);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(42, 17);
            this.label13.TabIndex = 68;
            this.label13.Text = "OK率";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.Location = new System.Drawing.Point(459, 526);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(28, 17);
            this.label14.TabIndex = 70;
            this.label14.Text = "OK";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.Location = new System.Drawing.Point(511, 526);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(29, 17);
            this.label15.TabIndex = 72;
            this.label15.Text = "NG";
            // 
            // tb_ReadCodeNGNum
            // 
            this.tb_ReadCodeNGNum.BackColor = System.Drawing.Color.Red;
            this.tb_ReadCodeNGNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_ReadCodeNGNum.Location = new System.Drawing.Point(501, 545);
            this.tb_ReadCodeNGNum.Margin = new System.Windows.Forms.Padding(4);
            this.tb_ReadCodeNGNum.Name = "tb_ReadCodeNGNum";
            this.tb_ReadCodeNGNum.ReadOnly = true;
            this.tb_ReadCodeNGNum.Size = new System.Drawing.Size(45, 23);
            this.tb_ReadCodeNGNum.TabIndex = 71;
            this.tb_ReadCodeNGNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb_ReadCodeOKRate
            // 
            this.tb_ReadCodeOKRate.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_ReadCodeOKRate.Location = new System.Drawing.Point(360, 544);
            this.tb_ReadCodeOKRate.Margin = new System.Windows.Forms.Padding(4);
            this.tb_ReadCodeOKRate.Name = "tb_ReadCodeOKRate";
            this.tb_ReadCodeOKRate.ReadOnly = true;
            this.tb_ReadCodeOKRate.Size = new System.Drawing.Size(57, 23);
            this.tb_ReadCodeOKRate.TabIndex = 73;
            this.tb_ReadCodeOKRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label16.Location = new System.Drawing.Point(419, 550);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(20, 17);
            this.label16.TabIndex = 74;
            this.label16.Text = "%";
            // 
            // check_AutoJumpNG
            // 
            this.check_AutoJumpNG.AutoSize = true;
            this.check_AutoJumpNG.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.check_AutoJumpNG.Location = new System.Drawing.Point(459, 106);
            this.check_AutoJumpNG.Name = "check_AutoJumpNG";
            this.check_AutoJumpNG.Size = new System.Drawing.Size(90, 21);
            this.check_AutoJumpNG.TabIndex = 75;
            this.check_AutoJumpNG.Text = "跳过NG片";
            this.check_AutoJumpNG.UseVisualStyleBackColor = true;
            this.check_AutoJumpNG.Visible = false;
            this.check_AutoJumpNG.CheckedChanged += new System.EventHandler(this.check_AutoJumpNG_CheckedChanged);
            this.check_AutoJumpNG.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Check_AutoJumpNG_MouseClick);
            // 
            // panel_CognexSDK
            // 
            this.panel_CognexSDK.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.panel_CognexSDK.Location = new System.Drawing.Point(565, 12);
            this.panel_CognexSDK.Name = "panel_CognexSDK";
            this.panel_CognexSDK.Size = new System.Drawing.Size(692, 555);
            this.panel_CognexSDK.TabIndex = 76;
            // 
            // AlarmTimer
            // 
            this.AlarmTimer.Enabled = true;
            this.AlarmTimer.Interval = 2000;
            this.AlarmTimer.Tick += new System.EventHandler(this.AlarmTimer_Tick);
            // 
            // lb_BCAlarmMessageOutput
            // 
            this.lb_BCAlarmMessageOutput.BackColor = System.Drawing.SystemColors.Control;
            this.lb_BCAlarmMessageOutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_BCAlarmMessageOutput.FormattingEnabled = true;
            this.lb_BCAlarmMessageOutput.HorizontalScrollbar = true;
            this.lb_BCAlarmMessageOutput.ItemHeight = 17;
            this.lb_BCAlarmMessageOutput.Items.AddRange(new object[] {
            resources.GetString("lb_BCAlarmMessageOutput.Items")});
            this.lb_BCAlarmMessageOutput.Location = new System.Drawing.Point(5, 399);
            this.lb_BCAlarmMessageOutput.Margin = new System.Windows.Forms.Padding(4);
            this.lb_BCAlarmMessageOutput.Name = "lb_BCAlarmMessageOutput";
            this.lb_BCAlarmMessageOutput.ScrollAlwaysVisible = true;
            this.lb_BCAlarmMessageOutput.Size = new System.Drawing.Size(553, 123);
            this.lb_BCAlarmMessageOutput.TabIndex = 78;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Gray;
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label17.Location = new System.Drawing.Point(5, 381);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(99, 19);
            this.label17.TabIndex = 79;
            this.label17.Text = "MES信息输出:";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.用户登录ToolStripMenuItem,
            this.数据库ToolStripMenuItem,
            this.参数设置ToolStripMenuItem,
            this.手动上报ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 581);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1258, 25);
            this.menuStrip1.TabIndex = 80;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 用户登录ToolStripMenuItem
            // 
            this.用户登录ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.登录ToolStripMenuItem,
            this.登出ToolStripMenuItem});
            this.用户登录ToolStripMenuItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.用户登录ToolStripMenuItem.Name = "用户登录ToolStripMenuItem";
            this.用户登录ToolStripMenuItem.Size = new System.Drawing.Size(80, 21);
            this.用户登录ToolStripMenuItem.Text = "用户登录";
            this.用户登录ToolStripMenuItem.MouseDown += new System.Windows.Forms.MouseEventHandler(this.用户登录ToolStripMenuItem_MouseDown);
            // 
            // 登录ToolStripMenuItem
            // 
            this.登录ToolStripMenuItem.Name = "登录ToolStripMenuItem";
            this.登录ToolStripMenuItem.Size = new System.Drawing.Size(106, 22);
            this.登录ToolStripMenuItem.Text = "登录";
            this.登录ToolStripMenuItem.Click += new System.EventHandler(this.登录ToolStripMenuItem_Click);
            // 
            // 登出ToolStripMenuItem
            // 
            this.登出ToolStripMenuItem.Name = "登出ToolStripMenuItem";
            this.登出ToolStripMenuItem.Size = new System.Drawing.Size(106, 22);
            this.登出ToolStripMenuItem.Text = "登出";
            this.登出ToolStripMenuItem.Click += new System.EventHandler(this.登出ToolStripMenuItem_Click_1);
            // 
            // 数据库ToolStripMenuItem
            // 
            this.数据库ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.打开数据库ToolStripMenuItem,
            this.ClearLotID});
            this.数据库ToolStripMenuItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.数据库ToolStripMenuItem.Name = "数据库ToolStripMenuItem";
            this.数据库ToolStripMenuItem.Size = new System.Drawing.Size(65, 21);
            this.数据库ToolStripMenuItem.Text = "数据库";
            this.数据库ToolStripMenuItem.Click += new System.EventHandler(this.数据库ToolStripMenuItem_Click);
            this.数据库ToolStripMenuItem.MouseDown += new System.Windows.Forms.MouseEventHandler(this.数据库ToolStripMenuItem_MouseDown);
            // 
            // 打开数据库ToolStripMenuItem
            // 
            this.打开数据库ToolStripMenuItem.Name = "打开数据库ToolStripMenuItem";
            this.打开数据库ToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.打开数据库ToolStripMenuItem.Text = "打开数据库";
            this.打开数据库ToolStripMenuItem.Click += new System.EventHandler(this.打开数据库ToolStripMenuItem_Click);
            // 
            // ClearLotID
            // 
            this.ClearLotID.Name = "ClearLotID";
            this.ClearLotID.Size = new System.Drawing.Size(174, 22);
            this.ClearLotID.Text = "换型清除LotID";
            this.ClearLotID.Click += new System.EventHandler(this.ClearLotID_Click);
            // 
            // 参数设置ToolStripMenuItem
            // 
            this.参数设置ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.重连TCPToolStripMenuItem,
            this.参数设置ToolStripMenuItem1,
            this.重新读码ToolStripMenuItem,
            this.Clear_ReadCode});
            this.参数设置ToolStripMenuItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.参数设置ToolStripMenuItem.Name = "参数设置ToolStripMenuItem";
            this.参数设置ToolStripMenuItem.Size = new System.Drawing.Size(80, 21);
            this.参数设置ToolStripMenuItem.Text = "系统设置";
            this.参数设置ToolStripMenuItem.Click += new System.EventHandler(this.参数设置ToolStripMenuItem_Click);
            this.参数设置ToolStripMenuItem.MouseDown += new System.Windows.Forms.MouseEventHandler(this.参数设置ToolStripMenuItem_MouseDown);
            // 
            // 重连TCPToolStripMenuItem
            // 
            this.重连TCPToolStripMenuItem.Name = "重连TCPToolStripMenuItem";
            this.重连TCPToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.重连TCPToolStripMenuItem.Text = "重连TCP";
            this.重连TCPToolStripMenuItem.Click += new System.EventHandler(this.重连TCPToolStripMenuItem_Click);
            // 
            // 参数设置ToolStripMenuItem1
            // 
            this.参数设置ToolStripMenuItem1.Name = "参数设置ToolStripMenuItem1";
            this.参数设置ToolStripMenuItem1.Size = new System.Drawing.Size(151, 22);
            this.参数设置ToolStripMenuItem1.Text = "参数设置";
            this.参数设置ToolStripMenuItem1.Click += new System.EventHandler(this.参数设置ToolStripMenuItem1_Click);
            // 
            // 重新读码ToolStripMenuItem
            // 
            this.重新读码ToolStripMenuItem.Name = "重新读码ToolStripMenuItem";
            this.重新读码ToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.重新读码ToolStripMenuItem.Text = "重新读码";
            this.重新读码ToolStripMenuItem.Click += new System.EventHandler(this.重新读码ToolStripMenuItem_Click);
            // 
            // Clear_ReadCode
            // 
            this.Clear_ReadCode.Name = "Clear_ReadCode";
            this.Clear_ReadCode.Size = new System.Drawing.Size(151, 22);
            this.Clear_ReadCode.Text = "清除读码率";
            this.Clear_ReadCode.Click += new System.EventHandler(this.清除读码率_Click);
            // 
            // 手动上报ToolStripMenuItem
            // 
            this.手动上报ToolStripMenuItem.Checked = true;
            this.手动上报ToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.手动上报ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.手动上传LotIDToolStripMenuItem,
            this.换班清产能ToolStripMenuItem,
            this.上报产能ToolStripMenuItem,
            this.上报TTToolStripMenuItem,
            this.保修ToolStripMenuItem,
            this.手动拔片ToolStripMenuItem,
            this.清除lotToolStripMenuItem});
            this.手动上报ToolStripMenuItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.手动上报ToolStripMenuItem.Name = "手动上报ToolStripMenuItem";
            this.手动上报ToolStripMenuItem.Size = new System.Drawing.Size(80, 21);
            this.手动上报ToolStripMenuItem.Text = "操作按钮";
            this.手动上报ToolStripMenuItem.Click += new System.EventHandler(this.手动上报ToolStripMenuItem_Click);
            this.手动上报ToolStripMenuItem.MouseDown += new System.Windows.Forms.MouseEventHandler(this.手动上报ToolStripMenuItem_MouseDown);
            // 
            // 手动上传LotIDToolStripMenuItem
            // 
            this.手动上传LotIDToolStripMenuItem.Name = "手动上传LotIDToolStripMenuItem";
            this.手动上传LotIDToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.手动上传LotIDToolStripMenuItem.Text = "手动上传LotID";
            this.手动上传LotIDToolStripMenuItem.Click += new System.EventHandler(this.手动上传LotIDToolStripMenuItem_Click);
            // 
            // 换班清产能ToolStripMenuItem
            // 
            this.换班清产能ToolStripMenuItem.Name = "换班清产能ToolStripMenuItem";
            this.换班清产能ToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.换班清产能ToolStripMenuItem.Text = "换班清产能";
            this.换班清产能ToolStripMenuItem.Click += new System.EventHandler(this.换班清产能ToolStripMenuItem_Click);
            // 
            // 上报产能ToolStripMenuItem
            // 
            this.上报产能ToolStripMenuItem.Name = "上报产能ToolStripMenuItem";
            this.上报产能ToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.上报产能ToolStripMenuItem.Text = "上报产能";
            this.上报产能ToolStripMenuItem.Click += new System.EventHandler(this.上报产能ToolStripMenuItem_Click);
            // 
            // 上报TTToolStripMenuItem
            // 
            this.上报TTToolStripMenuItem.Name = "上报TTToolStripMenuItem";
            this.上报TTToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.上报TTToolStripMenuItem.Text = "上报TT";
            this.上报TTToolStripMenuItem.Click += new System.EventHandler(this.上报TTToolStripMenuItem_Click);
            // 
            // 保修ToolStripMenuItem
            // 
            this.保修ToolStripMenuItem.Name = "保修ToolStripMenuItem";
            this.保修ToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.保修ToolStripMenuItem.Text = "报修";
            this.保修ToolStripMenuItem.Click += new System.EventHandler(this.保修ToolStripMenuItem_Click);
            // 
            // 手动拔片ToolStripMenuItem
            // 
            this.手动拔片ToolStripMenuItem.Name = "手动拔片ToolStripMenuItem";
            this.手动拔片ToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.手动拔片ToolStripMenuItem.Text = "手动拔片";
            this.手动拔片ToolStripMenuItem.Click += new System.EventHandler(this.手动拔片ToolStripMenuItem_Click);
            // 
            // lb_LogMessageOutput
            // 
            this.lb_LogMessageOutput.BackColor = System.Drawing.SystemColors.Control;
            this.lb_LogMessageOutput.Cursor = System.Windows.Forms.Cursors.Default;
            this.lb_LogMessageOutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_LogMessageOutput.FormattingEnabled = true;
            this.lb_LogMessageOutput.HorizontalScrollbar = true;
            this.lb_LogMessageOutput.ItemHeight = 17;
            this.lb_LogMessageOutput.Items.AddRange(new object[] {
            resources.GetString("lb_LogMessageOutput.Items")});
            this.lb_LogMessageOutput.Location = new System.Drawing.Point(5, 233);
            this.lb_LogMessageOutput.Margin = new System.Windows.Forms.Padding(4);
            this.lb_LogMessageOutput.Name = "lb_LogMessageOutput";
            this.lb_LogMessageOutput.ScrollAlwaysVisible = true;
            this.lb_LogMessageOutput.Size = new System.Drawing.Size(553, 140);
            this.lb_LogMessageOutput.TabIndex = 81;
            // 
            // lb_NextTrayState
            // 
            this.lb_NextTrayState.AutoSize = true;
            this.lb_NextTrayState.BackColor = System.Drawing.Color.Yellow;
            this.lb_NextTrayState.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_NextTrayState.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_NextTrayState.Location = new System.Drawing.Point(209, 48);
            this.lb_NextTrayState.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_NextTrayState.Name = "lb_NextTrayState";
            this.lb_NextTrayState.Size = new System.Drawing.Size(29, 19);
            this.lb_NextTrayState.TabIndex = 84;
            this.lb_NextTrayState.Text = "NT";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label20.Location = new System.Drawing.Point(5, 50);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(87, 17);
            this.label20.TabIndex = 83;
            this.label20.Text = "Next-TrayID:";
            // 
            // tb_NextTrayID
            // 
            this.tb_NextTrayID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_NextTrayID.Location = new System.Drawing.Point(95, 46);
            this.tb_NextTrayID.Margin = new System.Windows.Forms.Padding(4);
            this.tb_NextTrayID.Name = "tb_NextTrayID";
            this.tb_NextTrayID.Size = new System.Drawing.Size(113, 23);
            this.tb_NextTrayID.TabIndex = 82;
            // 
            // tb_RecipeID
            // 
            this.tb_RecipeID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_RecipeID.Location = new System.Drawing.Point(311, 46);
            this.tb_RecipeID.Margin = new System.Windows.Forms.Padding(4);
            this.tb_RecipeID.Name = "tb_RecipeID";
            this.tb_RecipeID.ReadOnly = true;
            this.tb_RecipeID.Size = new System.Drawing.Size(113, 23);
            this.tb_RecipeID.TabIndex = 86;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label19.Location = new System.Drawing.Point(242, 46);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(68, 17);
            this.label19.TabIndex = 85;
            this.label19.Text = "产品型号:";
            // 
            // b_PM
            // 
            this.b_PM.BackColor = System.Drawing.Color.Green;
            this.b_PM.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.b_PM.Location = new System.Drawing.Point(459, 132);
            this.b_PM.Name = "b_PM";
            this.b_PM.Size = new System.Drawing.Size(75, 32);
            this.b_PM.TabIndex = 87;
            this.b_PM.Text = "PM(维护)";
            this.b_PM.UseVisualStyleBackColor = false;
            this.b_PM.Click += new System.EventHandler(this.Button1_Click);
            // 
            // b_MC
            // 
            this.b_MC.BackColor = System.Drawing.Color.Green;
            this.b_MC.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.b_MC.Location = new System.Drawing.Point(460, 170);
            this.b_MC.Name = "b_MC";
            this.b_MC.Size = new System.Drawing.Size(75, 32);
            this.b_MC.TabIndex = 88;
            this.b_MC.Text = "MC(换型)";
            this.b_MC.UseVisualStyleBackColor = false;
            this.b_MC.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.tb_NowTrayID);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.tb_RecipeID);
            this.groupBox2.Controls.Add(this.lb_NowTrayState);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.lb_NextTrayState);
            this.groupBox2.Controls.Add(this.tb_WorkOrderID);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.tb_NextTrayID);
            this.groupBox2.Location = new System.Drawing.Point(0, 46);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(454, 75);
            this.groupBox2.TabIndex = 89;
            this.groupBox2.TabStop = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Green;
            this.button1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(458, 206);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 32);
            this.button1.TabIndex = 90;
            this.button1.Text = "测试按钮";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.Button1_Click_1);
            // 
            // 清除lotToolStripMenuItem
            // 
            this.清除lotToolStripMenuItem.Name = "清除lotToolStripMenuItem";
            this.清除lotToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.清除lotToolStripMenuItem.Text = "清除lot";
            this.清除lotToolStripMenuItem.Click += new System.EventHandler(this.清除lotToolStripMenuItem_Click);
            // 
            // CIMMainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1258, 606);
            this.ControlBox = false;
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.b_MC);
            this.Controls.Add(this.b_PM);
            this.Controls.Add(this.lb_LogMessageOutput);
            this.Controls.Add(this.lb_BCAlarmMessageOutput);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.panel_CognexSDK);
            this.Controls.Add(this.check_AutoJumpNG);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.tb_ReadCodeOKRate);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.tb_ReadCodeNGNum);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.tb_ReadCodeOKNum);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.check_LotUnlimited);
            this.Controls.Add(this.tb_SetPlateNum);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.tb_NewPlateNum);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.check_PLC_CIMSwitch);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lb_panelOneState);
            this.Controls.Add(this.lb_panelTwoState);
            this.Controls.Add(this.lb_panelThreeState);
            this.Controls.Add(this.lb_panelFourState);
            this.Controls.Add(this.lb_panelFiveState);
            this.Controls.Add(this.lb_panelSixState);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tb_NewPanelIDSix);
            this.Controls.Add(this.tb_NewPanelIDFive);
            this.Controls.Add(this.tb_NewPanelIDFour);
            this.Controls.Add(this.tb_NewPanelIDThree);
            this.Controls.Add(this.tb_NewPanelIDTwo);
            this.Controls.Add(this.btn_CIMAlive);
            this.Controls.Add(this.ftb_NewPanelIDOne);
            this.Controls.Add(this.btn_ConnectBCR);
            this.Controls.Add(this.btn_ConnectVCR);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.VCR);
            this.Controls.Add(this.cmb_BCRPort);
            this.Controls.Add(this.cmb_VCRPort);
            this.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "CIMMainForm";
            this.Text = "先河激光CIM软件-202105";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CIMMainForm_FormClosing);
            this.Load += new System.EventHandler(this.CIMMainForm_Load);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CIMMainForm_MouseClick);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmb_VCRPort;
        private System.Windows.Forms.ComboBox cmb_BCRPort;
        private System.Windows.Forms.Label VCR;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_ConnectVCR;
        private System.Windows.Forms.Button btn_ConnectBCR;
        private System.Windows.Forms.TextBox tb_NowTrayID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox ftb_NewPanelIDOne;
        private System.Windows.Forms.Button btn_CIMAlive;
        private System.Windows.Forms.TextBox tb_NewPanelIDTwo;
        private System.Windows.Forms.TextBox tb_NewPanelIDThree;
        private System.Windows.Forms.TextBox tb_NewPanelIDFour;
        private System.Windows.Forms.TextBox tb_NewPanelIDFive;
        private System.Windows.Forms.TextBox tb_NewPanelIDSix;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lb_NowTrayState;
        private System.Windows.Forms.Label lb_panelSixState;
        private System.Windows.Forms.Label lb_panelFiveState;
        private System.Windows.Forms.Label lb_panelFourState;
        private System.Windows.Forms.Label lb_panelThreeState;
        private System.Windows.Forms.Label lb_panelTwoState;
        private System.Windows.Forms.Label lb_panelOneState;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox check_StationFour;
        private System.Windows.Forms.CheckBox check_StationFive;
        private System.Windows.Forms.CheckBox check_StationSix;
        private System.Windows.Forms.CheckBox check_StationThree;
        private System.Windows.Forms.CheckBox check_StationTwo;
        private System.Windows.Forms.CheckBox check_StationOne;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox check_PLC_CIMSwitch;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_WorkOrderID;
        private System.Windows.Forms.TextBox tb_NewPlateNum;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox tb_SetPlateNum;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.CheckBox check_LotUnlimited;
        private System.Windows.Forms.TextBox tb_ReadCodeOKNum;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox tb_ReadCodeNGNum;
        private System.Windows.Forms.TextBox tb_ReadCodeOKRate;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.CheckBox check_AutoJumpNG;
        private System.Windows.Forms.Panel panel_CognexSDK;
        private System.Windows.Forms.Timer AlarmTimer;
        private System.Windows.Forms.ListBox lb_BCAlarmMessageOutput;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 用户登录ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 登录ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 登出ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 数据库ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 参数设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 手动上报ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 重连TCPToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 参数设置ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 手动上传LotIDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 换班清产能ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 上报产能ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 上报TTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 保修ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 重新读码ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 手动拔片ToolStripMenuItem;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ListBox lb_LogMessageOutput;
        private System.Windows.Forms.ToolStripMenuItem 打开数据库ToolStripMenuItem;
        private System.Windows.Forms.Label lb_NextTrayState;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox tb_NextTrayID;
        private System.Windows.Forms.ToolStripMenuItem Clear_ReadCode;
        private System.Windows.Forms.ToolStripMenuItem ClearLotID;
        private System.Windows.Forms.TextBox tb_RecipeID;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button b_PM;
        private System.Windows.Forms.Button b_MC;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ToolStripMenuItem 清除lotToolStripMenuItem;
    }
}