﻿using System.Runtime.InteropServices;

namespace TimeOperate
{
    class TimeAPI
    {
        [DllImport("Kernel32.dll")]
        public static extern void GetLocalTime(ref SystemTime lpSystemTime);

        [DllImport("Kernel32.dll")]
        public static extern bool SetLocalTime(ref SystemTime lpSystemTime);

        [DllImport("Kernel32.dll")]
        public static extern void GetSystemTime(ref SystemTime lpSystemTime);

        [DllImport("Kernel32.dll")]
        public static extern bool SetSystemTime(ref SystemTime lpSystemTime);
    }

    [StructLayout(LayoutKind.Sequential)]
    struct SystemTime
    {
        [MarshalAs(UnmanagedType.U2)]
        internal ushort year; // 年
        [MarshalAs(UnmanagedType.U2)]
        internal ushort month; // 月
        [MarshalAs(UnmanagedType.U2)]
        internal ushort dayOfWeek; // 星期
        [MarshalAs(UnmanagedType.U2)]
        internal ushort day; // 日
        [MarshalAs(UnmanagedType.U2)]
        internal ushort hour; // 时
        [MarshalAs(UnmanagedType.U2)]
        internal ushort minute; // 分
        [MarshalAs(UnmanagedType.U2)]
        internal ushort second; // 秒
        [MarshalAs(UnmanagedType.U2)]
        internal ushort milliseconds; // 毫秒
    }
}
