﻿using System;
using System.Runtime.InteropServices;

namespace TimeOperate
{
    class PrivilegeUtil
    {
        /// <summary>
        /// 授予权限
        /// 参数取值为文件PrivilegeAPI中的类PrivilegeConstants中的字段
        /// </summary>
        /// <param name="privilegeName">PrivilegeConstants类中的字段</param>
        /// <returns></returns>
        public static bool grantPrivilege(string privilegeName)
        {
            try
            {
                LUID locallyUniqueIdentifier = new LUID();
                if (PrivilegeAPI.LookupPrivilegeValue(null, privilegeName, ref locallyUniqueIdentifier))
                {
                    TOKEN_PRIVILEGES tokenPrivileges = new TOKEN_PRIVILEGES();
                    tokenPrivileges.PrivilegeCount = 1;

                    LUID_AND_ATTRIBUTES luidAndAtt = new LUID_AND_ATTRIBUTES();
                    // luidAndAtt.Attributes should be SE_PRIVILEGE_ENABLED to enable privilege
                    luidAndAtt.Attributes = PrivilegeAttributes.SE_PRIVILEGE_ENABLED;
                    luidAndAtt.Luid = locallyUniqueIdentifier;
                    tokenPrivileges.Privilege = luidAndAtt;

                    IntPtr tokenHandle = IntPtr.Zero;
                    try
                    {
                        if (PrivilegeAPI.OpenProcessToken(PrivilegeAPI.GetCurrentProcess(),
                            TokenAccess.TOKEN_ADJUST_PRIVILEGES | TokenAccess.TOKEN_QUERY, out tokenHandle))
                        {
                            if (PrivilegeAPI.AdjustTokenPrivileges(tokenHandle, false, ref tokenPrivileges, 1024, IntPtr.Zero, 0))
                            {
                                // 当前用户没有关联该权限
                                // 需要在windows系统（本地安全策略——本地策略——用户权限分配）中设置为该权限添加当前用户
                                if (Marshal.GetLastWin32Error() != PrivilegeAPI.ERROR_NOT_ALL_ASSIGNED)
                                {
                                    return true;
                                }
                            }
                        }
                    }
                    finally
                    {
                        if (tokenHandle != IntPtr.Zero)
                        {
                            PrivilegeAPI.CloseHandle(tokenHandle);
                        }
                    }
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// 撤销权限
        /// 参数取值为文件PrivilegeAPI中的类PrivilegeConstants中的字段
        /// </summary>
        /// <param name="privilegeName">PrivilegeConstants类中的字段</param>
        /// <returns></returns>
        public static bool revokePrivilege(string privilegeName)
        {
            try
            {
                LUID locallyUniqueIdentifier = new LUID();

                if (PrivilegeAPI.LookupPrivilegeValue(null, privilegeName, ref locallyUniqueIdentifier))
                {
                    TOKEN_PRIVILEGES tokenPrivileges = new TOKEN_PRIVILEGES();
                    tokenPrivileges.PrivilegeCount = 1;

                    LUID_AND_ATTRIBUTES luidAndAtt = new LUID_AND_ATTRIBUTES();
                    // luidAndAtt.Attributes should be none (not set) to disable privilege
                    luidAndAtt.Luid = locallyUniqueIdentifier;
                    tokenPrivileges.Privilege = luidAndAtt;

                    IntPtr tokenHandle = IntPtr.Zero;
                    try
                    {
                        if (PrivilegeAPI.OpenProcessToken(PrivilegeAPI.GetCurrentProcess(),
                            TokenAccess.TOKEN_ADJUST_PRIVILEGES | TokenAccess.TOKEN_QUERY, out tokenHandle))
                        {
                            if (PrivilegeAPI.AdjustTokenPrivileges(tokenHandle, false, ref tokenPrivileges, 1024, IntPtr.Zero, 0))
                            {
                                // 当前用户没有关联该权限
                                // 需要在windows系统（本地安全策略——本地策略——用户权限分配）中设置为该权限添加当前用户
                                if (Marshal.GetLastWin32Error() != PrivilegeAPI.ERROR_NOT_ALL_ASSIGNED)
                                {
                                    return true;
                                }
                            }
                        }
                    }
                    finally
                    {
                        if (tokenHandle != IntPtr.Zero)
                        {
                            PrivilegeAPI.CloseHandle(tokenHandle);
                        }
                    }
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
