﻿using System;

namespace TimeOperate
{
    class TimeUtil
    {
        /// <summary>
        /// 获取本地时间
        /// </summary>
        /// <returns></returns>
        public static DateTime getLocalTime()
        {
            SystemTime sysTime = new SystemTime();
            TimeAPI.GetLocalTime(ref sysTime);
            return SystemTime2DateTime(sysTime);
        }
        
        /// <summary>
        /// 设置本地时间
        /// </summary>
        /// <param name="dateTime"></param>
        /// <returns></returns>
        public static bool setLocalTime(DateTime dateTime)
        {
            /* 注意事项：
             * 这里授予线程修改系统时间的权限，但是Windows系统并没有给予Users修改系统时间的权限，需要进行下列操作并重启计算机：
             * 本地安全策略——本地策略——用户权限分配——更改系统时间，在其中的安全设置中添加Users
             * 
             * 也可以直接删除这里的if判断条件，直接以管理员身份运行程序，也能够修改系统时间
             * 因为Windows系统给予Administrators修改系统时间的权限
			 *
			 * 如果出现修改时间失败的情况，请尝试以管理员身份运行程序
             */
            if (PrivilegeUtil.grantPrivilege(PrivilegeConstants.SE_SYSTEMTIME_NAME))
            {
                // 授权成功
                SystemTime sysTime = DateTime2SystemTime(dateTime);
                bool success = TimeAPI.SetLocalTime(ref sysTime);
                if (!PrivilegeUtil.revokePrivilege(PrivilegeConstants.SE_SYSTEMTIME_NAME))
                {
                    // 撤权失败
                }
                return success;
            }
            // 授权失败
            return false;
        }
        
        /// <summary>
        /// 获取系统时间
        /// </summary>
        /// <returns></returns>
        public static DateTime getSystemTime()
        {
            SystemTime sysTime = new SystemTime();
            TimeAPI.GetSystemTime(ref sysTime);
            return SystemTime2DateTime(sysTime);
        }
        
        /// <summary>
        /// 设置系统时间（UTC）
        /// </summary>
        /// <param name="dateTime"></param>
        /// <returns></returns>
        public static bool setSystemTime(DateTime dateTime)
        {
            /* 注意事项：
             * 这里授予线程修改系统时间的权限，但是Windows系统并没有给予Users修改系统时间的权限，需要进行下列操作并重启计算机：
             * 本地安全策略——本地策略——用户权限分配——更改系统时间，在其中的安全设置中添加Users
             * 
             * 也可以直接删除这里的if判断条件，直接以管理员身份运行程序，也能够修改系统时间
             * 因为Windows系统给予Administrators修改系统时间的权限
			 *
			 * 如果出现修改时间失败的情况，请尝试以管理员身份运行程序
             */
            if (PrivilegeUtil.grantPrivilege(PrivilegeConstants.SE_SYSTEMTIME_NAME))
            {
                // 授权成功
                SystemTime sysTime = DateTime2SystemTime(dateTime);
                bool success = TimeAPI.SetSystemTime(ref sysTime);
                if (!PrivilegeUtil.revokePrivilege(PrivilegeConstants.SE_SYSTEMTIME_NAME))
                {
                    // 撤权失败
                }
                return success;
            }
            // 授权失败
            return false;
        }
        
        /// <summary>
        /// 将SystemTime转换为DateTime
        /// </summary>
        /// <param name="sysTime"></param>
        /// <returns></returns>
        public static DateTime SystemTime2DateTime(SystemTime sysTime)
        {
            return new DateTime(sysTime.year, sysTime.month, sysTime.day, sysTime.hour, sysTime.minute, sysTime.second, sysTime.milliseconds);
        }
        
        /// <summary>
        /// 将DateTime转换为SystemTime
        /// </summary>
        /// <param name="dateTime"></param>
        /// <returns></returns>
        public static SystemTime DateTime2SystemTime(DateTime dateTime)
        {
            SystemTime sysTime = new SystemTime();
            sysTime.year = Convert.ToUInt16(dateTime.Year);
            sysTime.month = Convert.ToUInt16(dateTime.Month);
            sysTime.day = Convert.ToUInt16(dateTime.Day);
            sysTime.hour = Convert.ToUInt16(dateTime.Hour);
            sysTime.minute = Convert.ToUInt16(dateTime.Minute);
            sysTime.second = Convert.ToUInt16(dateTime.Second);
            sysTime.milliseconds = Convert.ToUInt16(dateTime.Millisecond);
            return sysTime;
        }

    }
}
