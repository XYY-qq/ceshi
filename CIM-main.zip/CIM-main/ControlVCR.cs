﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Threading;
using System.Windows.Forms;
using System.Text;
using TwinCAT.Ads;
using System.Collections;
using Cognex;
using System.Threading.Tasks;
using CustomTool;
using System.Windows.Forms;
using System.Timers;

namespace CIM通讯
{
    /// <summary>
    /// 将6个PanelID全部上传，然后再去一个一个对比，BC反馈的信息会之后到来。所以，我是收到六个反馈之后再对比一次。
    /// </summary>
    public class ControlVCR : mySerialPort
    {
        //CIM在/离线事件
        public event Action CIMOffLineEvent;
        public bool CIMswitch = false;
        public bool ReadCodeFlow = false;

        public bool CognexFlag = false;
        public bool Aflag = false;
        public int StationNumber = 6;
        private static int StationEventCount = 0;//记录目前是哪个工位触发通知事件。
        public static int ReadFromBCStationCount = 0;//记录目前读到是第几个PanelID的回复。
        private int ResetReadNum = 2;//读码失败之后重新读码的次数
        public bool checkAutoJumpNG = false;//自动跳过NG品
        //Thread thDecoder = null;

        System.Timers.Timer aTimer = new System.Timers.Timer(); //定时器
        /// <summary>
        /// 当前工单号用尽提示
        /// </summary>
        public bool WorkOrderOff;
        /// <summary>
        /// 为TRUE时，不限制加工的次数
        /// </summary>
        public bool lotUnlimited = false;
        //缓存1-6个panel的ID
        public string[] StationPanelID
            {
            get
            {
                return stationPanelID;
            }
        }
        public bool[] StationVCRCheck
        {
            get
            {
                return stationVCRCheck;
            }
        }
        //无限上报
        public bool LotUnlimited
        {
            get
            {
                return lotUnlimited;
            }
            set
            {
                lotUnlimited = value;
            }
        }
        /// <summary>
        /// 从BC端读到的PanelID存放在这里
        /// </summary>
        public string[] ReadStationPanelID
        {
            get
            {
                return readStationPanelID;
            }
        }
        //上一次VCR对比成功的数据,用做AOI使用
        public string[] LastStationPanelID
        {
            get
            {
                return lastStationPanelID;
            }
        }
        /// <summary>
        /// 存放VCR读码成功的panelID，VCR读码成功后入队，Sendout之后出队
        /// </summary>
        public Queue<PanelIDMessageClass> QueueLastStationPanelID
        {
            get
            {
                return queueLastStationPanelID;
            }
        }
        
        /// <summary>
        /// VCR对比失败数据
        /// </summary>
        public string[] ErrorStationPanelID
        {
            get
            {
                return errorStationPanelID;
            }
        }
        /// <summary>
        /// 从BC端读到的PanelID,NG or OK
        /// </summary>
        public bool[] ReadStationVCRCheck
        {
            get
            {
                return readStationVCRCheck;
            }
        }
        //所有工位读码成功
        public bool AllStationVCRCheck
        {
            get
            {
                return allStationVCRCheck;
            }
        }
        //所有工位与BC端对比成功
        public bool AllReadStationVCRCheck
        {
            get
            {
                return allReadStationVCRCheck;
            }
            set
            {
                allReadStationVCRCheck = value;
            }
        }
        public Queue<PanelIDMessageClass> queueLastStationPanelID = new Queue<PanelIDMessageClass>();   //存储每盘的交互信息
        private  string[] stationPanelID = new string[6];   //当前读码值
        private  bool[] stationVCRCheck = new bool[6];      //当前读码值是否有效
        private string[] readStationPanelID = new string[6];    //已验证的Panel码
        private bool[] readStationVCRCheck = new bool[6];       //已验证的Panel码是否有效
        private string[] lastStationPanelID = new string[6];
        private string[] errorStationPanelID = new string[6];
        private bool allStationVCRCheck = true;
        private bool allReadStationVCRCheck = true;

        /// <summary>
        /// 康耐视静态读码事件
        /// </summary>
        public static event Action CognexReadCodeEvent;


        public event Action WorkOrderOffEvent;
        public delegate void bReadyToCameraEncodeEventHandler();
        public event bReadyToCameraEncodeEventHandler bReadyToCameraEncodeEvent;
        public delegate void VCRReadNGEventHandler(bool[] check);
        public event VCRReadNGEventHandler VCRReadNGEvent;
        public delegate void VCRReadOKEventHandler();
        public event VCRReadOKEventHandler VCRReadOKEvent;
        public event Action PanelFeedUnitToCutingUnitEvent;//上料单元到切割单元
        public event Action PanelCutingUnitToBrakeUnitEvent;//切割单元到裂片单元
        public event Action PanelBrakeUnitToFinishUnitEvent;//裂片单元到下料单元
        public event Action PanelSendOutEvent;
        public event Action VCRDisplayEvent;
        public event Action<bool[]> PanelDisplayEvent;
        public event Action<VariableMap.EqpStatus> EqpStatusEvent;
        public event Action EqpAlarmEvent;
        private bool flag = true;
        private bool CutingAlarmFlag = false;
        private bool FeedAlarmFlag = false;
        private bool FinishAlarmFlag = false;
        Thread CIMSWitch = null;
        private bool m_bFourStationEnable = false;
        private bool m_bOfflineMode = false;

        public ControlVCR(bool bOfflineMode, bool bFourStationEnable)
        {
            m_bOfflineMode = bOfflineMode;
            m_bFourStationEnable = bFourStationEnable;
            if(m_bFourStationEnable)
            {
                StationNumber = 4;
            }
            else
            {
                StationNumber = 6;
            }
            //thDecoder = new Thread(CognexRead);
            //thDecoder.IsBackground = true;
            //thDecoder.Start();

            readStationVCRCheck[0] = false;
            readStationVCRCheck[1] = false;
            readStationVCRCheck[2] = false;
            readStationVCRCheck[3] = false;
            readStationVCRCheck[4] = false;
            readStationVCRCheck[5] = false;

            readStationPanelID[0] = "";
            readStationPanelID[1] = "";
            readStationPanelID[2] = "";
            readStationPanelID[3] = "";
            readStationPanelID[4] = "";
            readStationPanelID[5] = "";

            OpFrameHeadAndTail = true;
            Hex_CmdHead = (byte)('<');
            Hex_CmdTail = (byte)('>');
            BeckhoffRW.BeckhoffBase_Init();//初始化倍福底层
            if (BeckhoffRW.BeckhoffEn)
            {
                BeckhoffRW.adsClient.AdsNotificationEx += new AdsNotificationExEventHandler(adsClient_AdsNotificationEx);
            }

            try
            {
                BeckhoffRW.AddDeviceNotification<bool>(".bReady_to_CameraEncode");
                BeckhoffRW.AddDeviceNotification<bool>(".bCuttingReady_to_Feed");
                BeckhoffRW.AddDeviceNotification<bool>(".bCatch_PosReady");
                BeckhoffRW.AddDeviceNotification<bool>(".bBrakeTableReady");
                BeckhoffRW.AddDeviceNotification<bool>(".StFinish_ActState.bSuckFinish");
                BeckhoffRW.AddDeviceNotification<bool>(".StFeed_State.bIn_Reset");//PLC上料复位信号
            }
            catch(Exception ex)
            {
                MessageBox.Show("关联倍福变量失败："+ex.Message);
            }

            //BeckhoffRW.AddDeviceNotification<bool>(".boRedLight");//报警
            //BeckhoffRW.AddDeviceNotification<bool>(".boYellowLight");//暂停
            //BeckhoffRW.AddDeviceNotification<bool>(".boGreenLight");//运行
            //BeckhoffRW.AddDeviceNotification<bool>(".StFinish_Cylinder.bBuzzer");//下料报警
            //BeckhoffRW.AddDeviceNotification<bool>(".StFeed_Cylinder.bBuzzer");//上料报警
            bReadyToCameraEncodeEvent += new ControlVCR.bReadyToCameraEncodeEventHandler(workStart);
            W_ReadOverVCR(false);//置位
            W_CheakBCReadPanelIDOK(false);
            W_CheakBCReadPanelIDNG(false);
            W_CIMSwitchForPLC(false);
            W_ResetCanReadVCR();

            //LH 放弃定时器，改为任务
            //SetTimerParam();  
            if(!m_bOfflineMode)
            {
                BeckhoffStsTask();
            }
        }

        public bool m_bBFStsRun = true;
        private void BeckhoffStsTask()
        {
            Task task = new Task(new Action(BeckhoffStsDo));
            task.Start();
        }

        private void BeckhoffStsDo()
        {
            while (m_bBFStsRun)
            {
                VariableMap.EqpStatus myeqpStatus = R_EqpStatus();
                if ((EqpStatusEvent != null) && (eqpStatus != myeqpStatus))
                {
                    Console.WriteLine("设备状态切换");
                    EqpStatusEvent(eqpStatus);
                }

                bool bCuting = false, bFinish = false, bFeed = false;
                BeckhoffRW.ReadPlcVariable(".boRedLight", ref bCuting);
                BeckhoffRW.ReadPlcVariable(".StFinish_Cylinder.bBuzzer", ref bFinish);
                BeckhoffRW.ReadPlcVariable(".StFeed_Cylinder.bBuzzer", ref bFeed);
                if ((bCuting != CutingAlarmFlag) || (bFinish != FinishAlarmFlag) || (bFeed != FeedAlarmFlag))
                {
                    CutingAlarmFlag = bCuting;
                    FinishAlarmFlag = bFinish;
                    FeedAlarmFlag = bFeed;
                    Console.WriteLine("设备报警事件");
                    if (EqpAlarmEvent != null)
                    {
                        EqpAlarmEvent();
                    }
                }
                eqpStatus = myeqpStatus;

                Thread.Sleep(10000);    //10S处理一次
            }
        }

        public void SetTimerParam()
        {
            //到时间的时候执行事件  
            aTimer.Elapsed += new ElapsedEventHandler(TimerChanged);
            aTimer.Interval = 6000;
            aTimer.AutoReset = true;//执行一次 false，一直执行true  
            //是否执行System.Timers.Timer.Elapsed事件  
            aTimer.Enabled = true;
        }
        VariableMap.EqpStatus eqpStatus = VariableMap.EqpStatus.II;
        //定时器
        public void TimerChanged(object source, System.Timers.ElapsedEventArgs e)
        {
                VariableMap.EqpStatus myeqpStatus = R_EqpStatus();
                if ((EqpStatusEvent != null)&&(eqpStatus != myeqpStatus))
                {
                    Console.WriteLine("设备状态切换");
                    EqpStatusEvent.BeginInvoke(eqpStatus, null, null);
                }

                bool bCuting = false, bFinish = false, bFeed = false;
                BeckhoffRW.ReadPlcVariable(".boRedLight", ref bCuting);
                BeckhoffRW.ReadPlcVariable(".StFinish_Cylinder.bBuzzer", ref bFinish);
                BeckhoffRW.ReadPlcVariable(".StFeed_Cylinder.bBuzzer", ref bFeed);
                if ((bCuting != CutingAlarmFlag) || (bFinish != FinishAlarmFlag) || (bFeed != FeedAlarmFlag))
                {
                    CutingAlarmFlag = bCuting;
                    FinishAlarmFlag = bFinish;
                    FeedAlarmFlag = bFeed;
                    Console.WriteLine("设备报警事件");
                    if (EqpAlarmEvent != null)
                    {
                        EqpAlarmEvent.BeginInvoke(null, null);
                    }
                }
            eqpStatus = myeqpStatus;
        }
        /// <summary>
        /// 通知事件,当前是第一工位事件触发是触发事件，工位到6自动变为1；
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private  void adsClient_AdsNotificationEx(object sender, AdsNotificationExEventArgs e)
        {
            try
            {
                if (flag)
                {
                    flag = false;
                    return;
                }
                bool state = false;
                bool state1 = false;
                bool state2 = false;
                bool state3 = false;
                bool state4 = false;
                bool stateFeedReset = false;
                BeckhoffRW.ReadPlcVariable(".bReady_to_CameraEncode", ref state);//到达读码位置
                BeckhoffRW.ReadPlcVariable(".StFinish_ActState.bSuckFinish", ref state1);//下料完成
                BeckhoffRW.ReadPlcVariable(".bCuttingReady_to_Feed", ref state2);//上料单元到切割单元
                BeckhoffRW.ReadPlcVariable(".bCatch_PosReady", ref state3);//切割单元到裂片单元
                BeckhoffRW.ReadPlcVariable(".bBrakeTableReady", ref state4);//裂片单元到下料单元
                BeckhoffRW.ReadPlcVariable(".StFeed_State.bIn_Reset", ref stateFeedReset);//PLC上料复位信号
                if((e.NotificationHandle == (int)BeckhoffRW.notificationHandles[".StFeed_State.bIn_Reset"]) && stateFeedReset)
                {
                    ToolSet.Log.Info("进入 StFeed_State.bIn_Reset...");
                    //PLC上料复位时，将读码工位置为初始值
                    StationEventCount = 0;
                    W_ReadOverVCR(false);//置位
                    W_CheakBCReadPanelIDOK(false);
                    W_CheakBCReadPanelIDNG(false);
                    W_ResetCanReadVCR();
                }
                if ((e.NotificationHandle == (int)BeckhoffRW.notificationHandles[".bReady_to_CameraEncode"]) && state && !Aflag) //
                {
                    ToolSet.Log.Info("进入 bReady_to_CameraEncode...");
                    W_CheakBCReadPanelIDNG(false);
                    W_CheakBCReadPanelIDOK(false);
                    if (this.checkAutoJumpNG)
                    {
                        W_ReStartVCR(false);
                    }                  
                    if (bReadyToCameraEncodeEvent != null)
                    {
                        if (!m_bOfflineMode)
                        {
                            //如果用尽工单号，则报警
                            if (WorkOrderOff && (WorkOrderOffEvent != null) && (!lotUnlimited))
                            {
                                W_CheakBCReadPanelIDNG(true);
                                CIMAlaram(true);
                                WorkOrderOffEvent.BeginInvoke(null, null);
                            }
                            else
                            {
                                
                            }
                        }
                        else
                        {
                            W_CheakBCReadPanelIDNG(false);
                        }

                        StationEventCount++;
                        if (StationEventCount >= StationNumber + 1) //7-1
                        {
                            StationEventCount = 1;
                        }
                        ToolSet.Log.Info("第" + StationEventCount + "次触发读码流程");
                        //LH
                        bReadyToCameraEncodeEvent.BeginInvoke(null,null);
                    }
                }
                //出料信号
                if ((e.NotificationHandle == (int)BeckhoffRW.notificationHandles[".StFinish_ActState.bSuckFinish"]) && state1)
                {
                    if (!m_bOfflineMode)
                    {
                        ToolSet.Log.Info("进入 StFinish_ActState.bSuckFinish...");
                        if (PanelSendOutEvent != null)
                        {
                            PanelSendOutEvent.BeginInvoke(null, null);
                        }
                    }
                    
                }
                //上料单元到切割单元
                if ((e.NotificationHandle == (int)BeckhoffRW.notificationHandles[".bCuttingReady_to_Feed"]) && state2)
                {
                    if (!m_bOfflineMode)
                    {
                        ToolSet.Log.Info("进入 bCuttingReady_to_Feed...");
                        if (PanelFeedUnitToCutingUnitEvent != null)
                        {
                            PanelFeedUnitToCutingUnitEvent.BeginInvoke(null, null);
                        }
                    }
                }

                //切割单元到裂片单元
                if ((e.NotificationHandle == (int)BeckhoffRW.notificationHandles[".bCatch_PosReady"]) && state3)
                {
                    if (!m_bOfflineMode)
                    {
                        ToolSet.Log.Info("进入 bCatch_PosReady...");
                        if (PanelCutingUnitToBrakeUnitEvent != null)
                        {
                            PanelCutingUnitToBrakeUnitEvent.BeginInvoke(null, null);
                        }
                    }
                }

                //裂片单元到下料单元
                if ((e.NotificationHandle == (int)BeckhoffRW.notificationHandles[".bBrakeTableReady"]) && state4)
                {
                    if (!m_bOfflineMode)
                    {
                        ToolSet.Log.Info("进入 bBrakeTableReady...");
                        if (PanelBrakeUnitToFinishUnitEvent != null)
                        {
                            PanelBrakeUnitToFinishUnitEvent.BeginInvoke(null, null);
                        }
                    }
                }
            }
            catch (AdsErrorException code)
            {
                MessageBox.Show(code.ToString());
            }
        }
        /// <summary>
        /// 读码成功,表示PanelID和BC端对比OK or NG
        /// </summary>
        public void W_CheakBCReadPanelIDOK(bool state)
        {
            BeckhoffRW.WritePlcVariable(".CameraEncodeCheak_OK", state);
            ToolSet.Log.Info("发送：CameraEncodeCheak_OK" + state);
            
        }
        public void W_CheakBCReadPanelIDNG(bool state)
        {
            BeckhoffRW.WritePlcVariable(".CameraEncodeCheak_Error", state);
            ToolSet.Log.Info("发送：CameraEncodeCheak_Error" + state);
        }
        /// <summary>
        /// 获取设备的运行状态
        /// </summary>
        /// <returns></returns>
        public VariableMap.EqpStatus R_EqpStatus()
        {
            VariableMap.EqpStatus eqpStatus = VariableMap.EqpStatus.II;
            bool stateRun = false;
            bool stateIdle = false;
            bool stateDown = false;
            BeckhoffRW.ReadPlcVariable(".boGreenLight", ref stateRun);
            BeckhoffRW.ReadPlcVariable(".boYellowLight", ref stateIdle);
            BeckhoffRW.ReadPlcVariable(".boRedLight", ref stateDown);

            if (stateRun)
            {
                eqpStatus = VariableMap.EqpStatus.RR;
            }
            if (stateIdle)
            {
                eqpStatus = VariableMap.EqpStatus.II;
            }
            if (stateDown)
            {
                eqpStatus = VariableMap.EqpStatus.DW;
            }

            return eqpStatus;
        }
        /// <summary>
        /// CIM报警，红灯+蜂鸣器
        /// </summary>
        /// <param name="state"></param>
        public void CIMAlaram(bool state)
        {
            BeckhoffRW.WritePlcVariable(".boRedLightHMI", state);
            BeckhoffRW.WritePlcVariable(".boBuzzerHMI", state);
        }
        /// <summary>
        /// 读码失败后，需要弹窗提示，手动换片，调用此函数来再次启动读码流程
        /// </summary>
        public void W_ReStartVCR(bool state)
        {
            BeckhoffRW.WritePlcVariable(".bVCR_ReStart", state);
        }

        /// <summary>
        /// 暂停上下料
        /// </summary>
        public void W_StopFeedAndFinish(bool state)
        {
            BeckhoffRW.WritePlcVariable(".bStop_Machine_FromCIM", state);
        }
        /// <summary>
        /// 可以读取VCR信号
        /// </summary>
        /// <returns></returns>
        private bool R_CanReadVCR()
        {
            bool state = false;
            BeckhoffRW.ReadPlcVariable(".bReady_to_CameraEncode",ref state);
            return state;
        }

        private  void W_ResetCanReadVCR()
        {
            BeckhoffRW.WritePlcVariable(".bReady_to_CameraEncode",false);
        }


        /// <summary>
        /// 设置是否启用PLC程序中的CIM功能
        /// </summary>
        /// <param name="state"></param>
        public void W_CIMSwitchForPLC(bool state)
        {
            BeckhoffRW.WritePlcVariable(".bStopCIM_ToPLC", state);
        }
        /// <summary>
        /// 可以读取VCR信号
        /// </summary>
        /// <returns></returns>
        private int R_Step()
        {
            int state = 0;
            BeckhoffRW.ReadPlcVariable(".Feed_Fin_State", ref state);
            return state;
        }
        /// <summary>
        /// 读取上料复位信号
        /// </summary>
        /// <returns></returns>
        private bool R_FeedReset()
        {
            bool state = false;
            BeckhoffRW.ReadPlcVariable(".StFeed_State.bIn_Reset", ref state);
            return state;
        }
            //.StFeed_State.bIn_Reset
        /// <summary>
        /// 读取完成VCR信号
        /// </summary>
        /// <returns></returns>
        private void W_ReadOverVCR(bool state)
        {
            BeckhoffRW.WritePlcVariable(".bCameraEncodeFinsih",  state);
            ToolSet.Log.Info(".bCameraEncodeFinsih:" + state.ToString());
        }
        /// <summary>
        /// 获取VCR读码信息
        /// </summary>
        //DateTime NowTime;
        private bool R_ReadVCR(int limitTime = 3000)
        {
            int time = 0;
            ReceivedFlag = false;//修改
            Thread.Sleep(300);
            SendData(System.Text.Encoding.UTF8.GetBytes("+"));
            Thread.Sleep(100);
            //NowTime = DateTime.Now;
            while (ReceivedFlag == false)
            {
                if (time <= limitTime)
                {
                    Thread.Sleep(50);
                    time = time + 50;
                }
                else
                {
                    return false;
                }
            }
            return true;
            
        }
        /// <summary>
        /// （多次）获取VCR读码信息
        /// </summary>
        /// <param name="count"></param>
        /// <returns></returns>
        public bool RMany_ReadVCR(int count)
        {
            for (int i = 0; i < count; i++)
            {
                if (R_ReadVCR())
                {
                    return true;
                }
                if ((i == count) && (!R_ReadVCR()))
                {
                    return false;
                }
                //Thread.Sleep(1500);//第一次触发以后起到延时作用
            }
            return false;
        }
        //一直触发，提取getImage（）发回的线程交互信号，告诉主线程可执行读码核对判断
        public void CognexRead()
        {
            while(true)
            {
                if (Aflag)
                {
                    
                    Task task = new Task(() =>
                    {
                        if (!Cognex.DataMan.SDK.MainForm._wait_ReadCodeHandle.WaitOne(VariableMap.waitTime,true)) //线程同步事件
                        {
                            MessageBox.Show(("< CognexRead >线程超时"));
                        }
                        Aflag = false;
                        CognexReader();
                    });
                    task.Start();
                    task.Wait();
                }
            }
        }
     
        public void CognexReader()
        {
            #region
            //            if (CognexFlag)//康耐视SDK读码
            //            {     //根据读取到的字符，截取“<”到最后一位的字节
            //                if (Cognex.DataMan.SDK.MainForm.strReadCode.Contains("<"))
            //                {
            //                    Cognex.DataMan.SDK.MainForm.strReadCode = Cognex.DataMan.SDK.MainForm.strReadCode.Remove(0, 1);
            //                    Cognex.DataMan.SDK.MainForm.strReadCode = Cognex.DataMan.SDK.MainForm.strReadCode.Remove(Cognex.DataMan.SDK.MainForm.strReadCode.Length - 1, 1);
            //                }
            //                stationPanelID[StationEventCount - 1] = Cognex.DataMan.SDK.MainForm.strReadCode;
            //                W_ReadOverVCR(true);
            //                Cognex.DataMan.SDK.MainForm.strReadCode = "";
            //                checkPanelID();

            //                if ((StationEventCount == StationNumber) && (VCRReadNGEvent != null) && (!AllStationVCRCheck))//VCR读码失败
            //                {
            //                    if (ResetReadNum == 0)//
            //                    {
            //                        if (this.checkAutoJumpNG)
            //                        {
            //                            W_CheakBCReadPanelIDNG(true);
            //                            W_CIMSwitchForPLC(false);
            //                            W_ReStartVCR(true);
            //                            Thread.Sleep( VariableMap.waitTime);
            //                            W_CIMSwitchForPLC(true);
            //                            VCRReadNGEvent.BeginInvoke(StationVCRCheck, null, null);
            //                        }
            //                        else
            //                        {
            //                            Console.WriteLine("读码失败信号");
            //                            //读码失败报警                    
            //                            CIMAlaram(true);
            //                            W_CheakBCReadPanelIDNG(true);
            //                            VCRReadNGEvent.BeginInvoke(StationVCRCheck, null, null);
            //                        }
            //                        ResetReadNum = 2;//重新赋值
            //                        Cognex.DataMan.SDK.MainForm.ReadCodeNumber = 2;
            //                    }
            //                    else//自动重新读码
            //                    {
            //                        ResetReadNum--;
            //                        Cognex.DataMan.SDK.MainForm.ReadCodeNumber--;
            //                        W_CheakBCReadPanelIDNG(true);
            //                        W_ReStartVCR(true);
            //                    }
            //                }
            //                if ((StationEventCount == StationNumber) && (VCRReadOKEvent != null) && (AllStationVCRCheck))//VCR读码成功
            //                {
            //                    //读码失败报警清除
            //                    ResetReadNum = 2;//重新赋值
            //                    Cognex.DataMan.SDK.MainForm.ReadCodeNumber = 2;
            //                    CIMAlaram(false);
            //#region 这个连接Mas系统后注释掉
            //                    if (!SYSMACGateway.CIMModeFlag)
            //                    {
            //                        Console.WriteLine("读码成功信号");
            //                        W_CheakBCReadPanelIDOK(true);
            //                        VCRReadOKEvent.BeginInvoke(null, null);//发送数据到显示界面
            //                    }
            //#endregion
            //                    else
            //                    {
            //                        VCRReadOKEvent.BeginInvoke(null, null);//发送数据到显示界面
            //                    }
            //                    VCRDisplayEvent.BeginInvoke(null, null);
            //                }
            //            }
            //            else//
            #endregion
            {
                ToolSet.Log.Info("读码...");
                if (RMany_ReadVCR(1))   //读取完成
                {
                    ToolSet.Log.Info("读码完成");
                    stationPanelID[StationEventCount - 1] = Encoding.UTF8.GetString(AllData.ToArray());
                    W_ReadOverVCR(true);
                }
                else
                {
                    W_ReadOverVCR(true);
                    ToolSet.Log.Info("读码器无返回值,读码器异常!!");
                    stationPanelID[StationEventCount - 1] = "CamraError"; //存放之前先将字符串置为空
                }
                ToolSet.Log.Info(StationEventCount.ToString() + "码值：" + stationPanelID[StationEventCount-1]);
                checkPanelID();
                //TimeSpan ts = DateTime.Now - NowTime;
                //ToolSet.Log.Info("VCR反馈时长:"+ts.TotalSeconds.ToString());
                if ((StationEventCount == StationNumber) && (VCRReadNGEvent != null) && (!AllStationVCRCheck))//VCR读码失败
                {
                    ToolSet.Log.Info("VCR读码失败...");
                    VCRDisplayEvent.BeginInvoke(null, null);

                    //当前交互流程结束，CIM可以离线
                    ReadCodeFlow = true;
                    if (!m_bOfflineMode)
                    {
                        if ((CIMOffLineEvent != null) && (CIMswitch == true))
                        {
                            CIMOffLineEvent.BeginInvoke(null, null);
                            CIMswitch = false;
                        }
                    }
                    
                    //ToolSet.Log.Info("二维码失败验证!");
                    //if (ResetReadNum == 0)//
                    {
                        if (this.checkAutoJumpNG)
                        {
                            ToolSet.Log.Info("VCR读码失败之后勾选直接发送一次翻转信号！！！");
                            //在此直接给和读码成功一样的信号
                            W_CheakBCReadPanelIDOK(true);
                            //ReadCodeFlow = false;
                            VCRReadNGEvent.BeginInvoke(StationVCRCheck, null, null);
                            //LH?  不应该是false吗
                            //W_CheakBCReadPanelIDNG(true);
                            ////重启PLC流程？
                            //W_CIMSwitchForPLC(false);
                            //W_ReStartVCR(true);
                            //Thread.Sleep( VariableMap.waitTime);
                            //W_CIMSwitchForPLC(true);
                        }
                        else
                        { 
                            VCRReadNGEvent.BeginInvoke(StationVCRCheck, null, null);
                            Console.WriteLine("读码失败信号");
                            //读码失败报警                    
                            CIMAlaram(true);
                            W_CheakBCReadPanelIDNG(true);
                           
                        }
                        //ResetReadNum = 2;//重新赋值
                    }
                    //else//自动重新读码
                    //{
                    //    ResetReadNum--;
                    //    W_CheakBCReadPanelIDNG(true);
                    //    W_ReStartVCR(true);
                    //}
                }
                if ((StationEventCount == StationNumber) && (VCRReadOKEvent != null) && (AllStationVCRCheck))//VCR读码成功
                {
                    ToolSet.Log.Info("VCR读码成功...");
                    VCRDisplayEvent.BeginInvoke(null, null);

                    //ToolSet.Log.Info("二维码失败验证!");
                    //读码失败报警清除
                    //ResetReadNum = 2;//重新赋值

                    //当前交互流程结束，CIM可以离线
                    ReadCodeFlow = true;
                    if(!m_bOfflineMode)
                    {
                        if ((CIMOffLineEvent != null) && (CIMswitch == true))
                        {
                            CIMOffLineEvent.BeginInvoke(null, null);
                            CIMswitch = false;
                        }
                    }
                    
                    CIMAlaram(false);
                    if (!SYSMACGateway.CIMModeFlag || m_bOfflineMode) //离线
                    {
                        Console.WriteLine("读码成功信号");
                        W_CheakBCReadPanelIDOK(true);
                        //更新VCR界面显示验证结果，以及把数据存入数据库
                        if (PanelDisplayEvent != null)
                        {
                            bool[] bCheck = new bool[6];
                            for(int i=0;i<6;i++)
                            {
                                bCheck[i] = true;
                            }
                            PanelDisplayEvent.BeginInvoke(bCheck, null, null);
                        }
                    }
                    else
                    {
                        //LH
                        VCRReadOKEvent();
                        //VCRReadOKEvent.BeginInvoke(null, null);//发送数据到显示界面
                    }
                }

                ToolSet.Log.Info("VCR读码end");
            }
        }
        /// <summary>
        /// 工作流程，一次读六个工位，读完之后存放在stationPanelID字符串数组中，每个工位最多读取四次，如果读取失败，则该工位的panelID为空，可能是硬件故障出现。
        /// </summary>
        public void workStart()
        {
            //if (CognexFlag)//康耐视SDK读码
            //{
            //    CognexReadCodeEvent();//读码事件  
            //    Aflag = true;
            //}
            //else
            {
                CognexReader();
            }
        }
        private void checkPanelID()
        {
            allStationVCRCheck = true;
            for (int i = 0; i < StationNumber; i++)
            {
                //注释以后查看传的是那个值，让read_result判断
                if ((StationPanelID[i] == "noread") || (StationPanelID[i] == "") || (StationPanelID[i] == "CamraError"))
                {
                    stationVCRCheck[i] = false;
                    //ToolSet.Log.Info("VCR回复:" + StationPanelID[i]);
                }
                else
                {
                    stationVCRCheck[i] = true;
                }
                allStationVCRCheck = allStationVCRCheck && stationVCRCheck[i];
                ToolSet.Log.Info("VCR回复:" + StationPanelID[i]);
            }
        }
  
        //获取当前时刻，当前地点，panel所处的位置 [Addr 的值为 FeedToCuting - CutingToBrake - BrakeToFinish - Finish]
        /// <summary>
        /// count 为-1时，表示没有找到
        /// </summary>
        /// <param name="QueueLastStationPanelID"></param>
        /// <param name="Addr"></param>
        /// <param name="count"，在队列中的位置></param>
        public void GetCurrentPanelIDMessage(ref Queue<PanelIDMessageClass> QueueLastStationPanel,ref List<PanelIDMessageClass> panels, string Addr)
        {
            int i = 0;
            List<PanelIDMessageClass> PanelList = new List<PanelIDMessageClass>();
            ToolSet.Log.Info("QueueLastStationPanel.Count：" + QueueLastStationPanel.Count);
            PanelList.AddRange(QueueLastStationPanel.ToArray());
            ToolSet.Log.Info("PanelList.Count：" + PanelList.Count);  //
            QueueLastStationPanel.Clear();//清除队列
            foreach (PanelIDMessageClass feed in PanelList)
            {
                ToolSet.Log.Info("VCR与机台:" + feed.PanelID[0]);
                //从前往后遍历
                if (feed.bFeedUnitIN)
                {
                    ToolSet.Log.Info("VCR:" + feed.PanelID[0] + "feed.bFeedUnitIN");
                    if (feed.bFeedUnitToCutingUnit)
                    {
                        ToolSet.Log.Info("VCR:" + feed.PanelID[0] + "feed.bFeedUnitToCutingUnit");
                        if (feed.bCutingUnitToBrakeUnit)
                        {
                            ToolSet.Log.Info("VCR:" + feed.PanelID[0] + "feed.bCutingUnitToBrakeUnit");
                            if (feed.bBrakeUnitToFinishUnit)
                            {
                                ToolSet.Log.Info("VCR:" + feed.PanelID[0] + "feed.bBrakeUnitToFinishUnit");
                                if (feed.bFinishUnitOUT)
                                {
                                    //结束
                                }
                                else
                                {
                                    if (Addr == "Finish")
                                    {
                                        PanelList[i].bFinishUnitOUT = true; 
                                        //panel = feed;
                                        panels.Add(feed);
                                    }
                                }
                            }
                            else
                            {
                                if (Addr == "BrakeToFinish")
                                {
                                    PanelList[i].bBrakeUnitToFinishUnit = true;
                                    //panel = feed;
                                    panels.Add(feed);
                                }
                            }
                        }
                        else
                        { 
                            if(Addr == "CutingToBrake")
                            {
                                PanelList[i].bCutingUnitToBrakeUnit = true;
                                //panel = feed;
                                panels.Add(feed);
                            }
                        }
                    }
                    else
                    {
                        if (Addr == "FeedToCuting")
                        {
                            PanelList[i].bFeedUnitToCutingUnit = true;
                            //panel = feed;
                            panels.Add(feed);
                        }
                    }
                }
                else 
                {
                    //结束
                }
                QueueLastStationPanel.Enqueue(feed);//遍历入队
                i++;
            }           
        }

        public void Close()
        {
            try
            {
                ClearSelf();
                BeckhoffRW.BeckhoffMotionDispose();
            }
            catch (Exception) { }
        }

        public void Test()
        {
            Queue<PanelIDMessageClass> QueueLastStationPanelID = new Queue<PanelIDMessageClass>();
            PanelIDMessageClass c1 = new PanelIDMessageClass();
            c1.bFeedUnitIN = true;
            c1.bFeedUnitToCutingUnit = true;
            c1.bCutingUnitToBrakeUnit = true;
            c1.bBrakeUnitToFinishUnit = true;
            c1.bFinishUnitOUT = false;
            QueueLastStationPanelID.Enqueue(c1);


            PanelIDMessageClass c2 = new PanelIDMessageClass();
            c2.bFeedUnitIN = true;
            c2.bFeedUnitToCutingUnit = true;
            c2.bCutingUnitToBrakeUnit = true;
            c2.bBrakeUnitToFinishUnit = false;
            c2.bFinishUnitOUT = false;
            QueueLastStationPanelID.Enqueue(c2);

            PanelIDMessageClass c3 = new PanelIDMessageClass();
            c3.bFeedUnitIN = true;
            c3.bFeedUnitToCutingUnit = true;
            c3.bCutingUnitToBrakeUnit = false;
            c3.bBrakeUnitToFinishUnit = false;
            c3.bFinishUnitOUT = false;
            QueueLastStationPanelID.Enqueue(c3);

            PanelIDMessageClass c4 = new PanelIDMessageClass();
            c4.bFeedUnitIN = true;
            c4.bFeedUnitToCutingUnit = false;
            c4.bCutingUnitToBrakeUnit = false;
            c4.bBrakeUnitToFinishUnit = false;
            c4.bFinishUnitOUT = false;
            QueueLastStationPanelID.Enqueue(c4);

            PanelIDMessageClass c5 = new PanelIDMessageClass();
            c5.bFeedUnitIN = false;
            c5.bFeedUnitToCutingUnit = false;
            c5.bCutingUnitToBrakeUnit = false;
            c5.bBrakeUnitToFinishUnit = false;
            c5.bFinishUnitOUT = false;
            QueueLastStationPanelID.Enqueue(c5);


            //[Addr 的值为 FeedToCuting - CutingToBrake - BrakeToFinish - Finish]
            //GetCurrentPanelIDMessage(ref QueueLastStationPanelID, "FeedToCuting");
            //GetCurrentPanelIDMessage(ref QueueLastStationPanelID, "CutingToBrake");
            //GetCurrentPanelIDMessage(ref QueueLastStationPanelID, "BrakeToFinish");
            //GetCurrentPanelIDMessage(ref QueueLastStationPanelID, "Finish");

        }

        public void test1()
        {
            if (bReadyToCameraEncodeEvent != null)
            {
                //LH
                bReadyToCameraEncodeEvent.BeginInvoke(null, null);
            }
        }
    }
}
