﻿using System;
using System.Text;
using System.Threading;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CIM通讯
{
    //发送和接收只有一个通道，也就是一个时间点只允许一个变量交互。
    //为了应对不同的后缀造成变量名不同，使用字典的方式处理
    public class VariableMap:SYSMACGateway
    {
        //public delegate void BCMsgCanReadEventHandler(string Msg);
        public static int  waitTime = 4000;
        public delegate void BCToCtLBitONHandler(object sender, EventArgs e);
        public delegate void CtLToBCRepalyHandler();

        public Action<string> TimeOutEvent;
        public Action<string> BCMessageCanReadEvent;
        public Action<string> BCDateTimeCanReadEvent;
        public Action<string,int,string,int,string> BCTrayValidationCanReadEvent;
        public Action<string, int, string, int,string> BCTrayValidationDisplayEvent;
        public Action<string,int> BCPNLValidationCanReadEvent;
        public Action<bool[]> BCPNLValidationDisplayEvent;
        public event Action<bool> BC_Aliving;
        public delegate void SD_BCToCtL_CommandEventHandler(List<int> listMessage);
        public event SD_BCToCtL_CommandEventHandler SD_BCToCtL_Command_MessageEvent;
        public event SD_BCToCtL_CommandEventHandler SD_BCToCtL_Command_DateTimeEvent;
        public event SD_BCToCtL_CommandEventHandler SD_BCToCtL_Command_TrayValidationEvent;
        public event SD_BCToCtL_CommandEventHandler SD_BCToCtL_Command_PNLValidationEvent;

        //线程间通讯
        public ManualResetEvent _waitPanelIDCheackHandle = new ManualResetEvent(false);
        public ManualResetEvent _waitTrayIDCheackHandle = new ManualResetEvent(false);

        //public ManualResetEvent _waitPanelRemoveCheackHandle = new ManualResetEvent(false);
        //public EventWaitHandle _waitPanelUnitOut1CheackHandle = new AutoResetEvent(false);
        //public EventWaitHandle _waitPanelUnitOut2CheackHandle = new AutoResetEvent(false);
        //public EventWaitHandle _waitPanelUnitIn1CheackHandle = new AutoResetEvent(false);
        //public EventWaitHandle _waitPanelUnitIn2CheackHandle = new AutoResetEvent(false);
        //public EventWaitHandle _waitPanelReceiveCheackHandle = new AutoResetEvent(false);
        //public EventWaitHandle _waitProcessStartCheackHandle = new AutoResetEvent(false);
        //public EventWaitHandle _waitProcessDataCheackHandle = new AutoResetEvent(false);
        //public EventWaitHandle _waitPanelSendOutCheackHandle = new AutoResetEvent(false);


        Thread thEqpAlive = null;
        Thread thBCAlive = null;

        public enum EqpStatus
        {
            II = 1,//IDLE 空闲--暂停
            RR = 2,//RUN  正常切割运动
            DW = 3,//DOWN  宕机-报警
            PM = 4,//PM    / 设备维护中---这个不需要      
            MC = 5,//Model / Change 换型 --换型号
        }
        public enum Bit
        {
            ON = 1,
            OFF = 0,
        }
        //报警号
        public enum AlarmID
        {
            A = 99,
        }
        public enum AlarmLevel
        {
            Light = 1,
            Heavy = 2,
        }
        public enum AlarmStatus
        {
            AlarmSet = 1,
            AlarmClear = 2,
        }
        public enum EqpRepair_Action
        {
            CallStart = 1,
            RepairStart = 2,
            End = 3,
        }
        //换班
        public enum CapacityInfo_Reason
        {
            ShiftToZero = 0,//正常上传
            NormalReporting = 1,//换班清零
        }
        public static string EventingName
        {
            get
            {
               return  SYSMACGateway.EventingName;
            }
            set
            {
                  SYSMACGateway.EventingName = value;
            }
        }
        string[] strEqpStatus = new string[] { " ", "II", "RR", "DW", "PM", "MC" };//设备状态
        #region 从BC端读到的信息，事件触发的时候会写这几个变量
        public static string RstrUnitID = "";   //单元号
        #endregion
        # region 向BC端写数据时会写这几个变量
        public static string strUnitID = "";   //单元号
        public static string RemovestrPanelID = ""; //panel号(非正常出料的ID)
        public static string strCallOperatorID = "";    //叫修ID 
        public static string strRepairOperatorID = "";  //维修ID
        public static string strEndOperatorID = "";     //维修结束ID
        public static string strCallStartTime = "";     //叫修开始时间
        public static string strRepairStartTime = "";   //维修开始时间
        public static string strEndTime = "";           //维修结束时间
        #endregion
        //定义类内全局的变量
        #region 使用这几个数组的长度
        //private int[] UnitID = new int[7];   //单元号
        //private int[] TrayID = new int[10];  //Tray盘号
        //private int[] PanelID = new int[10]; //panel号
        //private int[] DateTime = new int[7]; //时间
        //private int[] CIMMessage = new int[40]; //BC信息

        private int UnitIDlength = 7;   //单元号长度
        private int TrayIDlength = 10;  //Tray盘号长度
        private int PanelIDlength = 10; //panel号长度
        private int RecipeIDlength = 10; //产品型号号长度
        private int DateTimelength = 7; //时间长度
        private int CIMMessagelength = 40; //BC信息长度

        public static int EQP_ReasonCode;
        #endregion

        #region 报修相关
        private int[] CallOperatorID = new int[10];    //叫修ID 
        private int[] RepairOperatorID = new int[10];  //维修ID
        private int[] EndOperatorID = new int[10];     //维修结束ID
        private int[] CallStartTime = new int[7];      //叫修开始时间
        private int[] RepairStartTime = new int[7];    //维修开始时间
        private int[] EndTime = new int[7];            //维修结束时间
        #endregion     
 
        private CIMParams cIMparams;
        public VariableMap(CIMParams cIMparams)
            : base(cIMparams)
        {
            cIMparams.ReadPrm();
            this.cIMparams = cIMparams;
            strUnitID = cIMparams.UnitID;

            if (m_bOfflineMode)
                return;

            variableCompolet.Changed += new EventHandler(variableCompolet_Changed);
            SD_BCToCtL_Command_MessageEvent += new SD_BCToCtL_CommandEventHandler(BCToCtL_MessageBitON);
            SD_BCToCtL_Command_DateTimeEvent += new SD_BCToCtL_CommandEventHandler(BCToCtL_DateTimeBitON);
            SD_BCToCtL_Command_PNLValidationEvent += new SD_BCToCtL_CommandEventHandler(BCToCtL_PNLValidationBitON);
            SD_BCToCtL_Command_TrayValidationEvent += new SD_BCToCtL_CommandEventHandler(BCToCtL_TrayValidationBitON);

            #region 线程初始化

            thEqpAlive = new Thread(EqpAlive);
            thEqpAlive.IsBackground = true;
            thBCAlive = new Thread(BCAlive);
            thBCAlive.IsBackground = true;
            thBCAlive.Start();

            #endregion
        }

        private void BCAlive()
        {
            while (true)
            {
                if (BCToCtL_BCAlive() == false)
                {
                    int i = 0;
                    while (!BCToCtL_BCAlive())
                    {                       
                        Thread.Sleep(400);
                        i++;
                        if (i >= 10)
                        {
                            break;
                        }
                    }
                    if (BCToCtL_BCAlive() == false)
                    {
                        if (BC_Aliving != null)
                        {
                            BC_Aliving.BeginInvoke(false, null, null);
                        }
                    }
                }
                else
                {
                    int i = 0;
                    while (BCToCtL_BCAlive())
                    {                       
                        Thread.Sleep(400);
                        i++;
                        if (i >= 10)
                        {
                            break;
                        }
                    }
                    if (BCToCtL_BCAlive() == true)
                    {
                        if (BC_Aliving != null)
                        {
                            BC_Aliving.BeginInvoke(false, null, null);
                        }
                    }
                }
             }
        }
        //在线与否
        public void CtLToBC_EqpAlive(bool state)
        {
            if (state == true)
            {
                thEqpAlive = new Thread(EqpAlive);
                thEqpAlive.IsBackground = true;
                thEqpAlive.Start();
            }
            else
            {
                if(thEqpAlive != null)
                {
                    try
                    {
                        thEqpAlive.Abort();//终止线程
                    }
                    catch (Exception ex)
                    {
                        ToolSet.Log.Info("终止EqpAlive线程异常："+ex.Message);
                    }
                }
            }
        }
        /// <summary>
        /// 规则：四秒ON，四秒OFF,交替出现
        /// </summary>
        private void EqpAlive()
        {
            while (true)
            {
                WriteVariable("RV_CtLToBC_Event_EqpAlive", false);
                Thread.Sleep( VariableMap.waitTime);
                WriteVariable("RV_CtLToBC_Event_EqpAlive", true);
                Thread.Sleep( VariableMap.waitTime);
            }
        }
        /// <summary>
        /// CIM在线与否
        /// 1：CIM ON -- true
        /// 0：CIM OFF -- false
        /// </summary>
        /// <param name="state"></param>
        public void CtLToBC_CIMMode(bool state)
        {
            if (state)
            {
                SYSMACGateway.CIMModeFlag = state;
                Int16[] CIMModeChange = new Int16[10];
                CIMModeChange[0] = Convert.ToInt16(state);
                WriteVariable("RV_CtLToBC_Event_CIMModeChange", CIMModeChange);
            }
            else
            {
                Int16[] CIMModeChange = new Int16[10];
                CIMModeChange[0] = Convert.ToInt16(state);
                WriteVariable("RV_CtLToBC_Event_CIMModeChange", CIMModeChange);
                SYSMACGateway.CIMModeFlag = state;
            }
        }

        #region CtlToBC的BitOFF方法
        public void BitOFF_CtLToBC_EqpStatus()
        {
            WriteVariable("RV_CtLToBC_Event_EqpStatusChange[0]", (Int32)Bit.OFF);
        }
        public void BitOFF_CtLToBC_EventAlarm()
        {
            WriteVariable("RV_CtLToBC_Event_Alarm[0]", (Int32)Bit.OFF);
        }
        public void BitOFF_CtLToBC_TactTime()
        {
            WriteVariable("RV_CtLToBC_Event_TactTime[0]", (Int32)Bit.OFF);
        }
        public void BitOFF_CtLToBC_TrayInfoRequest()
        {
            WriteVariable("RV_CtLToBC_Event_TrayInfoRequest[0]", (Int32)Bit.OFF);
        }
        public void BitOFF_CtLToBC_PanelInfoRequest()
        {
            WriteVariable("RV_CtLToBC_Event_PanelInfoRequest[0]", (Int32)Bit.OFF);
        }
        public void BitOFF_CtLToBC_PanelReceive()
        {
            WriteVariable("RV_CtLToBC_Event_PanelReceive[0]", (Int32)Bit.OFF);
        }
        public void BitOFF_CtLToBC_ProcessStart()
        {
            WriteVariable("RV_CtLToBC_Event_ProcessStart[0]", (Int32)Bit.OFF);
        }
        public void BitOFF_CtLToBC_PanelUnitIn1()
        {
            WriteVariable("RV_CtLToBC_Event_PanelUnitIn1[0]", (Int32)Bit.OFF);
        }
        public void BitOFF_CtLToBC_PanelUnitIn2()
        {
            WriteVariable("RV_CtLToBC_Event_PanelUnitIn2[0]", (Int32)Bit.OFF);
        }
        public void BitOFF_CtLToBC_ProcessData()
        {
            WriteVariable("RV_CtLToBC_Event_ProcessData[0]", (Int32)Bit.OFF);
        }
        
        public void BitOFF_CtLToBC_PanelUnitOut1()
        {
            WriteVariable("RV_CtLToBC_Event_PanelUnitOut1[0]", (Int32)Bit.OFF);
        }
        public void BitOFF_CtLToBC_PanelUnitOut2()
        {
            WriteVariable("RV_CtLToBC_Event_PanelUnitOut2[0]", (Int32)Bit.OFF);
        }
        public void BitOFF_CtLToBC_PanelSendOut()
        {
            WriteVariable("RV_CtLToBC_Event_PanelSendOut[0]", (Int32)Bit.OFF);
        }
        public void BitOFF_CtLToBC_PanelRemove()
        {
            WriteVariable("RV_CtLToBC_Event_PanelRemove[0]", (Int32)Bit.OFF);
        }
        public void BitOFF_CtLToBC_EqpRepair()
        {
            WriteVariable("RV_CtLToBC_Event_EqpRepair[0]", (Int32)Bit.OFF);
        }
        public void BitOFF_CtLToBC_CapacityInfo()
        {
            WriteVariable("RV_CtLToBC_Event_CapacityInfo[0]", (Int32)Bit.OFF);
        }
        #endregion

        #region CtlToBC的写变量方法
        /// <summary>
        /// 设备状态信息上报
        /// </summary>
        /// <param name="EqpStatus"></param>
        public void CtLToBC_EqpStatus(EqpStatus eqpStatus)
        {
            List<Int32> LeqpStatus = new List<Int32>();
            LeqpStatus.Add((Int32)Bit.ON);
            LeqpStatus.Add((int)eqpStatus);
            LeqpStatus.AddRange(AsciiToIntArray(strEqpStatus[(int)eqpStatus]));
            if (eqpStatus.ToString() == "PM" || eqpStatus.ToString() == "MC")//4为PM----5为MC
            {
                switch (CIMparams.Prefix)
                {
                    //根据机台号来修改对应的值位置，有四个
                    //Unit Status #1--->设备状态
                    //ReasonCode #1
                    case "CtL":
                        {
                            //判断是PM或MC的开始还是结束----根据当前值就可以判断是开始还是结束
                            LeqpStatus.Add(0);
                            LeqpStatus.Add(EQP_ReasonCode);
                        }
                        break;
                    case "CtR":
                        {
                            LeqpStatus.Add(0);
                            LeqpStatus.Add(0);

                            LeqpStatus.Add(0);
                            LeqpStatus.Add(EQP_ReasonCode);
                        }
                        break;
                    case "Ct1L":
                        {
                            LeqpStatus.Add(0);
                            LeqpStatus.Add(0);
                            LeqpStatus.Add(0);
                            LeqpStatus.Add(0);

                            LeqpStatus.Add(0);
                            LeqpStatus.Add(EQP_ReasonCode);
                        }
                        break;
                    case "Ct1R":
                        {
                            LeqpStatus.Add(0);
                            LeqpStatus.Add(0);
                            LeqpStatus.Add(0);
                            LeqpStatus.Add(0);
                            LeqpStatus.Add(0);
                            LeqpStatus.Add(0);
                            LeqpStatus.Add(0);
                            LeqpStatus.Add(0);

                            LeqpStatus.Add(0);
                            LeqpStatus.Add(EQP_ReasonCode);
                        }
                        break;
                    default:
                        {

                        }
                        break;
                }
            }
            int L = variableLength("RV_CtLToBC_Event_EqpStatusChange") - LeqpStatus.Count();
            Int32[] Reserve = new Int32[L];
            LeqpStatus.AddRange(Reserve);
            Int32[] AeqpStatus = LeqpStatus.ToArray();
            WriteVariable("RV_CtLToBC_Event_EqpStatusChange", AeqpStatus);
        }

        object obEqpSts = new object();
        public void CtLToBC_EqpStatusTask(EqpStatus eqpStatus, int tiomeout)
        {
            if (m_bOfflineMode)
                return;
            //LH 
            //Task task = new Task(() =>
            //{
                //LH 
                lock (obEqpSts)
                {
                    _waitSD_BCToCtL_Event_EqpStatusChangeHandle.Reset();
                    CtLToBC_EqpStatus(eqpStatus);
                    if (!_waitSD_BCToCtL_Event_EqpStatusChangeHandle.WaitOne(tiomeout)) //线程同步事件
                    {
                        Console.WriteLine("< CtLToBC_EqpStatus >线程超时");
                        //if (BCToCtL_BCAlive() == true)
                        //{
                        //    TimeOutEvent.BeginInvoke("< CtLToBC_EqpStatus >线程超时", null, null);

                        //}
                    }
                    else
                    {
                        Console.WriteLine("< CtLToBC_EqpStatus >线程正常");
                    }
                    _waitSD_BCToCtL_Event_EqpStatusChangeHandle.Reset();
                    BitOFF_CtLToBC_EqpStatus();
                }
            //});
            //task.Start();
            //task.Wait();
        }
        /// <summary>
        /// 将所有的字符串转为指定长度的int数组
        /// </summary>
        /// <param name="IntArrray"></param>
        /// <param name="Str"></param>
        private void StringToIntArray(Int32[] IntArrray, string Str)
        {
            if (Str == null)
            {
                Str = "";
            }

            if (Str.Length % 2 == 0)
            {
                if (Str.Length / 2 < IntArrray.Length)
                {
                    int L = IntArrray.Length - Str.Length / 2;
                    char[] a = new char[L*2];
                    for (int i = 0; i < L * 2; i++)
                    {
                        a[i] = ' ';
                    }
                    string s = new string(a);
                    Str = Str + s;
                }
            }
            else
            {
                if ((Str.Length+1) / 2 < IntArrray.Length)
                {
                    int L = IntArrray.Length - (Str.Length + 1)/2;
                    char[] a = new char[L * 2];
                    for (int i = 0; i < L * 2; i++)
                    {
                        a[i] = ' ';
                    }
                    string s = new string(a);
                    Str = Str + s;
                }
            }
            Int32[] sInt32 = new Int32[Str.Count()];
            sInt32 = AsciiToIntArray(Str);
            Array.Copy(sInt32, 0, IntArrray, 0, sInt32.Length);
        }

        /// <summary>
        /// 开启线程发送报警信息给BC
        /// </summary>
        /// <param name="AlarmID"></param>
        /// <param name="alarmLevel"></param>
        /// <param name="alarmStatus"></param>
        /// <param name="tiomeout"></param>

        private void CtLToBC_EventAlarm(Int32 AlarmID, AlarmLevel alarmLevel,AlarmStatus alarmStatus)
        {
            int[] UnitID = new int[this.UnitIDlength];
            System.Console.WriteLine("6线程ID为：{0}", Thread.CurrentThread.ManagedThreadId);
            List<Int32> LeventAlarm = new List<Int32>();
            LeventAlarm.Add((Int32)Bit.ON);
            StringToIntArray(UnitID, strUnitID);
            LeventAlarm.AddRange(UnitID);
            if (AlarmID <= 65536)
            {

                LeventAlarm.Add((Int32)AlarmID);
                LeventAlarm.Add(0);
            }
            else
            {
                Int32[] aAlarmID = new Int32[2];
                aAlarmID[0] = (Int32)(AlarmID % 65536);
                aAlarmID[1] = (Int32)(AlarmID / 65536);
                LeventAlarm.AddRange(aAlarmID);
            }
            LeventAlarm.Add((Int32)alarmLevel);
            LeventAlarm.Add((Int32)alarmStatus);
            
            int L = variableLength("RV_CtLToBC_Event_Alarm") - LeventAlarm.Count();
            Int32[] Reserve = new Int32[L];
            LeventAlarm.AddRange(Reserve);
            Int32 []AeventAlarm = LeventAlarm.ToArray();
            WriteVariable("RV_CtLToBC_Event_Alarm", AeventAlarm);
        }
        public void CtLToBC_EventAlarmTask(Int32 AlarmID, AlarmLevel alarmLevel, AlarmStatus alarmStatus, int tiomeout)
        {
            //LH
            //Task task = new Task(() =>
            //{
                _waitSD_BCToCtL_Event_AlarmHandle.Reset();
                CtLToBC_EventAlarm(AlarmID, alarmLevel, alarmStatus);
                if (!_waitSD_BCToCtL_Event_AlarmHandle.WaitOne(tiomeout)) //线程同步事件
                {
                    Console.WriteLine("< CtLToBC_EventAlarm >线程超时");
                    //if (BCToCtL_BCAlive() == true)
                    //{
                    //    TimeOutEvent.BeginInvoke("< CtLToBC_EventAlarm >线程超时", null, null);
                    //}
                }
                else
                {
                    Console.WriteLine("< CtLToBC_EventAlarm >线程正常");
                }
                _waitSD_BCToCtL_Event_AlarmHandle.Reset();
                BitOFF_CtLToBC_EventAlarm();
            //});
            //task.Start();
            //task.Wait();
        }
 
        private void CtLToBC_TactTime(Int32 tactTime)
        {
            List<Int32> LtactTime = new List<Int32>();
            LtactTime.Add((Int32)Bit.ON);
            if (tactTime <= 65536)
            {
                
                LtactTime.Add((Int32)tactTime);
                LtactTime.Add(0);
            }
            else
            {
                Int32[] atactTime = new Int32[2];
                atactTime[0] = (Int32)(tactTime % 65536);
                atactTime[1] = (Int32)(tactTime / 65536);
                LtactTime.AddRange(atactTime);
            }
            int L = variableLength("RV_CtLToBC_Event_TactTime") - LtactTime.Count();
            Int32[] Reserve = new Int32[L];
            LtactTime.AddRange(Reserve);
            Int32[] AtactTime = LtactTime.ToArray();
            WriteVariable("RV_CtLToBC_Event_TactTime", AtactTime);
        }
        public void CtLToBC_TactTimeTask(Int32 tactTime, int tiomeout)
        {
            //LH
            //Task task = new Task(() =>
            //{
                _waitSD_BCToCtL_Event_TactTimeHandle.Reset();
                CtLToBC_TactTime(tactTime);
                if (!_waitSD_BCToCtL_Event_TactTimeHandle.WaitOne(tiomeout)) //线程同步事件
                {
                    Console.WriteLine("< CtLToBC_TactTime >线程超时");
                    //if (BCToCtL_BCAlive() == true)
                    //{
                    //    TimeOutEvent.BeginInvoke("< CtLToBC_TactTime >线程超时", null, null);
                    //}
                }
                else
                {
                    Console.WriteLine("< CtLToBC_TactTime >线程正常");
                }
                _waitSD_BCToCtL_Event_TactTimeHandle.Reset();
                BitOFF_CtLToBC_TactTime();
            //});
            //task.Start();
            //task.Wait();
        }

        private void CtLToBC_TrayInfoRequest(string strTrayID)
        {
            int[] UnitID = new int[UnitIDlength];
            int[] TrayID = new int[TrayIDlength];
            List<Int32> LtrayInfoRequest = new List<Int32>();
            LtrayInfoRequest.Add((Int32)Bit.ON);
            StringToIntArray(UnitID, strUnitID);
            LtrayInfoRequest.AddRange(UnitID);
            StringToIntArray(TrayID, strTrayID);
            LtrayInfoRequest.AddRange(TrayID);
            int L = variableLength("RV_CtLToBC_Event_TrayInfoRequest") - LtrayInfoRequest.Count();
            Int32[] Reserve = new Int32[L];
            LtrayInfoRequest.AddRange(Reserve);
            Int32[] AtrayInfoRequest = LtrayInfoRequest.ToArray();
            WriteVariable("RV_CtLToBC_Event_TrayInfoRequest", AtrayInfoRequest);
        }

        object obTrayInfo = new object();
        public void CtLToBC_TrayInfoRequestTask(int tiomeout, string strTrayID)
        {
            //LH
            //Task task = new Task(() =>
            //{
                lock (obTrayInfo)
                {
                    ToolSet.Log.Info("运行CtLToBC_TrayInfoRequestTask:"+ strTrayID);
                    _waitSD_BCToCtL_Event_TrayInfoRequestHandle.Reset();
                    CtLToBC_TrayInfoRequest(strTrayID);
                    System.Console.WriteLine("执行任务事件线程ID为：{0}", Thread.CurrentThread.ManagedThreadId);
                    if (!_waitSD_BCToCtL_Event_TrayInfoRequestHandle.WaitOne(tiomeout)) //线程同步事件
                    {
                        ToolSet.Log.Info("< CtLToBC_TrayInfoRequest >线程超时");
                        //if (BCToCtL_BCAlive() == true)
                        //{
                        //    TimeOutEvent.BeginInvoke("< CtLToBC_TrayInfoRequest >线程超时", null, null);
                        //}
                    }
                    else
                    {
                        Console.WriteLine("< CtLToBC_TrayInfoRequest >线程正常");
                        ToolSet.Log.Info("< CtLToBC_TrayInfoRequest >线程正常");
                    }
                    _waitSD_BCToCtL_Event_TrayInfoRequestHandle.Reset();
                    BitOFF_CtLToBC_TrayInfoRequest();
                }
            //});
            //task.Start();
            //task.Wait();
        }

        private void CtLToBC_PanelInfoRequest(string strPanelID, string strTrayID)
        {
            int[] UnitID = new int[UnitIDlength];
            int[] PanelID = new int[PanelIDlength];
            int[] TrayID = new int[TrayIDlength];
            List<Int32> LpanelInfoRequest = new List<Int32>();
            LpanelInfoRequest.Add((Int32)Bit.ON);
            StringToIntArray(UnitID, strUnitID);
            LpanelInfoRequest.AddRange(UnitID);
            StringToIntArray(PanelID, strPanelID);
            LpanelInfoRequest.AddRange(PanelID);
            StringToIntArray(TrayID, strTrayID);
            LpanelInfoRequest.AddRange(TrayID);
            int L = variableLength("RV_CtLToBC_Event_PanelInfoRequest") - LpanelInfoRequest.Count();
            Int32[] Reserve = new Int32[L];
            LpanelInfoRequest.AddRange(Reserve);
            Int32[] ApanelInfoRequest = LpanelInfoRequest.ToArray();
            WriteVariable("RV_CtLToBC_Event_PanelInfoRequest", ApanelInfoRequest);
            ToolSet.Log.Info(string.Format("CtLToBC_Event_PanelInfoRequest上传---PanelID:{0},TrayID:{1}",strPanelID, strTrayID));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="tiomeout"></param>
        /// <returns></returns>
        public bool CtLToBC_PanelInfoRequestTask(string strPanelID, string strTrayID,int tiomeout)
        {
            //LH
            bool flag = true;
            //Task task = new Task(() =>
            //{
                _waitSD_BCToCtL_Event_PanelInfoRequestHandle.Reset();
                CtLToBC_PanelInfoRequest(strPanelID, strTrayID);
                if (!_waitSD_BCToCtL_Event_PanelInfoRequestHandle.WaitOne(tiomeout)) //线程同步事件
                {
                    ToolSet.Log.Info("< CtLToBC_PanelInfoRequest >线程超时 -- " + strPanelID);
                    flag = false;
                }
                else
                {
                    //Console.WriteLine("< CtLToBC_PanelInfoRequest >线程正常");
                    ToolSet.Log.Info("< CtLToBC_PanelInfoRequest >线程正常");
                    flag = true;
                }
                _waitSD_BCToCtL_Event_PanelInfoRequestHandle.Reset();
                BitOFF_CtLToBC_PanelInfoRequest();
            //});
            //task.Start();
            //task.Wait();          
            return flag;
        }
        private void CtLToBC_PanelReceive(string strPanelID)
        {
            int[] PanelID = new int[PanelIDlength];
            List<Int32> LpanelReceive = new List<Int32>();
            LpanelReceive.Add((Int32)Bit.ON);
            StringToIntArray(PanelID, strPanelID);
            LpanelReceive.AddRange(PanelID);
            int L = variableLength("RV_CtLToBC_Event_PanelReceive") - LpanelReceive.Count();
            Int32[] Reserve = new Int32[L];
            LpanelReceive.AddRange(Reserve);
            Int32[] ApanelReceive = LpanelReceive.ToArray();
            WriteVariable("RV_CtLToBC_Event_PanelReceive", ApanelReceive);
        }

        public void CtLToBC_PanelReceiveTask(string strPanelID, int tiomeout)
        {
            //LH
            //Task task = new Task(() =>
            //{
                _waitSD_BCToCtL_Event_PanelReceiveHandle.Reset();
                CtLToBC_PanelReceive(strPanelID);
                if (!_waitSD_BCToCtL_Event_PanelReceiveHandle.WaitOne(tiomeout)) //线程同步事件
                {
                    //this._waitPanelReceiveCheackHandle.Set();
                    ToolSet.Log.Info("< CtLToBC_PanelReceive >线程超时 -- " + strPanelID);
                    //if (BCToCtL_BCAlive() == true)
                    //{
                    //    TimeOutEvent.BeginInvoke("< CtLToBC_PanelReceive >线程超时", null, null);
                    //}
                }
                else
                {
                    Console.WriteLine("< CtLToBC_PanelReceive >线程正常");
                    //this._waitPanelReceiveCheackHandle.Set();
                }
                _waitSD_BCToCtL_Event_PanelReceiveHandle.Reset();
                BitOFF_CtLToBC_PanelReceive();
            //});
            //task.Start();
            //task.Wait();
        }

        private void CtLToBC_ProcessStart(string strPanelID)
        {
            int[] PanelID = new int[PanelIDlength];
            List<Int32> LprocessStart = new List<Int32>();
            LprocessStart.Add((Int32)Bit.ON);
            StringToIntArray(PanelID, strPanelID);
            LprocessStart.AddRange(PanelID);
            int L = variableLength("RV_CtLToBC_Event_ProcessStart") - LprocessStart.Count();
            Int32[] Reserve = new Int32[L];
            LprocessStart.AddRange(Reserve);
            Int32[] AprocessStart = LprocessStart.ToArray();
            WriteVariable("RV_CtLToBC_Event_ProcessStart", AprocessStart);
        }

        public void CtLToBC_ProcessStartTask(string strPanelID, int tiomeout)
        {
            //LH
            //Task task = new Task(() =>
            //{
                _waitSD_BCToCtL_Event_ProcessStartHandle.Reset();
                CtLToBC_ProcessStart(strPanelID);
                if (!_waitSD_BCToCtL_Event_ProcessStartHandle.WaitOne(tiomeout)) //线程同步事件
                {
                    //this._waitProcessStartCheackHandle.Set();
                    ToolSet.Log.Info("< CtLToBC_ProcessStart >线程超时 -- " + strPanelID);
                    //if (BCToCtL_BCAlive() == true)
                    //{
                    //    TimeOutEvent.BeginInvoke("< CtLToBC_ProcessStart >线程超时", null, null);
                    //}
                    
                }
                else
                {
                    //this._waitProcessStartCheackHandle.Set();
                    Console.WriteLine("< CtLToBC_ProcessStart >线程正常");
                }
                _waitSD_BCToCtL_Event_ProcessStartHandle.Reset();
                BitOFF_CtLToBC_ProcessStart();
            //});
            //task.Start();
            //task.Wait();
        }

        private void CtLToBC_PanelUnitIn1(string strPanelID)
        {
            int[] UnitID = new int[UnitIDlength];
            int[] PanelID = new int[PanelIDlength];
            List<Int32> LpanelUnitIn1 = new List<Int32>();
            LpanelUnitIn1.Add((Int32)Bit.ON);
            StringToIntArray(PanelID, strPanelID);
            LpanelUnitIn1.AddRange(PanelID);
            StringToIntArray(UnitID, strUnitID);
            LpanelUnitIn1.AddRange(UnitID);
            int L = variableLength("RV_CtLToBC_Event_PanelUnitIn1") - LpanelUnitIn1.Count();
            Int32[] Reserve = new Int32[L];
            LpanelUnitIn1.AddRange(Reserve);
            Int32[] ApanelUnitIn1 = LpanelUnitIn1.ToArray();
            WriteVariable("RV_CtLToBC_Event_PanelUnitIn1", ApanelUnitIn1);
        }

        public void CtLToBC_PanelUnitIn1Task(string strPanelID, int tiomeout)
        {
            //LH
            //Task task = new Task(() =>
            //{
                _waitSD_BCToCtL_Event_PanelUnitIn1Handle.Reset();
                CtLToBC_PanelUnitIn1(strPanelID);
                if (!_waitSD_BCToCtL_Event_PanelUnitIn1Handle.WaitOne(tiomeout)) //线程同步事件
                {
                    //this._waitPanelUnitIn1CheackHandle.Set();
                    ToolSet.Log.Info("< CtLToBC_PanelUnitIn1 >线程超时 -- " + strPanelID);
                    //if (BCToCtL_BCAlive() == true)
                    //{
                    //    TimeOutEvent.BeginInvoke("< CtLToBC_PanelUnitIn1 >线程超时", null, null);
                    //}
                }
                else
                {
                    //this._waitPanelUnitIn1CheackHandle.Set();
                    Console.WriteLine("< CtLToBC_PanelUnitIn1 >线程正常");
                }
                _waitSD_BCToCtL_Event_PanelUnitIn1Handle.Reset();
                BitOFF_CtLToBC_PanelUnitIn1();
           // });
           // task.Start();
           //task.Wait();
        }

        private void CtLToBC_PanelUnitIn2(string strPanelID)
        {

            int[] UnitID = new int[UnitIDlength];
            int[] PanelID = new int[PanelIDlength];
            List<Int32> LpanelUnitIn2 = new List<Int32>();
            LpanelUnitIn2.Add((Int32)Bit.ON);
            StringToIntArray(PanelID, strPanelID);
            LpanelUnitIn2.AddRange(PanelID);
            StringToIntArray(UnitID, strUnitID);
            LpanelUnitIn2.AddRange(UnitID);
            int L = variableLength("RV_CtLToBC_Event_TrayInfoRequest") - LpanelUnitIn2.Count();
            Int32[] Reserve = new Int32[L];
            LpanelUnitIn2.AddRange(Reserve);
            Int32[] ApanelUnitIn2 = LpanelUnitIn2. ToArray();
            WriteVariable("RV_CtLToBC_Event_PanelUnitIn2", ApanelUnitIn2);
        }

        public void CtLToBC_PanelUnitIn2Task(string strPanelID,int tiomeout)
        {
            //LH
            //Task task = new Task(() =>
            //{
                _waitSD_BCToCtL_Event_PanelUnitIn2Handle.Reset();
                CtLToBC_PanelUnitIn2(strPanelID);
                if (!_waitSD_BCToCtL_Event_PanelUnitIn2Handle.WaitOne(tiomeout)) //线程同步事件
                {
                    //this._waitPanelUnitIn2CheackHandle.Set();
                    ToolSet.Log.Info("< CtLToBC_PanelUnitIn2 >线程超时 -- " + strPanelID);
                    //if (BCToCtL_BCAlive() == true)
                    //{
                    //    TimeOutEvent.BeginInvoke("< CtLToBC_PanelUnitIn2 >线程超时", null, null);
                    //}
                }
                else
                {
                    //this._waitPanelUnitIn2CheackHandle.Set();
                    Console.WriteLine("< CtLToBC_PanelUnitIn2 >线程正常");
                }
                _waitSD_BCToCtL_Event_PanelUnitIn2Handle.Reset();
                BitOFF_CtLToBC_PanelUnitIn2();
            //});
            //task.Start();
            //task.Wait();
        }

        private void CtLToBC_ProcessData(string strRecipeID,Int32 parameter1, Int32 parameter2, Int32 parameter3, string strPanelID)
        {

            int[] UnitID = new int[UnitIDlength];
            int[] PanelID = new int[PanelIDlength];
            int[] RecipeID = new int[RecipeIDlength];
            List<Int32> LprocessData = new List<Int32>();
            LprocessData.Add((Int32)Bit.ON);
            StringToIntArray(PanelID, strPanelID);
            LprocessData.AddRange(PanelID);
            StringToIntArray(UnitID, strUnitID);
            LprocessData.AddRange(UnitID);

            StringToIntArray(RecipeID, strRecipeID);
            LprocessData.AddRange(RecipeID);

            LprocessData.Add(parameter1);
            LprocessData.Add(parameter2);
            LprocessData.Add(parameter3);
            int L = 150 - LprocessData.Count();
            Int32[] Reserve = new Int32[L];
            LprocessData.AddRange(Reserve);
            Int32[] AprocessData = LprocessData.ToArray();
            WriteVariable("RV_CtLToBC_Event_ProcessData", AprocessData);
            ToolSet.Log.Info("出RV_CtLToBC_Event_ProcessData--WriteVariable");
        }

        public void CtLToBC_ProcessDataTask(string strRecipeID,Int32 parameter1, Int32 parameter2, Int32 parameter3, string strPanelID,int tiomeout)
        {
            //LH
            //Task task = new Task(() =>
            //{
            //LH
                ToolSet.Log.Info("进入CtLToBC_ProcessData  -- " + strPanelID);
                _waitSD_BCToCtL_Event_ProcessDataHandle.Reset();
                CtLToBC_ProcessData(strRecipeID,parameter1, parameter2, parameter3, strPanelID);
                if (!_waitSD_BCToCtL_Event_ProcessDataHandle.WaitOne(tiomeout)) //线程同步事件
                {
                    //this._waitProcessDataCheackHandle.Set();
                    ToolSet.Log.Info("< CtLToBC_ProcessData >线程超时 -- " + strPanelID);
                    //if (BCToCtL_BCAlive() == true)
                    //{
                    //    TimeOutEvent.BeginInvoke("< CtLToBC_ProcessData >线程超时", null, null);
                    //}
                }
                else
                {
                    //this._waitProcessDataCheackHandle.Set();
                    Console.WriteLine("< CtLToBC_ProcessData >线程正常");
                }
                _waitSD_BCToCtL_Event_ProcessDataHandle.Reset();
                BitOFF_CtLToBC_ProcessData();
            //});
            //task.Start();
            //task.Wait();
        }

        private void CtLToBC_PanelUnitOut1(string strPanelID)
        {

            int[] UnitID = new int[UnitIDlength];
            int[] PanelID = new int[PanelIDlength];
            List<Int32> LpanelUnitOut1 = new List<Int32>();
            LpanelUnitOut1.Add((Int32)Bit.ON);
            StringToIntArray(PanelID, strPanelID);
            LpanelUnitOut1.AddRange(PanelID);
            StringToIntArray(UnitID, strUnitID);
            LpanelUnitOut1.AddRange(UnitID);
            int L = variableLength("RV_CtLToBC_Event_PanelUnitOut1") - LpanelUnitOut1.Count();
            Int32[] Reserve = new Int32[L];
            LpanelUnitOut1.AddRange(Reserve);
            Int32[] ApanelUnitOut1 = LpanelUnitOut1.ToArray();
            WriteVariable("RV_CtLToBC_Event_PanelUnitOut1", ApanelUnitOut1);
        }

        public void CtLToBC_PanelUnitOut1Task(string strPanelID, int tiomeout)
        {
            //LH
            //Task task = new Task(() =>
            //{
                _waitSD_BCToCtL_Event_PanelUnitOut1Handle.Reset();
                CtLToBC_PanelUnitOut1(strPanelID);
                if (!_waitSD_BCToCtL_Event_PanelUnitOut1Handle.WaitOne(tiomeout)) //线程同步事件
                {
                    //this._waitPanelUnitOut1CheackHandle.Set();
                    ToolSet.Log.Info("< CtLToBC_PanelUnitOut1 >线程超时 -- " + strPanelID);
                    //if (BCToCtL_BCAlive() == true)
                    //{
                    //    TimeOutEvent.BeginInvoke("< CtLToBC_PanelUnitOut1 >线程超时", null, null);
                    //}
                }
                else
                {
                    //this._waitPanelUnitOut1CheackHandle.Set();
                    Console.WriteLine("< CtLToBC_PanelUnitOut1 >线程正常");
                }
                _waitSD_BCToCtL_Event_PanelUnitOut1Handle.Reset();
                BitOFF_CtLToBC_PanelUnitOut1();
            //});
            //task.Start();
            //task.Wait();
        }

        private void CtLToBC_PanelUnitOut2(string strPanelID)
        {
            int[] UnitID = new int[UnitIDlength];
            int[] PanelID = new int[PanelIDlength];
            List<Int32> LpanelUnitOut2 = new List<Int32>();
            LpanelUnitOut2.Add((Int32)Bit.ON);
            StringToIntArray(PanelID, strPanelID);
            LpanelUnitOut2.AddRange(PanelID);
            StringToIntArray(UnitID, strUnitID);
            LpanelUnitOut2.AddRange(UnitID);
            int L = variableLength("RV_CtLToBC_Event_PanelUnitOut2") - LpanelUnitOut2.Count();
            Int32[] Reserve = new Int32[L];
            LpanelUnitOut2.AddRange(Reserve);
            Int32[] ApanelUnitOut2 = LpanelUnitOut2.ToArray();
            WriteVariable("RV_CtLToBC_Event_PanelUnitOut2", ApanelUnitOut2);
        }

        public void CtLToBC_PanelUnitOut2Task(string strPanelID,int tiomeout)
        {
            //LH
            //Task task = new Task(() =>
            //{
                _waitSD_BCToCtL_Event_PanelUnitOut2Handle.Reset();
                CtLToBC_PanelUnitOut2(strPanelID);
                if (!_waitSD_BCToCtL_Event_PanelUnitOut2Handle.WaitOne(tiomeout)) //线程同步事件
                {
                    //this._waitPanelUnitOut2CheackHandle.Set();
                    ToolSet.Log.Info("< CtLToBC_PanelUnitOut2 >线程超时 -- " + strPanelID);
                    ////if (BCToCtL_BCAlive() == true)
                    //{
                    //    TimeOutEvent.BeginInvoke("< CtLToBC_PanelUnitOut2 >线程超时", null, null);
                    //}
                }
                else
                {
                    //this._waitPanelUnitOut2CheackHandle.Set();
                    Console.WriteLine("< CtLToBC_PanelUnitOut2 >线程正常");
                }
                _waitSD_BCToCtL_Event_PanelUnitOut2Handle.Reset();
                BitOFF_CtLToBC_PanelUnitOut2();
            //});
            //task.Start();
            //task.Wait();
        }

        private void CtLToBC_PanelSendOut(string strPanelID)
        {
            ToolSet.Log.Info("进RV_CtLToBC_Event_PanelSendOut--WriteVariable");
            int[] UnitID = new int[UnitIDlength];
            int[] PanelID = new int[PanelIDlength];
            List<Int32> LpanelSendOut = new List<Int32>();
            LpanelSendOut.Add((Int32)Bit.ON);
            StringToIntArray(PanelID, strPanelID);
            LpanelSendOut.AddRange(PanelID);
            StringToIntArray(UnitID, strUnitID);
            LpanelSendOut.AddRange(UnitID);
            int L = 30 - LpanelSendOut.Count();
            Int32[] Reserve = new Int32[L];
            LpanelSendOut.AddRange(Reserve);
            Int32[] ApanelSendOut = LpanelSendOut.ToArray();
            WriteVariable("RV_CtLToBC_Event_PanelSendOut", ApanelSendOut);
            ToolSet.Log.Info("出RV_CtLToBC_Event_PanelSendOut--WriteVariable");
        }

        public void CtLToBC_PanelSendOutTask(string strPanelID, int tiomeout)
        {
            //LH
            //Task task = new Task(() =>
            //{
                _waitSD_BCToCtL_Event_PanelSendOutHandle.Reset();
                CtLToBC_PanelSendOut(strPanelID);
                if (!_waitSD_BCToCtL_Event_PanelSendOutHandle.WaitOne(tiomeout)) //线程同步事件
                {
                    //this._waitPanelSendOutCheackHandle.Set();
                    ToolSet.Log.Info("< CtLToBC_PanelSendOut >线程超时 -- " + strPanelID);
                    //线程超时再执行一次SendOut
                    CtLToBC_PanelSendOut(strPanelID);
                    if (!_waitSD_BCToCtL_Event_PanelSendOutHandle.WaitOne(tiomeout))
                    {
                        ToolSet.Log.Info("第二次发送< CtLToBC_PanelSendOut >线程超时 -- " + strPanelID);
                    }
                    //if (BCToCtL_BCAlive() == true)
                    //{
                    //    TimeOutEvent.BeginInvoke("< CtLToBC_PanelSendOut >线程超时", null, null);
                    //}
                }
                else
                {
                    //this._waitPanelSendOutCheackHandle.Set();
                    //Console.WriteLine("< CtLToBC_PanelSendOut >线程正常");
                    ToolSet.Log.Info("< CtLToBC_PanelSendOut >线程正常 -- " + strPanelID);
                }
                _waitSD_BCToCtL_Event_PanelSendOutHandle.Reset();
                BitOFF_CtLToBC_PanelSendOut();
            //});
            //task.Start();
            //task.Wait();//
        }

        private void CtLToBC_PanelRemove(string strPanelID)
        {
            int[] UnitID = new int[UnitIDlength];
            int[] PanelID = new int[PanelIDlength];
            List<Int32> LpanelRemove = new List<Int32>();
            LpanelRemove.Add((Int32)Bit.ON);
            StringToIntArray(PanelID, strPanelID);
            LpanelRemove.AddRange(PanelID);
            StringToIntArray(UnitID, strUnitID);
            LpanelRemove.AddRange(UnitID);
            int L = variableLength("RV_CtLToBC_Event_PanelRemove") - LpanelRemove.Count();
            Int32[] Reserve = new Int32[L];
            LpanelRemove.AddRange(Reserve);
            Int32[] ApanelRemove = LpanelRemove.ToArray();
            WriteVariable("RV_CtLToBC_Event_PanelRemove", ApanelRemove);
        }

        object obPanelRemove = new object();
        public bool CtLToBC_PanelRemoveTask(string strPanelID,int tiomeout)
        {
            if (m_bOfflineMode)
                return true;
            //LH
            bool flag = true;
            //Task task = new Task(() =>
            //{
                lock(obPanelRemove)
                {
                    _waitSD_BCToCtL_Event_PanelRemoveHandle.Reset();
                    CtLToBC_PanelRemove(strPanelID);
                    if (!_waitSD_BCToCtL_Event_PanelRemoveHandle.WaitOne(tiomeout)) //线程同步事件
                    {
                        ToolSet.Log.Info("< CtLToBC_PanelRemove >线程超时 -- " + strPanelID);
                        flag = false;
                        //_waitPanelRemoveCheackHandle.Set();
                    }
                    else
                    {
                        ToolSet.Log.Info("< CtLToBC_PanelRemove >线程正常 -- " + strPanelID);
                        Console.WriteLine("< CtLToBC_PanelRemove >线程正常");
                        //_waitPanelRemoveCheackHandle.Set();
                    }
                    _waitSD_BCToCtL_Event_PanelRemoveHandle.Reset();
                    BitOFF_CtLToBC_PanelRemove();
                }
            //});
            //task.Start();
            //task.Wait();
            return flag;
        }

        private void CtLToBC_EqpRepair(EqpRepair_Action eqpRepair_Action)
        {
            List<Int32> LeqpRepair = new List<Int32>();
            LeqpRepair.Add((Int32)Bit.ON);
            StringToIntArray(CallOperatorID, strCallOperatorID);
            LeqpRepair.AddRange(CallOperatorID);
            StringToIntArray(RepairOperatorID, strRepairOperatorID);
            LeqpRepair.AddRange(RepairOperatorID);
            StringToIntArray(EndOperatorID, strEndOperatorID);
            LeqpRepair.AddRange(EndOperatorID);
            StringToIntArray(CallStartTime, strCallStartTime);
            LeqpRepair.AddRange(CallStartTime);
            StringToIntArray(RepairStartTime, strRepairStartTime);
            LeqpRepair.AddRange(RepairStartTime);
            StringToIntArray(EndTime, strEndTime);
            LeqpRepair.AddRange(EndTime);
            LeqpRepair.Add((Int32)eqpRepair_Action);
            int L = variableLength("RV_CtLToBC_Event_EqpRepair") - LeqpRepair.Count();
            Int32[] Reserve = new Int32[L];
            LeqpRepair.AddRange(Reserve);
            Int32[] AeqpRepair = LeqpRepair.ToArray();
            WriteVariable("RV_CtLToBC_Event_EqpRepair", AeqpRepair);
        }

        object obEqpReqair = new object();
        public void  CtLToBC_EqpRepairTask(EqpRepair_Action eqpRepair_Action,int tiomeout)
        {
            //LH
            //Task task = new Task(() =>
            //{
                lock(obEqpReqair)
                {
                    _waitSD_BCToCtL_Event_EqpRepairHandle.Reset();
                    CtLToBC_EqpRepair(eqpRepair_Action);
                    if (_waitSD_BCToCtL_Event_EqpRepairHandle.WaitOne(tiomeout)) //线程同步事件
                    {
                        ToolSet.Log.Info("< CtLToBC_EqpRepair >线程完成 ");
                        BitOFF_CtLToBC_EqpRepair();
                    }
                    else
                    {
                        Console.WriteLine("< CtLToBC_EqpRepair >线程超时");
                        //TimeOutEvent.BeginInvoke("< CtLToBC_EqpRepair >线程超时", null, null);
                    }
                    _waitSD_BCToCtL_Event_EqpRepairHandle.Reset();
                    BitOFF_CtLToBC_EqpRepair();
                }
            //});
            //task.Start();
            //task.Wait();
        }

        private void CtLToBC_CapacityInfo(Int32 CapacityInfo, Int32 capacityInfo_Shift, CapacityInfo_Reason capacityInfo_Reason)
        {
            int[] UnitID = new int[UnitIDlength];
            List<Int32> LcapacityInfo = new List<Int32>();
            LcapacityInfo.Add((Int32)Bit.ON);
            StringToIntArray(UnitID, strUnitID);
            LcapacityInfo.AddRange(UnitID);
            LcapacityInfo.Add(CapacityInfo);
            LcapacityInfo.Add(capacityInfo_Shift);
            LcapacityInfo.Add((Int32)capacityInfo_Reason);
            int L = variableLength("RV_CtLToBC_Event_CapacityInfo") - LcapacityInfo.Count();
            Int32[] Reserve = new Int32[L];
            LcapacityInfo.AddRange(Reserve);
            Int32[] AcapacityInfo = LcapacityInfo.ToArray();
            WriteVariable("RV_CtLToBC_Event_CapacityInfo", AcapacityInfo);
        }

        public void CtLToBC_CapacityInfoTask(Int32 CapacityInfo, Int32 capacityInfo_Shift, CapacityInfo_Reason capacityInfo_Reason, int tiomeout)
        {
            //LH
            //Task task = new Task(() =>
            //{
                ToolSet.Log.Info("传入进来的班次"+ capacityInfo_Shift);
                _waitSD_BCToCtL_Event_CapacityInfoHandle.Reset();
                CtLToBC_CapacityInfo(CapacityInfo, capacityInfo_Shift, capacityInfo_Reason);
                if (!_waitSD_BCToCtL_Event_CapacityInfoHandle.WaitOne(tiomeout)) //线程同步事件
                {
                    ToolSet.Log.Info("< CtLToBC_CapacityInfo >线程超时");
                    //if (BCToCtL_BCAlive() == true)
                    //{
                    //    TimeOutEvent.BeginInvoke("< CtLToBC_CapacityInfo >线程超时", null, null);
                    //}
                }
                else
                {
                    Console.WriteLine("< CtLToBC_CapacityInfo >线程正常");
                }
                _waitSD_BCToCtL_Event_CapacityInfoHandle.Reset();
                BitOFF_CtLToBC_CapacityInfo();
            //});
            //task.Start();
            //task.Wait();
        }

        #endregion

        #region BCToCtl的读变量方法
        public bool BCToCtL_BCAlive()
        {
            if ((Int32)ReadVariable("SD_BCToCtL_Command_BCAlive") == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void BCToCtL_Message(ref string RstrCIMMessage, List<Int32> bCToCtl_Message)
        {

            int[] UnitID = new int[UnitIDlength];
            int[] CIMMessage = new int[CIMMessagelength];
            //int length = sYSMACGateway.variableLength("SD_BCToCtL_Command_Message");
            //Int32[] bCToCtl_Message = new Int32[length];
            //bCToCtl_Message = (Int32[])sYSMACGateway.ReadVariable("SD_BCToCtL_Command_Message");
            //List<Int32> lCToCtl_Message = new List<int>();
            List<Int32> lUnitID = new List<int>();
            List<Int32> lCIMMessage = new List<int>();
            for (int i = 1; i <= UnitID.Length; i++)
            {
                lUnitID.Add(bCToCtl_Message[i]);
            }
            for (int i = UnitID.Length+1; i <= (CIMMessage.Length + UnitID.Length); i++)
            {
                lCIMMessage.Add(bCToCtl_Message[i]);
            }
            RstrUnitID = IntArrayToAscii(lUnitID.ToArray());
            RstrCIMMessage = IntArrayToAscii(lCIMMessage.ToArray());
        }

        public void BCToCtL_DateTime(ref string RstrDateTime, List<Int32> bCToCtl_DateTime)
        {
            int[] mDateTime = new int[DateTimelength];
            //int length = sYSMACGateway.variableLength("SD_BCToCtL_Command_DateTime");
            //Int32[] bCToCtl_DateTime = new Int32[length];
            //bCToCtl_DateTime = (Int32[])sYSMACGateway.ReadVariable("SD_BCToCtL_Command_DateTime");
            //List<Int32> lCToCtl_DateTime = new List<int>();
            List<Int32> lDateTime = new List<int>();
            for (int i = 1; i <= mDateTime.Length; i++) //取 1-7 舍弃0
            {
                lDateTime.Add(bCToCtl_DateTime[i]);
            }
            RstrDateTime = IntArrayToAscii(lDateTime.ToArray());
        }

        public void BCToCtL_TrayValidation(ref string RstrTrayID, ref int TrayRTCode, ref string WorkOrderID, ref int Quantity,ref string RecipeID, List<Int32> bCToCtl_TrayValidation)
        {
            int[] TrayID = new int[TrayIDlength];
            //int length = sYSMACGateway.variableLength("SD_BCToCtL_Command_TrayValidation");
            //Int32[] bCToCtl_TrayValidation = new Int32[length];
            //bCToCtl_TrayValidation = (Int32[])sYSMACGateway.ReadVariable("SD_BCToCtL_Command_TrayValidation");
            //List<Int32> lCToCtl_TrayValidation = new List<int>();
            List<Int32> lTrayID = new List<int>();
            List<Int32> lWorkOrderID = new List<int>();
            List<Int32> lRecipeID = new List<int>();
            lTrayID.AddRange(bCToCtl_TrayValidation.Skip(1).Take(10).ToArray());
            TrayRTCode = bCToCtl_TrayValidation[11];
            lWorkOrderID.AddRange(bCToCtl_TrayValidation.Skip(12).Take(10).ToArray());
            lRecipeID.AddRange(bCToCtl_TrayValidation.Skip(22).Take(10).ToArray());
            Quantity = bCToCtl_TrayValidation[72];
            //for (int i = 1; i <= TrayID.Length; i++)
            //{
            //    lTrayID.Add(bCToCtl_TrayValidation[i]);
            //}
            //for (int i = TrayID.Length+1; i <= (1 + TrayID.Length); i++)
            //{
            //    TrayRTCode = bCToCtl_TrayValidation[i];
            //}
            RstrTrayID = IntArrayToAscii(lTrayID.ToArray());
            WorkOrderID = IntArrayToAscii(lWorkOrderID.ToArray());
            RecipeID = IntArrayToAscii(lRecipeID.ToArray());
        }

        public void BCToCtL_PNLValidation(ref string RstrPanelID, ref int PanelRTCode, List<Int32> bCToCtl_PNLValidation)
        {
            int[] PanelID = new int[PanelIDlength];
            //int length = sYSMACGateway.variableLength("SD_BCToCtL_Command_PNLValidation");
            //Int32[] bCToCtl_PNLValidation = new Int32[length];
            //bCToCtl_PNLValidation = (Int32[])sYSMACGateway.ReadVariable("SD_BCToCtL_Command_PNLValidation");
            //List<Int32> lCToCtl_PNLValidation = new List<int>();
            List<Int32> lPanelID = new List<int>();
            for (int i = 1; i <= PanelID.Length; i++)
            {
                lPanelID.Add(bCToCtl_PNLValidation[i]);
            }
            for (int i = PanelID.Length+1; i <= (1 + PanelID.Length); i++)
            {
                PanelRTCode = bCToCtl_PNLValidation[i];
            }
            RstrPanelID = IntArrayToAscii(lPanelID.ToArray());
            ToolSet.Log.Info("2-判定值PanelRTCode" + PanelRTCode.ToString ()); 
            ToolSet.Log.Info("验证plan-BCToCtL_PNLValidation:" + RstrPanelID.ToString()+"验证完成!");
        }

        //BitON之后做处理
        //BitON的任务处理集中函数
        //public void BCToCtLBitONTask(BCToCtLBitONHandler mBCToCtLBitONHandler, int tiomeout)
        //{
        //    Task task = new Task(() =>
        //    {
        //        mBCToCtLBitONHandler(null, new EventArgs());
        //    });
        //    task.Start();
        //    task.Wait();
        //}
        string RstrCIMMessage = "";

        public void BCToCtL_MessageBitON(List<Int32> Message)
        {
            //LH
            //Task task = new Task(() =>
            //{ 
                _waitSD_BCToCtL_Command_MessageHandle.Reset();
                if (BCToCtL_MessageBitStates() == 1)//Bit ON
                {
                    BCToCtL_Message(ref RstrCIMMessage, Message);
                    CtLToBC_MessageReply(true);
                }

                if (_waitSD_BCToCtL_Command_MessageHandle.WaitOne(VariableMap.waitTime)) //线程同步事件
                {
                    Console.WriteLine("<BCToCtL_MessageBitOff >线程正常"); 
                    CtLToBC_MessageReply(false);
                }
                else
                {
                    ToolSet.Log.Info("<BCToCtL_MessageBitOff >线程超时");
                    CtLToBC_MessageReply(false);
                    //if (BCToCtL_BCAlive() == true)
                    //{
                    //    TimeOutEvent.BeginInvoke("< BCToCtL_MessageBitOff >线程超时", null, null);
                    //}
                }
                _waitSD_BCToCtL_Command_MessageHandle.Reset();
                if (BCMessageCanReadEvent != null)
                {
                    BCMessageCanReadEvent.BeginInvoke(RstrCIMMessage, null, null);
                }

            //});
            // task.Start();
            // task.Wait();
        }
        string RstrDateTime = "";
        public void BCToCtL_DateTimeBitON(List<Int32> Message)
        {
            //LH
            //Task task = new Task(() =>
            //{ 
                _waitSD_BCToCtL_Command_DateTimeHandle.Reset();
                if (BCToCtL_DateTimeBitStates() == 1)//Bit ON
                {
                    BCToCtL_DateTime(ref RstrDateTime, Message);
                    CtLToBC_DateTimeReply(true);
                }
                if (_waitSD_BCToCtL_Command_DateTimeHandle.WaitOne(VariableMap.waitTime)) //线程同步事件
                {
                    Console.WriteLine("<BCToCtL_DateTimeBitOff >线程正常");
                    CtLToBC_DateTimeReply(false);

                }
                else
                {
                    Console.WriteLine("<BCToCtL_DateTimeBitOff >线程超时");
                    CtLToBC_DateTimeReply(false);
                    //if (BCToCtL_BCAlive() == true)
                    //{
                    //    TimeOutEvent.BeginInvoke("< BCToCtL_DateTimeBitOff >线程超时", null, null);
                    //}
                }
                _waitSD_BCToCtL_Command_DateTimeHandle.Reset();
                if (BCDateTimeCanReadEvent != null) //写系统时间比较慢
                {
                    BCDateTimeCanReadEvent.BeginInvoke(RstrDateTime,null,null);
                }
                
            //});
            //task.Start();
            //task.Wait();
        }
        string RstrTrayID = "";
        int TrayRTCode = 0;
        string WorkOrderID = "";
        int Quantity = 0;
        string RecipeID = "";
        public void BCToCtL_TrayValidationBitON(List<Int32> Message)
        {
            //LH
            //Task task = new Task(() =>
            //{
                _waitSD_BCToCtL_Command_TrayValidationHandle.Reset();
                if (BCToCtL_TrayValidationBitStates() == 1)//Bit ON
                {
                    BCToCtL_TrayValidation(ref RstrTrayID, ref TrayRTCode, ref WorkOrderID, ref Quantity,ref RecipeID, Message);
                    CtLToBC_TrayValidationReply(true);
                    ToolSet.Log.Info("进入BCToCtL_TrayValidationBitON");
                }
                ToolSet.Log.Info("进入_waitSD_BCToCtL_Command_TrayValidationHandle等待...");
                if (_waitSD_BCToCtL_Command_TrayValidationHandle.WaitOne(VariableMap.waitTime)) //线程同步事件
                {
                    _waitSD_BCToCtL_Command_TrayValidationHandle.Reset();
                    this._waitTrayIDCheackHandle.Set();
                    ToolSet.Log.Info("<BCToCtL_TrayValidationBitOff >线程正常");
                    CtLToBC_TrayValidationReply(false);
                }
                else
                {
                    _waitSD_BCToCtL_Command_TrayValidationHandle.Reset();
                    this._waitTrayIDCheackHandle.Set();
                    CtLToBC_TrayValidationReply(false);
                    ToolSet.Log.Info("<BCToCtL_TrayValidationBitOff >线程超时");
                    //if (BCToCtL_BCAlive() == true)
                    //{
                    //    TimeOutEvent.BeginInvoke("< BCToCtL_TrayValidationBitOff >线程超时", null, null);
                    //}
                }
                //更新Tray队列，及相应的参数值
                if (BCTrayValidationCanReadEvent != null)
                {
                    //BCTrayValidationCanReadEvent.BeginInvoke(RstrTrayID,TrayRTCode,WorkOrderID,Quantity, null, null);
                    BCTrayValidationCanReadEvent(RstrTrayID, TrayRTCode, WorkOrderID, Quantity, RecipeID);
                }
                if (BCTrayValidationDisplayEvent != null)
                {
                    BCTrayValidationDisplayEvent.BeginInvoke(RstrTrayID, TrayRTCode, WorkOrderID, Quantity, RecipeID, null, null);
                }
            //});
            //task.Start();
            //task.Wait();
        }
        string RstrPanelID = "";
        int PanelRTCode = 0;
        string k_PanelID = "";
        public void BCToCtL_PNLValidationBitON(List<Int32> Message)
        {
            //LH
            //Task task = new Task(() =>
            //{
                _waitBCToCtL_Command_PNLValidationHandle.Reset();
                //if (BCToCtL_PNLValidationBitStates() == 1)//Bit ON
                {
                    BCToCtL_PNLValidation(ref RstrPanelID, ref PanelRTCode, Message);
                    CtLToBC_PNLValidationReply(true);
                    ToolSet.Log.Info("进入BCToCtL_PNLValidationBitON");
                }
                ToolSet.Log.Info(string.Format("<<获取Panel反馈结果---PanelID：{0},RtCode:{1}", RstrPanelID, PanelRTCode));
                ToolSet.Log.Info("进入_waitBCToCtL_Command_PNLValidationHandle等待...");
                //LH？  如果为off，后续是否不需要
                if (_waitBCToCtL_Command_PNLValidationHandle.WaitOne( VariableMap.waitTime)) //线程同步事件
                {
                    _waitBCToCtL_Command_PNLValidationHandle.Reset();
                    CtLToBC_PNLValidationReply(false);
                    ToolSet.Log.Info("进入BCToCtL_PNLValidationBitOff线程正常");
                    _waitPanelIDCheackHandle.Set();//表示验证完成
                }
                else
                {
                    _waitBCToCtL_Command_PNLValidationHandle.Reset();
                    CtLToBC_PNLValidationReply(false);
                    ToolSet.Log.Info("进入BCToCtL_PNLValidationBitOff线程超时");
                    _waitPanelIDCheackHandle.Set();//表示验证完成
                }
                if (BCPNLValidationCanReadEvent != null)
                {
                    Console.WriteLine("<BCPNLValidationCanReadEvent >事件触发");
                    //LH？   此处异步是否会造成问题
                    BCPNLValidationCanReadEvent(RstrPanelID, PanelRTCode);
                    //BCPNLValidationCanReadEvent.BeginInvoke(RstrPanelID, PanelRTCode,null,null);              
                }
            //});
            //task.Start();
            //task.Wait();
        }
        #endregion
        #region 获取Bit位状态
        public int BCToCtL_MessageBitStates()
        {
            return (int)ReadVariable("SD_BCToCtL_Command_Message[0]");
        }
        public int BCToCtL_DateTimeBitStates()
        {
            return (int)ReadVariable("SD_BCToCtL_Command_DateTime[0]");
        }
        public int BCToCtL_TrayValidationBitStates()
        {
            return (int)ReadVariable("SD_BCToCtL_Command_TrayValidation[0]");
        }
        public int BCToCtL_PNLValidationBitStates()
        {
            return (int)ReadVariable("SD_BCToCtL_Command_PNLValidation[0]");
        }
        #endregion
        #region CtlToBC的Reply方法定义
        //等待Bit off 之后，置位Reply
        public void CtLToBC_MessageReply(bool state)
        {
            WriteVariable("RV_CtLToBC_Command_MessageReply", state);
        }
        public void CtLToBC_DateTimeReply(bool state)
        {
            WriteVariable("RV_CtLToBC_Command_DateTimeReply", state);
        }
        public void CtLToBC_TrayValidationReply(bool state)
        {
            WriteVariable("RV_CtLToBC_Command_TrayValidationReply", state);
        }
        public void CtLToBC_PNLValidationReply(bool state)
        {
            WriteVariable("RV_CtLToBC_Command_PNLValidationReply", state);
        }
        #endregion

        #region Ascii字符串转Int数组
        public Int32[] AsciiToIntArray(string Ascii)
        {
            byte[] b = Encoding.Default.GetBytes(Ascii);
            List<Int32> Ldata = new List<Int32>();
            for (int i = 0; i < b.Length; i++)
            {
                if (i % 2 == 1)//实际是偶数
                {
                    byte[] mbaye = new byte[2];
                    mbaye[0] = b[i - 1];
                    mbaye[1] = b[i];
                    Array.Reverse(mbaye); //字节序反转
                    Ldata.Add(mbaye[0]*256 + mbaye[1]);
                }
                else if(i == (b.Length - 1))
                {
                    Ldata.Add(b[i]);
                }
            }
            return  Ldata.ToArray();
        }
        //int数组转字符串
        public string IntArrayToAscii(Int32[] array)
        {

            List<byte> vs = new List<byte>();
            for (int i = 0; i < array.Length; i++)
            {
                vs.Add((byte)Convert.ToInt16((array[i] % 256).ToString(),10));
                vs.Add((byte)Convert.ToInt16((array[i] / 256).ToString(),10));  
            }
            return Encoding.Default.GetString(vs.ToArray());
        }
        #endregion

        public void ThSD_BCToCtL_Command_Message(List<Int32> listMessage)
        {
            if (SD_BCToCtL_Command_MessageEvent != null)
            {
                //SD_BCToCtL_Command_MessageEvent.BeginInvoke(null, new EventArgs(), null, null);
                IAsyncResult asynResult = SD_BCToCtL_Command_MessageEvent.BeginInvoke(listMessage, (Result) =>
                {
                    SD_BCToCtL_Command_MessageEvent.EndInvoke(Result);
                }, null);
            }
        }
        public void ThSD_BCToCtL_Command_DateTime(List<Int32> listMessage)
        {
            if (SD_BCToCtL_Command_DateTimeEvent != null)
            {
                //SD_BCToCtL_Command_DateTimeEvent.BeginInvoke(null, new EventArgs(), null, null);
                IAsyncResult asynResult = SD_BCToCtL_Command_DateTimeEvent.BeginInvoke(listMessage, (Result) =>
                {
                    SD_BCToCtL_Command_DateTimeEvent.EndInvoke(Result);
                }, null);
            }
        }
        public void ThSD_BCToCtL_Command_TrayValidation(List<Int32> listMessage)
        {
            if (SD_BCToCtL_Command_TrayValidationEvent != null)
            {
                //SD_BCToCtL_Command_TrayValidationEvent.BeginInvoke(null, new EventArgs(), null, null);
                IAsyncResult asynResult = SD_BCToCtL_Command_TrayValidationEvent.BeginInvoke(listMessage, (Result) =>
                {
                    SD_BCToCtL_Command_TrayValidationEvent.EndInvoke(Result);
                }, null);
            }
        }
        public void ThSD_BCToCtL_Command_PNLValidation(List<Int32> listMessage)
        {
            if (SD_BCToCtL_Command_PNLValidationEvent != null)
            {
                SD_BCToCtL_Command_PNLValidationEvent.BeginInvoke(listMessage, null, null);
            }
        }

        /// <summary>
        /// 变量改变触发此事件上
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void variableCompolet_Changed(object sender, EventArgs e)
        {
            if (m_bOfflineMode)
                return;

            int eventID;
            string myeventingName;
            try
            {
                while (true)//当有变量触发事件的时候集中处理完
                {
                    if (m_bClose) return;
                    if (ReciveEvent(out eventingName, out eventID,  0) == false)
                    {
                        return;//处理完之后退出死循环
                    }
                    if(CIMModeFlag)
                    {
                        myeventingName = dictVariableNames[eventingName];
                        MACGatewayMsg myMsg = new MACGatewayMsg();
                        myMsg.CTL_EventChanged = myeventingName;
                        myMsg.EventChanged = eventingName;

                        if (((int)variableCompolet.ReadVariable(myMsg.EventChanged) == 1) || ((myMsg.CTL_EventChanged == "SD_BCToCtL_Command_Message[0]") || (myMsg.CTL_EventChanged == "SD_BCToCtL_Command_DateTime[0]")
                        || (myMsg.CTL_EventChanged == "SD_BCToCtL_Command_TrayValidation[0]") || (myMsg.CTL_EventChanged == "SD_BCToCtL_Command_PNLValidation[0]")))//如果不是BitOn,直接退出
                        {
                            if (((myMsg.CTL_EventChanged == "SD_BCToCtL_Command_Message[0]") || (myMsg.CTL_EventChanged == "SD_BCToCtL_Command_DateTime[0]")
                            || (myMsg.CTL_EventChanged == "SD_BCToCtL_Command_TrayValidation[0]") || (myMsg.CTL_EventChanged == "SD_BCToCtL_Command_PNLValidation[0]")))
                            {
                                string str = myMsg.CTL_EventChanged.Replace("[0]", "");
                                myMsg.EventMessage.AddRange((int[])ReadVariable(str));
                            }
                            else
                            {
                                myMsg.EventMessage.Add(1);
                            }
                            #region     与BC之间变量交互时的BitOn/OFF
                            if (CIMFlowFlag == false)
                            {
                                switch (myMsg.CTL_EventChanged)
                                {
                                    case "SD_BCToCtL_Command_Message[0]":
                                        {
                                            if ((int)ReadVariable("SD_BCToCtL_Command_Message[0]") == 1)
                                            { 
                                                CIMFlowFlag = true;
                                                ThSD_BCToCtL_Command_Message(myMsg.EventMessage);
                                                CIMFlowFlag = false;
                                            }
                                            if ((int)ReadVariable("SD_BCToCtL_Command_Message[0]") == 0)//收到BitOFF之后OFF repaly
                                            {
                                                _waitSD_BCToCtL_Command_MessageHandle.Set();//设置线程同步事件
                                            }
                                        }
                                        break;
                                    case "SD_BCToCtL_Command_DateTime[0]":
                                        {
                                            if ((int)ReadVariable("SD_BCToCtL_Command_DateTime[0]") == 1)
                                            {
                                                CIMFlowFlag = true;
                                                ThSD_BCToCtL_Command_DateTime(myMsg.EventMessage);
                                                CIMFlowFlag = false;
                                            }
                                       
                                            if ((int)ReadVariable("SD_BCToCtL_Command_DateTime[0]") == 0)//收到BitOFF之后OFF repaly
                                            {
                                                _waitSD_BCToCtL_Command_DateTimeHandle.Set();//设置线程同步事件
                                            }
                                        }
                                        break;
                                    case "SD_BCToCtL_Command_TrayValidation[0]":
                                        {
                                            ToolSet.Log.Info("1-判定值TrayValidation[0]" + ReadVariable("SD_BCToCtL_Command_TrayValidation[0]").ToString());
                                            if ((int)ReadVariable("SD_BCToCtL_Command_TrayValidation[0]") == 1)
                                            {
                                                ToolSet.Log.Info("SD_BCToCtL_Command_TrayValidation[0] ==1");
                                                CIMFlowFlag = true;
                                                ThSD_BCToCtL_Command_TrayValidation(myMsg.EventMessage);
                                                CIMFlowFlag = false;
                                            }
                                            if ((int)ReadVariable("SD_BCToCtL_Command_TrayValidation[0]") == 0)//收到BitOFF之后OFF repaly
                                            {
                                                ToolSet.Log.Info("SD_BCToCtL_Command_TrayValidation[0] ==0");
                                                _waitSD_BCToCtL_Command_TrayValidationHandle.Set();//设置线程同步事件
                                            }
                                        }
                                        break;
                                    case "SD_BCToCtL_Command_PNLValidation[0]":
                                        {
                                            ToolSet.Log.Info("SD_BCToCtL_Command_PNLValidation[0]"+ReadVariable("SD_BCToCtL_Command_PNLValidation[0]").ToString());
                                            ToolSet.Log.Info("1-判定值PanelRTCode" + myMsg.EventMessage.ToString());
                                                                    
                                            if ((int)ReadVariable("SD_BCToCtL_Command_PNLValidation[0]") == 1)
                                            {
                                                ToolSet.Log.Info("SD_BCToCtL_Command_PNLValidation[0] == 1");
                                                CIMFlowFlag = true;
                                                ThSD_BCToCtL_Command_PNLValidation(myMsg.EventMessage);
                                                CIMFlowFlag = false;
                                            }
                                            
                                            if ((int)ReadVariable("SD_BCToCtL_Command_PNLValidation[0]") == 0)//收到BitOFF之后OFF repaly
                                            {
                                                ToolSet.Log.Info("SD_BCToCtL_Command_PNLValidation[0] == 0");
                                                _waitBCToCtL_Command_PNLValidationHandle.Set();//设置线程同步事件
                                            }
                                        }
                                        break;
                                    case "SD_BCToCtL_Event_EqpStatusChangeReply":
                                        {
                                            CIMFlowFlag = true;
                                            _waitSD_BCToCtL_Event_EqpStatusChangeHandle.Set();
                                            CIMFlowFlag = false;
                                        }
                                        break;
                                    case "SD_BCToCtL_Event_AlarmReply":
                                        {
                                            CIMFlowFlag = true;
                                            _waitSD_BCToCtL_Event_AlarmHandle.Set();//设置线程同步事件
                                            CIMFlowFlag = false;
                                        }
                                        break;
                                    case "SD_BCToCtL_Event_TactTimeReply":
                                        {
                                            CIMFlowFlag = true;
                                            _waitSD_BCToCtL_Event_TactTimeHandle.Set();
                                            CIMFlowFlag = false;
                                        }
                                        break;
                                    case "SD_BCToCtL_Event_PanelInfoRequestReply":
                                        {
                                            CIMFlowFlag = true;
                                            _waitSD_BCToCtL_Event_PanelInfoRequestHandle.Set();
                                            CIMFlowFlag = false;
                                        }
                                        break;
                                    case "SD_BCToCtL_Event_PanelReceiveReply":
                                        {
                                            CIMFlowFlag = true;
                                            _waitSD_BCToCtL_Event_PanelReceiveHandle.Set();
                                            CIMFlowFlag = false;
                                        }
                                        break;
                                    case "SD_BCToCtL_Event_ProcessStartReply":
                                        {
                                            CIMFlowFlag = true;
                                            _waitSD_BCToCtL_Event_ProcessStartHandle.Set();
                                            CIMFlowFlag = false;
                                        }
                                        break;
                                    case "SD_BCToCtL_Event_PanelUnitIn1Reply":
                                        {
                                            CIMFlowFlag = true;
                                            _waitSD_BCToCtL_Event_PanelUnitIn1Handle.Set();
                                            CIMFlowFlag = false;
                                        }
                                        break;
                                    case "SD_BCToCtL_Event_PanelUnitIn2Reply":
                                        {
                                            CIMFlowFlag = true;
                                            _waitSD_BCToCtL_Event_PanelUnitIn2Handle.Set();
                                            CIMFlowFlag = false;
                                        }
                                        break;
                                    case "SD_BCToCtL_Event_ProcessDataReply":
                                        {
                                            CIMFlowFlag = true;
                                            _waitSD_BCToCtL_Event_ProcessDataHandle.Set();
                                            CIMFlowFlag = false;
                                        }
                                        break;
                                    case "SD_BCToCtL_Event_PanelUnitOut1Reply":
                                        {
                                            CIMFlowFlag = true;
                                            _waitSD_BCToCtL_Event_PanelUnitOut1Handle.Set();
                                            CIMFlowFlag = false;
                                        }
                                        break;
                                    case "SD_BCToCtL_Event_PanelUnitOut2Reply":
                                        {
                                            CIMFlowFlag = true;
                                            _waitSD_BCToCtL_Event_PanelUnitOut2Handle.Set();
                                            CIMFlowFlag = false;
                                        }
                                        break;
                                    case "SD_BCToCtL_Event_PanelSendOutReply":
                                        {
                                            CIMFlowFlag = true;
                                            _waitSD_BCToCtL_Event_PanelSendOutHandle.Set();
                                            ToolSet.Log.Info("BC出料反馈SD_BCToCtL_Event_PanelSendOutReply！");
                                            CIMFlowFlag = false;
                                        }
                                        break;
                                    case "SD_BCToCtL_Event_PanelRemoveReply":
                                        {
                                            CIMFlowFlag = true;
                                            _waitSD_BCToCtL_Event_PanelRemoveHandle.Set();
                                            CIMFlowFlag = false;
                                        }
                                        break;
                                    case "SD_BCToCtL_Event_EqpRepairReply":
                                        {
                                            CIMFlowFlag = true;
                                            _waitSD_BCToCtL_Event_EqpRepairHandle.Set();
                                            CIMFlowFlag = false;
                                        }
                                        break;
                                    case "SD_BCToCtL_Event_TrayInfoRequestReply":
                                        {
                                            CIMFlowFlag = true;
                                            _waitSD_BCToCtL_Event_TrayInfoRequestHandle.Set();
                                            CIMFlowFlag = false;
                                        }
                                        break;
                                    case "SD_BCToCtL_Event_CapacityInfoReply":
                                        {
                                            CIMFlowFlag = true;
                                            _waitSD_BCToCtL_Event_CapacityInfoHandle.Set();
                                            CIMFlowFlag = false;
                                        }
                                        break;
                                    default:
                                        {
                                            CIMFlowID = -1;
                                            CIMFlowFlag = false;
                                        }
                                        break;
                                }
                            }

                            #endregion
                        }
                    }
                }
            }
            catch (OMRON.FinsGateway.EventMemory.EventMemoryException evtexp)
            {
                if (evtexp.ErrorCode != Convert.ToInt32(0x2000000b))
                {
                    MessageBox.Show(evtexp.Message);
                    return;
                }
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
                return;
            }
        }

        private bool m_bClose = false;
        public void Close()
        {
            try
            {
                m_bClose = true;
                Dipose();
                thEqpAlive.Abort();
                thBCAlive.Abort();
            }
            catch (Exception) { }
        }
     }
    }

