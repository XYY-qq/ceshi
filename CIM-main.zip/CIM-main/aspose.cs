﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Threading;
using System.Windows.Forms;
using System.IO;
using Aspose.Cells;

namespace ASPOSE
{
    class aspose
    {

        public static bool TemplateExportEmptyExcel(string strTemplatePath,string strNewPath)
        {
            SaveFileDialog sf = new SaveFileDialog();
            sf.Filter = "Excel files (*.xls)|*.xls";
            string path = System.IO.Path.Combine(Application.StartupPath, strTemplatePath);
            WorkbookDesigner designer = new WorkbookDesigner();
            try
            {
                designer.Open(path);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Designer.Open错误:"+ex.ToString(), "提示");
                return false;
            }
			//设置数据源
            DataTable dtSource = new DataTable();
            designer.SetDataSource(dtSource);
            designer.Process();
//            designer.Workbook.Worksheets[0].Name = "对比模板";

            try
            {
                string saveFile = strNewPath;
                designer.Save(saveFile);
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "异常");
                return false;
            }
        }

        public static bool CopyExcel(string strExcelPath)
        {
            Workbook workbook = new Workbook();
            workbook.Open(strExcelPath);

            int iSheetCount = workbook.Worksheets.Count;
            if (iSheetCount < 2)
            {
                return false;
            }
            if (workbook.Worksheets[0].Name != "对比模板")
            {
                return false;
            }
            workbook.Worksheets.AddCopy(0);
            workbook.Worksheets[iSheetCount].Name = "对比数据" + DateTime.Now.ToString("hhmmss");

            workbook.Save(strExcelPath);

            return true;
        }

        public static bool SetCellData(DataTable tb,string strPath,int iCol,bool bFormula,int iFormulaType)
        {
            try
            {
                Workbook workbook = new Workbook();
                workbook.Open(strPath);

                int i = 0;
                int icount = tb.Rows.Count-14;
                int iI = workbook.Worksheets.Count;
                for (i = 0; i < icount; i++)
                {
                    workbook.Worksheets[iI - 1].Cells[i + 2, iCol].PutValue(tb.Rows[i][0]);
                    workbook.Worksheets[iI - 1].Cells[i + 2, iCol+1].PutValue(tb.Rows[i][1]);
                }
                workbook.Worksheets[iI - 1].Cells[1, 0].PutValue(icount);

                //空格
                for (i = 0; i < 14; i++)
                {
                    workbook.Worksheets[iI - 1].Cells[90 * 4 + 2 + i, iCol].PutValue(tb.Rows[icount + i][0]);
                    workbook.Worksheets[iI - 1].Cells[90 * 4 + 2 + i, iCol + 1].PutValue(tb.Rows[icount + i][1]);
                }

                if (bFormula)
                {
                    //string strLL = "";
                    //string strRR = "";
                    //for (i = 0; i < icount; i++)
                    //{
                    //    if (iFormulaType == 2)
                    //    {
                    //        strLL = string.Format("=D{0}-B{1}", i + 3,i + 3);
                    //        strRR = string.Format("=E{0}-C{1}", i + 3, i + 3);
                    //    }
                    //    else
                    //    {
                    //        strLL = string.Format("=F{0}-B{1}", i + 3, i + 3);
                    //        strRR = string.Format("=G{0}-C{1}", i + 3, i + 3);
                    //    }
                        
                    //    workbook.Worksheets[iI - 1].Cells[i + 2, iCol+4].Formula=strLL;
                    //    workbook.Worksheets[iI - 1].Cells[i + 2, iCol + 5].Formula=strRR;
                    //}
                }

                workbook.Save(strPath);
            }
            catch (System.Exception ex)
            {
                return false;
            }
           
            return true;
        }

        public static bool CreateAutoSheet(string strPath,DataSet data,ref string strRet)
        {
            strRet = "";

            try
            {
                //如果strPath不存在，则创建它
                if (File.Exists(strPath))
                    File.Delete(strPath);
                FileStream stream =  File.Create(strPath);
                stream.Close();

                Workbook workbook = new Workbook(strPath);
                //workbook.Open(strPath);

                //向Excel中写入数据
                workbook.Worksheets.Add();
                int iI = workbook.Worksheets.Count;
                workbook.Worksheets[iI-1].Name = "CIM数据";

                workbook.Worksheets[iI - 1].Cells[0, 0].PutValue("时间");
                workbook.Worksheets[iI - 1].Cells[0, 1].PutValue("TrayID");
                workbook.Worksheets[iI - 1].Cells[0, 2].PutValue("PanelID");

                int iline = 1;
                foreach (System.Data.DataTable table in data.Tables)
                {
                    foreach (DataRow row in table.Rows)
                    {
                        workbook.Worksheets[iI - 1].Cells[iline, 0].PutValue(row[0].ToString());
                        workbook.Worksheets[iI - 1].Cells[iline, 1].PutValue(row[1].ToString());
                        workbook.Worksheets[iI - 1].Cells[iline, 2].PutValue(row[2].ToString());
                        iline++;
                    }
                    break;
                }

                Thread.Sleep(100);
                workbook.Save(strPath);
            }
            catch (System.Exception ex)
            {
                strRet = ex.Message;
                return false;
            }

            return true;
        }
    }
}
